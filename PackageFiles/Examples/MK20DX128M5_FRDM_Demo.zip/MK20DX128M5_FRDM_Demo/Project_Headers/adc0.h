/*
 * adc.h
 *
 *  Created on: 17/11/2013
 *      Author: podonoghue
 */

#ifndef ADC_H_
#define ADC_H_

#include "derivative.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
   adc_singleEnded8_9bitConversion    = ADC_CFG1_MODE(0),
   adc_singleEnded10_11bitConversion  = ADC_CFG1_MODE(2),
   adc_singleEnded12_13bitConversion  = ADC_CFG1_MODE(1),
   adc_singleEnded16bitConversion     = ADC_CFG1_MODE(3),
} adc_precision;

typedef enum {
   adc_polled     = 0,
   adc_interrupt  = ADC_SC1_AIEN_MASK,
} adc_mode;

typedef enum {
   adc_channel_dp0,           // Differential channel used single-ended
   adc_channel_dp1,           // Differential channel used single-ended
   adc_channel_dp2,           // Differential channel used single-ended
   adc_channel_dp3,           // Differential channel used single-ended
   adc_channel_se4b,          // Single-ended channel (there is no 'A' channels)
   adc_channel_se5b,          // Single-ended channel (there is no 'A' channels)
   adc_channel_se6b,          // Single-ended channel (there is no 'A' channels)
   adc_channel_se7b,          // Single-ended channel (there is no 'A' channels)
   adc_channel_se8,           // Single-ended channel
   adc_channel_se9,           // Single-ended channel
   adc_channel_se10_unavailable,
   adc_channel_se11_unavailable,
   adc_channel_se12,          // Single-ended channel
   adc_channel_se13,          // Single-ended channel
   adc_channel_se14,          // Single-ended channel
   adc_channel_se15,          // Single-ended channel
   adc_channel_se16_unavailable,
   adc_channel_se17_unavailable,
   adc_channel_se18_unavailable,
   adc_channel_dm0,           // Differential channel used single-ended
   adc_channel_se20_unavailable,
   adc_channel_dm3,           // Differential channel used single-ended
   adc_channel_vrefOut,       // Vref output
   adc_channel_se23_invert,   // Inverted single-ended channel
   adc_channel_reserved24_unavailable,
   adc_channel_reserved25_unavailable,
   adc_channel_seTemperature, // Single-ended - Internal chip temperature sensor
   adc_channel_seBandgap,     // Single-ended - Internal chip band-gap reference
   adc_channel_reserved28,
   adc_channel_seVrefsh,      // Single-ended - Internal chip Voltage reference high
   adc_channel_seVrefsl,      // Single-ended - Internal chip Voltage reference low
   adc_channel_disabled,      // Module disabled

   adc_channel_diff0           = (adc_channel_dp0|ADC_SC1_DIFF_MASK),            // Differential channels (DP0 & DM0)
   adc_channel_diff3           = (adc_channel_dp3|ADC_SC1_DIFF_MASK),            // Differential channels (DP3 & DM3)
   adc_channel_diffTemperature = (adc_channel_seTemperature|ADC_SC1_DIFF_MASK),  // Differential channels Internal chip temperature sensor
   adc_channel_diffBandgap     = (adc_channel_seBandgap|ADC_SC1_DIFF_MASK),      // Differential channels Internal chip band-gap reference
   adc_channel_diffVrefsh      = (adc_channel_seVrefsh|ADC_SC1_DIFF_MASK),       // Differential channels Internal chip Voltage reference

} adc_channel_select;

int adc0_doConversion(adc_channel_select channel, adc_mode mode);
void adc0_initialise(adc_precision mode);

#ifndef ADC0_USES_NAKED_HANDLERS
   typedef void (*ADCCallbackFunction)(int conversionValue);
   ADCCallbackFunction adc0_setCallbackFunction(ADCCallbackFunction callback);
#endif

#ifdef __cplusplus
}
#endif

#endif /* ADC_H_ */
