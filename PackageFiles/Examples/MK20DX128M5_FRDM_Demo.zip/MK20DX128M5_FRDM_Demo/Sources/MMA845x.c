/*
 * MMA845x.c
 *
 *  Created on: 22/11/2013
 *      Author: podonoghue
 */
#include <stdint.h>
#include "i2c.h"
#include "MMA845x.h"

#define ACCELEROMETER_ADDRESS       (0x1D<<1)

enum {
   STATUS,
   F_STATUS = STATUS,
   OUT_X_MSB,
   OUT_X_LSB,
   OUT_Y_MSB,
   OUT_Y_LSB,
   OUT_Z_MSB,
   OUT_Z_LSB,
   Reservedx07,
   Reservedx08,
   F_SETUP,
   TRIG_CFG,
   SYSMOD,
   INT_SOURCE,
   WHO_AM_I,
   XYZ_DATA_CFG,
   HP_FILTER_CUTOFF,
   PL_STATUS,
   PL_CFG,
   PL_COUNT,
   PL_BF_ZCOMP,
   P_L_THS_REG,
   FF_MT_CFG,
   FF_MT_SRC,
   FF_MT_THS,
   FF_MT_COUNT,
   reservedx19,
   reservedx1A,
   reservedx1B,
   reservedx1C,
   TRANSIENT_CFG,
   TRANSIENT_SCR,
   TRANSIENT_THS,
   TRANSIENT_COUNT,
   PULSE_CFG,
   PULSE_SRC,
   PULSE_THSX,
   PULSE_THSY,
   PULSE_THSZ,
   PULSE_TMLT,
   PULSE_LTCY,
   PULSE_WIND,
   ASLP_COUNT,
   CTRL_REG1,
   CTRL_REG2,
   CTRL_REG3,
   CTRL_REG4,
   CTRL_REG5,
   OFF_X,
   OFF_Y,
   OFF_Z,
};

/*
 * Read Accelerometer register
 *
 * @param regNum  - Register number
 */
static uint8_t readReg(int regNum) {
   uint8_t command[] = {regNum};

   i2c_receive(ACCELEROMETER_ADDRESS, command, sizeof(command));
   return command[0];
}

/*
 * Write Accelerometer register
 *
 * @param regNum  - Register number
 * @param value   - Value to write
 */
static void writeReg(int regNum, uint8_t value) {
   uint8_t command[] = {regNum, value};

   i2c_transmit(ACCELEROMETER_ADDRESS, command, sizeof(command));
}

#define CTRL_REG2_RESET_MASK (1<<6) // Reset accelerometer

/*
 * Reset Accelerometer register
 */
void MMA845x_Reset(void) {

   writeReg(CTRL_REG2, CTRL_REG2_RESET_MASK);
   // Device is not accessible after RESET
   // Wait a while
   int i;
   for(i=0; i<20000; i++) {
      __asm__("nop");
   }
//   while ((readReg(CTRL_REG2) & CTRL_REG2_RESET_MASK) != 0) {
//      __asm__("nop");
//   }
}

/*
 * Put accelerometer into Standby mode
 */
void MMA845x_Standby(void) {

   writeReg(CTRL_REG1, readReg(CTRL_REG1)&~CTRL_REG1_ACTIVE_MASK);
}

/*
 * Put accelerometer into Active mode
 */
void MMA845x_Active(void) {

   writeReg(CTRL_REG1, readReg(CTRL_REG1)|CTRL_REG1_ACTIVE_MASK);
}

/*
 * Initialise the accelerometer
 *
 * @param mode - mode of operation
 */
void MMA845x_Initialise(MMA845x_Mode mode) {

   MMA845x_Reset();
   MMA845x_Standby();
   writeReg(XYZ_DATA_CFG, mode);
   MMA845x_Active();
}

/*
 * Obtains measurements from the accelerometer
 *
 * @param status  - Indicates status of x, y & z measurements
 * @param x       - X axis value
 * @param y       - Y axis value
 * @param z       - Z axis value
 */
void MMA845x_ReadXYX(int *status, int *x, int *y, int *z) {
   uint8_t dataXYZ[7] = {STATUS};

   // Receive 7 registers (status, X-high, X-low, Y-high, Y-low, Z-high & Z-low)
   i2c_receive(ACCELEROMETER_ADDRESS, dataXYZ, sizeof(dataXYZ));

   // Unpack data and return (data is sign extended)
   *status = dataXYZ[0];
   *x = (int16_t)((dataXYZ[1]<<8)+dataXYZ[2]);
   *y = (int16_t)((dataXYZ[3]<<8)+dataXYZ[4]);
   *z = (int16_t)((dataXYZ[5]<<8)+dataXYZ[6]);
}
