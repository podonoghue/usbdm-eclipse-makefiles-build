/*
 * lptrm.c
 *
 *  Created on: 12/11/2013
 *      Author: podonoghue
 */

#include <stddef.h>
#include "derivative.h"
#include "leds.h"
#include "utilities.h"
#include "lptmr.h"

/*!=========================================================================
 *
 *   Low Power Timer (LPTMR) routines
 *
 *=========================================================================*/

#ifdef SIM_SCGC5_LPTIMER_MASK
#define SIM_SCGC5_LPTMR_MASK SIM_SCGC5_LPTIMER_MASK
#endif

// Choose LPTMR clock source
#if (_LPTMR_CLOCK == _LPTMR_CLOCK0)
#define LPTMR_PSR_PCS_VALUE (0)
#elif (_LPTMR_CLOCK == _LPTMR_CLOCK1)
#define LPTMR_PSR_PCS_VALUE (1)
#elif (_LPTMR_CLOCK == _LPTMR_CLOCK2)
#define LPTMR_PSR_PCS_VALUE (2)
#elif (_LPTMR_CLOCK == _LPTMR_CLOCK3)
#define LPTMR_PSR_PCS_VALUE (3)
#else
#error "Check _LPTMR_CLOCK in lptmr.h"
#endif

/*!
 *   Enable the LPTMR
 *
 *  @param interval Timer interrupt interval in LPTMR ticks (use LPTMR_MILLISECOND_TO_TICKS() macro)
 */
void lptmr_initialise(uint16_t interval) {

   // Enable clock to LPTMR interface
   SIM_SCGC5 |= SIM_SCGC5_LPTMR_MASK;
   // Disable timer
   LPTMR0_CSR = 0;
   // Set interval
   LPTMR0_CMR = interval-1;
   // PCS 0,1,2,3 => MCGIRCLK, LPO, ERCLK32K, OSCERCLK
   LPTMR0_PSR = LPTMR_PSR_PCS(LPTMR_PSR_PCS_VALUE)|LPTMR_PSR_PRESCALE(_LPTRM_PRESCALE_MASK_VALUE);

   if (interval<=1) {
      // Enable timer with roll-over
      LPTMR0_CSR = LPTMR_CSR_TEN_MASK;
   }
   else {
      // Enable timer + interrupts + reset on event
      LPTMR0_CSR = LPTMR_CSR_TEN_MASK|LPTMR_CSR_TIE_MASK|LPTMR_CSR_TCF_MASK;
      NVIC_EnableIRQ(LPTMR0_IRQn);
      // Set arbitrary priority level
      NVIC_SetPriority(LPTMR0_IRQn, 2);
   }
}

/*!
 *   Disable the LPTMR
 */
void lptmr_finalise(void) {
   // Enable clock to LPTMR interface
   SIM_SCGC5 |= SIM_SCGC5_LPTMR_MASK;
   // Disable timer
   LPTMR0_CSR = 0;
   NVIC_DisableIRQ(LPTMR0_IRQn);
}

#ifndef LPTMR_USES_NAKED_HANDLERS

//! Pointer to LPTMR callback function
static LPTMRCallbackFunction callbackFunction = NULL;

/*!
 *   Set LPTRM interrupt callback
 *
 *   @param callback - The callback function to execute on interrupt
 *
 *   @return - previous callback
 */
LPTMRCallbackFunction lptmr_setCallbackFunction(LPTMRCallbackFunction callback) {
   LPTMRCallbackFunction temp = callback;
   callbackFunction = callback;
   return temp;
}

/*!
 *   LPTRM interrupt handler
 *
 *   Calls LPTMR callback
 */
void LPTMR0_IRQHandler(void) {
   // Clear interrupt flag
   LPTMR0_CSR = LPTMR_CSR_TCF_MASK|LPTMR_CSR_TEN_MASK|LPTMR_CSR_TIE_MASK|LPTMR_CSR_TCF_MASK;

   if (callbackFunction != NULL) {
      callbackFunction();
   }
}
#endif
