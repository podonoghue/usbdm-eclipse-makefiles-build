/*
 * SPI.c
 *
 *  Created on: 07/08/2012
 *      Author: podonoghue
 */
#include <stddef.h>
#include "clock.h"
#include "derivative.h"
#include "utilities.h"
#include "Freedom.h"
#include "SPI.h"

// SPI used
#define SPI_NUM 0 // Modify to change which SPI is used

#define DEFAULT_SPI_FREQUENCY  (10000000)     //!< Default SPI frequency 10 MHz

#ifdef MCU_MK20D5

#define SPI0_PCSIS_NUM         2              // Which PCS # e.g. 0 => PCS0
#define SPI0_PCS_REG           SPI0_PCS2_REG
#define SPI0_PCS_NUM           SPI0_PCS2_NUM

#endif

#ifdef MCU_MK64F12

#define SPI0_PCSIS_NUM        2              // Which PCS e.g. PCS0
#define SPI0_PCS_REG          SPI0_PCS2_REG
#define SPI0_PCS_NUM          SPI0_PCS2_NUM

#define SPI1_PCSIS_NUM        0              // Which PCS e.g. PCS0
#define SPI1_PCS_REG          SPI1_PCS0_REG  // PORT containing PCS signal
#define SPI1_PCS_NUM          SPI1_PCS0_NUM  // PORT Pin number

#endif

/*!
 * Constructor
 *
 */
SPI_0::SPI_0() : SPI(SPI0) {

   // Enable SPI port pins clock
   // PCS,MOSI,MISO,SCLK
   SIM_SCGC5 |= PORT_CLOCK_MASK(SPI0_SIN_REG)|PORT_CLOCK_MASK(SPI0_SOUT_REG)|PORT_CLOCK_MASK(SPI0_SCK_REG)|PORT_CLOCK_MASK(SPI0_PCS_REG);

   // SPI_IN pin
   PCR(SPI0_SIN_REG,SPI0_SIN_NUM)  = PORT_PCR_MUX(SPI0_ALT_FN)|PORT_PCR_PE_MASK|PORT_PCR_PS_MASK;

   // SPI_OUT pin
   PCR(SPI0_SOUT_REG,SPI0_SOUT_NUM) = PORT_PCR_MUX(SPI0_ALT_FN)|PORT_PCR_DSE_MASK;

   // SPI_CLK pin
   PCR(SPI0_SCK_REG,SPI0_SCK_NUM)   = PORT_PCR_MUX(SPI0_ALT_FN)|PORT_PCR_DSE_MASK;

   // SPI PCS pin
   PCR(SPI0_PCS_REG,SPI0_PCS_NUM) = PORT_PCR_MUX(SPI0_ALT_FN)|PORT_PCR_DSE_MASK;

   // Enable SPI module clock
   SIM_SCGC6 |= SIM_SCGC6_SPI0_MASK;

   spi->MCR   = SPI_MCR_HALT_MASK|SPI_MCR_CLR_RXF_MASK|SPI_MCR_ROOE_MASK|SPI_MCR_CLR_TXF_MASK|SPI_MCR_PCSIS(1<<SPI0_PCSIS_NUM)|
                SPI_MCR_MSTR_MASK|SPI_MCR_DCONF(0)|SPI_MCR_SMPL_PT(0);

   setCTAR0Value(SPI_CTAR_SLAVE_FMSZ(8-1)); // 8-bit transfers
   setCTAR1Value(SPI_CTAR_SLAVE_FMSZ(8-1)); // 8-bit transfers
}

#ifdef SPI1

/*!
 * Constructor
 *
 */
SPI_1::SPI_1() : SPI((volatile SPI0_Type *)SPI1) {

   // Enable SPI port pins clock
   // PCS,MOSI,MISO,SCLK
   SIM_SCGC5 |= PORT_CLOCK_MASK(SPI1_SIN_REG)|PORT_CLOCK_MASK(SPI1_SOUT_REG)|PORT_CLOCK_MASK(SPI1_SCK_REG)|PORT_CLOCK_MASK(SPI1_PCS_REG);

   // SPI_IN pin
   PCR(SPI1_SIN_REG,SPI1_SIN_NUM)  = PORT_PCR_MUX(SPI1_ALT_FN)|PORT_PCR_PE_MASK|PORT_PCR_PS_MASK;

   // SPI_OUT pin
   PCR(SPI1_SOUT_REG,SPI1_SOUT_NUM) = PORT_PCR_MUX(SPI1_ALT_FN)|PORT_PCR_DSE_MASK;

   // SPI_CLK pin
   PCR(SPI1_SCK_REG,SPI1_SCK_NUM)   = PORT_PCR_MUX(SPI1_ALT_FN)|PORT_PCR_DSE_MASK;

   // SPI PCS pin
   PCR(SPI1_PCS_REG,SPI1_PCS_NUM) = PORT_PCR_MUX(SPI1_ALT_FN)|PORT_PCR_DSE_MASK;

   // Enable SPI module clock
   SIM_SCGC6 |= SIM_SCGC6_SPI1_MASK;

   spi->MCR   = SPI_MCR_HALT_MASK|SPI_MCR_CLR_RXF_MASK|SPI_MCR_ROOE_MASK|SPI_MCR_CLR_TXF_MASK|SPI_MCR_PCSIS(1<<SPI1_PCSIS_NUM)|
                SPI_MCR_MSTR_MASK|SPI_MCR_FRZ_MASK|SPI_MCR_DCONF(0)|SPI_MCR_SMPL_PT(0);

   setSpeed(0);   // Use default speed
   setCTAR0Value(SPI_CTAR0_SLAVE_FMSZ(8-1)); // 8-bit transfers
   setCTAR1Value(SPI_CTAR0_SLAVE_FMSZ(8-1)); // 8-bit transfers
}
#endif

/*!
 * Constructor
 *
 * @param baseAddress - Base address of SPI
 */
SPI::SPI(volatile SPI0_Type *baseAddress) {
   spi          = baseAddress;
   spiBaudValue = 0;

   setSpeed(0);   // Use default speed
}

/*!
 * Sets Communication speed for SPI
 *
 * @param frequency => Frequency in Hz (0 => use default value)
 *
 * Note: Chooses the highest speed that is not greater than frequency.
 * Note: Only has effect from when the CTAR value is next changed
 */
void SPI::setSpeed(uint32_t frequency) {
   static const uint16_t pbrFactors[] = {2,3,5,7};
   static const uint16_t brFactors[]  = {2,4,6,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768};

   if (frequency == 0) {
      frequency = DEFAULT_SPI_FREQUENCY;
   }
   int bestPBR = 0;
   int bestBR  = 0;
   uint32_t difference = -1;
   for (int pbr = 3; pbr >= 0; pbr--) {
      for (int br = 15; br >= 0; br--) {
         uint32_t calculatedFrequency = SystemBusClock/(pbrFactors[pbr]*brFactors[br]);
         if (calculatedFrequency > frequency) {
            // Too high stop looking here
            break;
         }
         if ((frequency - calculatedFrequency) < difference) {
            // New "best value"
            difference = (frequency - calculatedFrequency);
            bestBR  = br;
            bestPBR = pbr;
         }
      }
   }
   spiBaudValue = SPI_CTAR_BR(bestBR)|SPI_CTAR_PBR(bestPBR);
}

/*!
 * Transmit and receive an 8-bit value over SPI
 *
 * @param data - Data to send
 *
 * @return Data received
 */
uint32_t SPI::txRx(uint32_t data) {
   spi->MCR &= ~SPI_MCR_HALT_MASK;
   spi->PUSHR = SPI_PUSHR_PCS(0xFF)|data;
   while ((spi->SR & SPI_SR_TCF_MASK)==0) {
      __asm__("nop");
   }
   spi->SR = SPI_SR_TCF_MASK|SPI_SR_EOQF_MASK;
   return spi->POPR;  // Return read data
}

/*!
 *  Transmit and receive a series of bytes
 *
 *  @param dataSize  Number of bytes to transfer
 *  @param dataOut   Transmit bytes (may be NULL for Rx only)
 *  @param dataIn    Receive byte buffer (may be NULL for Tx only)
 */
void SPI::txRxBytes(uint32_t dataSize, const uint8_t *dataOut, uint8_t *dataIn) {
   while(dataSize-->0) {
      uint32_t sendData = 0xFF;
      if (dataOut != NULL) {
         sendData = *dataOut++;
      }
      if (dataSize == 0) {
         sendData |= SPI_PUSHR_EOQ_MASK;
      }
      else {
         sendData |= SPI_PUSHR_CONT_MASK;
      }
      uint32_t data = txRx(sendData);
      if (dataIn != NULL) {
         *dataIn++ = data;
      }
   }
   spi->MCR |= SPI_MCR_HALT_MASK;
   while ((spi->SR&SPI_SR_TXRXS_MASK)) {
      __asm__("nop");
   }
}
