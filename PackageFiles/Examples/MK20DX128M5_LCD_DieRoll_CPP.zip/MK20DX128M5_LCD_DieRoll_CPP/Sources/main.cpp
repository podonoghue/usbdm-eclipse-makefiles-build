/*
 ============================================================================
 * main.cpp
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include "derivative.h"
#include "leds.h"
#include "timer.h"
#include "LCD.h"
#include "uart.h"
#include "Freedom.h"
#include "Die.h"

static Die die(new LCD(new SPI_0()));

void port_initialise() {

   // Enable all port clocks
   SIM->SCGC5 |=   SIM_SCGC5_PORTA_MASK
                | SIM_SCGC5_PORTB_MASK
                | SIM_SCGC5_PORTC_MASK
                | SIM_SCGC5_PORTD_MASK
                | SIM_SCGC5_PORTE_MASK;
}

#define CENTRE_SWITCH_PCR          PCR(CENTRE_SWITCH_PORT,CENTRE_SWITCH_NUM)
#define CENTRE_SWITCH_PDOR         PDOR(CENTRE_SWITCH_PORT)
#define CENTRE_SWITCH_PSOR         PSOR(CENTRE_SWITCH_PORT)  // Data set
#define CENTRE_SWITCH_PCOR         PCOR(CENTRE_SWITCH_PORT)  // Data clear
#define CENTRE_SWITCH_PTOR         PTOR(CENTRE_SWITCH_PORT)  // Data toggle
#define CENTRE_SWITCH_PDIR         PDIR(CENTRE_SWITCH_PORT)  // Data input
#define CENTRE_SWITCH_PDDR         PDDR(CENTRE_SWITCH_PORT)  // Data direction
#define CENTRE_SWITCH_MASK         (1<<CENTRE_SWITCH_NUM)

int getSwitch(void) {
   return (CENTRE_SWITCH_PDIR&CENTRE_SWITCH_MASK) == 0;
}

int main(void) {
   port_initialise();
   led_initialise();
   greenLedOn();

   CENTRE_SWITCH_PCR   = PORT_PCR_MUX(1)|PORT_PCR_PE_MASK|PORT_PCR_PS_MASK;
   CENTRE_SWITCH_PDDR &= ~(1<<CENTRE_SWITCH_NUM);

   srand(time(NULL));

   for(;;) {
      int timerValue;
      // Wait for switch press
      while (!getSwitch()) {
         time_t currentTime;
         struct tm *timeInfo;

         currentTime = time(NULL);
         timeInfo = localtime(&currentTime);
         printf("Time = %s\n", asctime(timeInfo));
      }
      // Roll while switch held
      while (getSwitch()) {
        die.rollOnce();
      }
      // Continue rolling for a while
      timerValue = 5 + rand()%16;
      while (timerValue-->0) {
         die.rollOnce();
      }
   }
}
