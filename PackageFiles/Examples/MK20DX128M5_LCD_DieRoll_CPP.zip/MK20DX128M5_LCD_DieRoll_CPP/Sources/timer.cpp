/*
 * timer.cpp
 *
 *  Created on: 12/05/2013
 *      Author: podonoghue
 */

#include <stdint.h>
#include "derivative.h"
#include "timer.h"

//=========================================================================
// Timer routines
//
//=========================================================================

//! Wait for given time in timer ticks
//!
//!  @param delay Delay time in fast timer ticks
//!
//!  @note Limited to ?? ms
//!
void fastTimerWait(uint32_t delay) {
   SIM->SCGC6 |= SIM_SCGC6_PIT_MASK;
   PIT->MCR    = PIT_MCR_FRZ_MASK; // Enable timers, timers freeze in debug mode

   PIT->CHANNEL[0].LDVAL = delay;                  // Set up delay
	PIT->CHANNEL[0].TFLG  = PIT_TFLG_TIF_MASK;      // Clear timer flag
	PIT->CHANNEL[0].TCTRL = PIT_TCTRL_TEN_MASK;     // Enable (and reset) timer
	while ((PIT->CHANNEL[0].TFLG&PIT_TFLG_TIF_MASK) == 0) { // Wait for timeout
	}
	PIT->CHANNEL[0].TCTRL = 0;                      // Disable timer
}

//! Wait for given time in milliseconds
//!
//! @param delay Delay time in milliseconds
//!
void millisecondTimerWait(uint16_t delay) {
   SIM->SCGC6 |= SIM_SCGC6_PIT_MASK;
   PIT->MCR    = PIT_MCR_FRZ_MASK; // Enable timers, timers freeze in debug mode

   PIT->CHANNEL[0].LDVAL = TIMER_MICROSECOND(1000); // Set up delay
	PIT->CHANNEL[0].TCTRL = PIT_TCTRL_TEN_MASK;      // Enable (and reset) timer
	while (delay-->0) {
		PIT->CHANNEL[0].TFLG  = PIT_TFLG_TIF_MASK;              // Clear timer flag
		while ((PIT->CHANNEL[0].TFLG&PIT_TFLG_TIF_MASK) == 0) { // Wait for timeout
		}
	}
	PIT->CHANNEL[0].TCTRL = 0;                       // Disable timer
}
