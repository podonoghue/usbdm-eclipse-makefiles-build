/*
 * SPI.h
 *
 *  Created on: 07/08/2012
 *      Author: podonoghue
 */

#ifndef SPI_H_
#define SPI_H_

#include <stdint.h>
#include "derivative.h"

/*!
 * Basic SPI interface class
 */
class SPI {
protected:
   volatile SPI_Type *spi;
            uint32_t   spiBaudValue;

public:
   SPI(volatile SPI_Type *baseAddress);

   uint32_t txRx(uint32_t data);

   void setSpeed(uint32_t freq);

   void txRxBytes(uint32_t dataSize, const uint8_t *dataOut, uint8_t *dataIn);

   /*! Set SPI.CTAR0 value
    *
    * @param ctar 32-bit CTAR value (excluding baud)
    */
   void setCTAR0Value(uint32_t ctar) {
      spi->CTAR[0] = spiBaudValue|ctar;
   }

   /*! Set SPI.CTAR1 value
    *
    * @param ctar 32-bit CTAR value (excluding baud)
    */
   void setCTAR1Value(uint32_t ctar) {
      spi->CTAR[1] = spiBaudValue|ctar;
   }
};

/*!
 * Class representing SPI0
 */
class SPI_0 : public SPI {
public:
   SPI_0();
};

#ifdef SPI1
/*!
 * Class representing SPI1
 */
class SPI_1 : public SPI {
public:
   SPI_1();
};

#endif

#endif /* SPI_H_ */
