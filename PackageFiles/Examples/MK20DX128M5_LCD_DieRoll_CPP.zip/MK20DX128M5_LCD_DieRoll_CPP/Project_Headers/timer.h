/*
 * timer.h
 *
 *  Created on: 12/05/2013
 *      Author: podonoghue
 */

#ifndef TIMER_H_
#define TIMER_H_

#include "clock.h"

// Timer constants, 24MHz ticks
#define TIMER_FREQ               (SystemBusClock/2)
#define TIMER_MICROSECOND(x)     (((x)*(TIMER_FREQ/1000))/1000UL)  // Timer ticks in 1 us

/*! \brief A Macro to wait for given time (makes use of timer).

    @param  t  Time to wait in \e microseconds.

    @note Limited to 2 ms
*/
#define WAIT_US(t) fastTimerWait(TIMER_MICROSECOND(t))
/*! \brief A Macro to wait for given time (makes use of timer).

    @param  t  Time to wait in \e milliseconds (<65000 ms).
*/
#define WAIT_MS(t) millisecondTimerWait((t))
/*! \brief A Macro to wait for given time or until a condition is met

    @param  t  Maximum time to wait in \e microseconds (<???).
    @param  c  Condition to exit wait early
*/
#define WAIT_WITH_TIMEOUT_US(t,c) {                         \
   PIT_LDVAL0 = TIMER_MICROSECOND(t);                       \
   PIT_TFLG0  = PIT_TFLG_TIF_MASK;                          \
   PIT_TCTRL0 = PIT_TCTRL_TEN_MASK;                         \
   while (!(c) && ((PIT_TFLG0&PIT_TFLG_TIF_MASK)==0)) {     \
   }                                                        \
   PIT_TCTRL0 = 0;                                          \
}
/*! \brief A Macro to wait for given time or until a condition is met

    @param  t  Maximum time to wait in \e milliseconds.
    @param  c  Condition to exit wait early
*/
#define WAIT_WITH_TIMEOUT_MS(t,c) {                         \
   int tt = t;                                              \
   PIT_LDVAL0 = TIMER_MICROSECOND(1000);                    \
   PIT_TCTRL0 = PIT_TCTRL_TEN_MASK;                         \
   while (!(c) && (tt-->0)) {                               \
      PIT_TFLG0  = PIT_TFLG_TIF_MASK;                       \
      while ((PIT_TFLG0&PIT_TFLG_TIF_MASK)==0) {            \
      }                                                     \
   }                                                        \
   PIT_TCTRL0 = 0;                                          \
}
/*! \brief A Macro to wait for given time or until a condition is met

    @param  t  Maximum time to wait in \e seconds.
    @param  c  Condition to exit wait early (checked every ~10 ms and affects timing)
*/
#define WAIT_WITH_TIMEOUT_S(t,c) {       \
    int tt = 100*(t);                    \
      do {                               \
         millisecondTimerWait(10);       \
      } while (!(c) & (tt-->0));         \
   }
/*! \brief Wait for given time in milliseconds (makes use of timer).

    @param  delay Time to wait in \e milliseconds.
*/
void millisecondTimerWait(uint16_t delay);
//! Wait for given time in fast timer ticks
//!
//!  @param delay Delay time in fast timer ticks
//!
//!  @note Limited to 2 ms
//!
void fastTimerWait(uint32_t delay);
//! Initialises the timers, input captures and interrupts
//!

void fastTimerWait(uint32_t delay);
void millisecondTimerWait(uint16_t delay);
uint8_t timer_initialise(void);

#endif /* TIMER_H_ */
