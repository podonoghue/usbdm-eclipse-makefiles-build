/*
 * rtc.c
 *
 *  Created on: 21/09/2013
 *      Author: podonoghue
 */

#include <sys/time.h>
#include "derivative.h"
#include "utilities.h"
#include "rtc.h"

#ifdef RTC_TSR
void rtc_initialise(void) {
   // Enable clock to RTC interface
   SIM_SCGC6 |= SIM_SCGC6_RTC_MASK;

   // Enable oscillator
//   RTC_CR  = RTC_CR_OSCE_MASK|RTC_CR_SC8P_MASK|RTC_CR_UM_MASK;
   int i;
   for (i=0; i<100000; i++) {
      __asm("nop");
   }
//   SIM_SOPT2 |= SIM_SOPT2_RTCCLKOUTSEL_MASK;    // RTC_CLKOUT = 32kHz
//   PORTE_PCR0 = PORT_PCR_MUX(7);                // Enable RTC_CLKOUT

   if ((RTC_SR&RTC_SR_TIF_MASK) != 0) {
      // RTC is not running or invalid - re-initialise

      // Software reset RTC
      RTC_CR  = RTC_CR_SWR_MASK;
      RTC_CR  = 0;
      // Enable oscillator
      RTC_CR  = RTC_CR_OSCE_MASK|RTC_CR_SC8P_MASK|RTC_CR_UM_MASK;
      // Set current time
      RTC_TSR = 1379453899;  // A bit closer to today!
      RTC_SR  = RTC_SR_TCE_MASK;
   }
//   NVIC_EnableIRQ(RTC_Seconds_IRQn);

//   RTC_IER = 0; // Disable all alarm interrupts
//   RTC_LR  = 0; // Lock all registers (LRL, SRL, CRL, TCL,
//   RTC_WAR = 0; // Disable writes to (IERW, LRW, SRW, CRW, TCRW, TARW, TPRW, TSRW) registers
}

static void setRealTimeValue(uint32_t timeSinceEpoch) {
   RTC_SR  = 0;
   RTC_TSR = timeSinceEpoch;
   RTC_SR  = RTC_SR_TCE_MASK;
}

void enableRTCSecondInterrupt(void) {
   // Enable clock to RTC interface
   SIM_SCGC6 |= SIM_SCGC6_RTC_MASK;
   // Enable interrupts from RTC
   RTC_IER   |= RTC_IER_TSIE_MASK;
   NVIC_EnableIRQ(RTC_Seconds_IRQn);
}

/*
 *   To support time.h functions
 */
int _gettimeofday(struct timeval *tp, void *tzp) {
   (void)tzp;
   if (((SIM_SCGC6 & SIM_SCGC6_RTC_MASK) == 0) ||
       ((RTC_SR&RTC_SR_TIF_MASK) != 0) ) {
      tp->tv_sec  = -1;
   }
   else {
      tp->tv_sec  = RTC_TSR;
   }
   tp->tv_usec = 0;
   return 0;
}

/*
 *   To support time.h functions
 */
int settimeofday(const struct timeval *tp, const struct timezone *tzp) {
   (void)tzp;
   // Start RTC
   rtc_initialise();
   setRealTimeValue(tp->tv_sec);
   return 0;
}
#endif
