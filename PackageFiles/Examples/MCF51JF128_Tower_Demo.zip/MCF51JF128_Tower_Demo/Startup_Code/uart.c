/*
 * uart.c
 *
 *  Created on: 14/04/2013
 *      Author: pgo
 */

#include <derivative.h>
#include "clock.h"
#include "uart.h"
#include "Freedom.h"

#define TX_MUX_REG     MXC(UART0_TX_PIN_PORT,UART0_TX_MUX_NUM)
#define RX_MUX_REG     MXC(UART0_RX_PIN_PORT,UART0_RX_MUX_NUM)
#define TX_MUX_MASK(n) MXC_MASK(UART0_TX_PIN_NUM,n)
#define RX_MUX_MASK(n) MXC_MASK(UART0_RX_PIN_NUM,n)

void uart_initialise(int baudrate) {
   uint16_t ubd;

   // Enable clock to UART
   SIM_SCGC1 |= SIM_SCGC1_UART0_MASK;

   // Set Tx (A7) & Rx (D6) Pin function
   MXC_PTDPF1 = (MXC_PTDPF1 & ~MXC_PTDPF1_D6_MASK) | MXC_PTDPF1_D6(UART0_RX_PIN_FN); // UART0_Rx
   RX_MUX_REG = (RX_MUX_REG & ~RX_MUX_MASK(0xF))   | RX_MUX_MASK(UART0_RX_PIN_FN);
   MXC_PTAPF1 = (MXC_PTAPF1 & ~MXC_PTAPF1_A7_MASK) | MXC_PTAPF1_A7(UART0_TX_PIN_FN); // UART0_Tx
   TX_MUX_REG = (TX_MUX_REG & ~TX_MUX_MASK(0xF))   | TX_MUX_MASK(UART0_TX_PIN_FN);

   // Set Tx & Rx pins in use
//   SIM_SOPT5 &= ~(SIM_SOPT5_UART0RXSRC_MASK|SIM_SOPT5_UART0TXSRC_MASK);

   // Disable UART before changing registers
   UART0_C2 &= ~(UART_C2_TE_MASK | UART_C2_RE_MASK);

   // Calculate baud settings
   ubd = (uint16_t)(SystemCoreClock/(baudrate * 16));

   // Set Baud rate register
   UART0_BDH = (UART0_BDH&~UART_BDH_SBR_MASK) | UART_BDH_SBR((ubd>>8));
   UART0_BDL = UART_BDL_SBR(ubd);

#ifdef UART_C4_BRFA_MASK
   // Determine fractional divider to get closer to the baud rate
   uint16_t brfa;
   brfa     = (uint8_t)(((SystemCoreClock*32000)/(baudrate * 16)) - (ubd * 32));
   UART0_C4 = (UART0_C4&~UART_C4_BRFA_MASK) | UART_C4_BRFA(brfa);

#endif
   UART0_C1 = 0;

   // Enable UART Tx & Rx
   UART0_C2 = UART_C2_TE_MASK|UART_C2_RE_MASK;
}


/*
 * Transmits a single character over the UART (blocking)
 *
 * @param ch - character to send
 */
void uart_txChar(int ch) {
   while ((UART0_S1 & UART_S1_TDRE_MASK) == 0) {
      // Wait for Tx buffer empty
      __asm__("nop");
   }
   UART0_D = ch;
}

/*
 * Receives a single character over the UART (blocking)
 *
 * @return - character received
 */
int uart_rxChar(void) {
   while ((UART0_S1 & UART_S1_RDRF_MASK) == 0) {
      // Wait for Rx buffer full
      __asm__("nop");
   }
   return UART0_D;
};
