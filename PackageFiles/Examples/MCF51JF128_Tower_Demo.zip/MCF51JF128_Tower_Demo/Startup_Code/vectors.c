/*
 *  Vectors.c
 *
 *  Generic vectors and security for Coldfire V1
 *
 *  Created on: 07/12/2012
 *      Author: podonoghue
 */
#include <stdint.h>

#define DEVICE_SUBFAMILY_CFV1Plus

/*
 * Security information
 */
#if defined(DEVICE_SUBFAMILY_CFV1Plus)
typedef struct {
    uint8_t   backdoorKey[8];
    uint8_t   fprot[4];
    uint8_t   fdprot;
    uint8_t   feprot;
    uint8_t   fopt;
    uint8_t   fsec;
} SecurityInfo;

__attribute__ ((section(".cs3.security_information")))
const SecurityInfo securityInfo = {
    /* backdoor */ {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},
    /* fprot    */ {0xFF,0xFF,0xFF,0xFF,},
    /* fdprot   */ 0xFF,
    /* feprot   */ 0xFF,
    /* fopt     */ 0xFF,
    /* fsec     */ 0xFE,  /* KEYEN=3,MEEN=3,FSLACC=3,SEC=2 */
};
#elif defined(DEVICE_SUBFAMILY_CFV1)
typedef struct {
    uint8_t  backdoorKey[8];
    uint8_t  res1[5];
    uint8_t  nvprot;
    uint8_t  res2;
    uint8_t  nvopt;
} SecurityInfo;

__attribute__ ((section(".cs3.security_information")))
const SecurityInfo securityInfo = {
    /* backdoor */ {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},
    /* res1     */ {0xFF,0xFF,0xFF,0xFF,0xFF,},
    /* nvprot   */ 0xFF,
    /* res2     */ 0xFF,
    /* nvopt    */ 0xFF,
};
#else
#error "Device family not set"
#endif

/*
 * Vector table related
 */
typedef void( *const intfunc )( void );

#define WEAK_DEFAULT_HANDLER __attribute__ ((weak, alias("Default_Handler")))

 __attribute__((__interrupt__))
void Default_Handler(void) {
   while (1) {
      asm("halt");
   }
}

void __cs3_reset(void) __attribute__((__interrupt__));
extern uint32_t __cs3_stack;

void AccessError_Handler(void)           WEAK_DEFAULT_HANDLER;
void AddressError_Handler(void)          WEAK_DEFAULT_HANDLER;
void IllegalInstruction_Handler(void)    WEAK_DEFAULT_HANDLER;
void DivideBy0_Handler(void)       	     WEAK_DEFAULT_HANDLER;
void PrivilegeViolation_Handler(void)    WEAK_DEFAULT_HANDLER;
void Trace_Handler(void)       		     WEAK_DEFAULT_HANDLER;
void UnimplementedLineA_Handler(void)    WEAK_DEFAULT_HANDLER;
void UnimplementedLineF_Handler(void)    WEAK_DEFAULT_HANDLER;
void NonPCBreakpoint_Handler(void)       WEAK_DEFAULT_HANDLER;
void PCBreakpoint_Handler(void)          WEAK_DEFAULT_HANDLER;
void FormatError_Handler(void)           WEAK_DEFAULT_HANDLER;
void Uninitialized_IRQHandler(void)      WEAK_DEFAULT_HANDLER;
void SpuriousInt_IRQHandler(void)        WEAK_DEFAULT_HANDLER;
void AutoVector1_IRQHandler(void)        WEAK_DEFAULT_HANDLER;
void AutoVector2_IRQHandler(void)        WEAK_DEFAULT_HANDLER;
void AutoVector3_IRQHandler(void)        WEAK_DEFAULT_HANDLER;
void AutoVector4_IRQHandler(void)        WEAK_DEFAULT_HANDLER;
void AutoVector5_IRQHandler(void)        WEAK_DEFAULT_HANDLER;
void AutoVector6_IRQHandler(void)        WEAK_DEFAULT_HANDLER;
void AutoVector7_IRQHandler(void)        WEAK_DEFAULT_HANDLER;
void Trap0_IRQHandler(void)              WEAK_DEFAULT_HANDLER;
void Trap1_IRQHandler(void)              WEAK_DEFAULT_HANDLER;
void Trap2_IRQHandler(void)              WEAK_DEFAULT_HANDLER;
void Trap3_IRQHandler(void)              WEAK_DEFAULT_HANDLER;
void Trap4_IRQHandler(void)              WEAK_DEFAULT_HANDLER;
void Trap5_IRQHandler(void)              WEAK_DEFAULT_HANDLER;
void Trap6_IRQHandler(void)              WEAK_DEFAULT_HANDLER;
void Trap7_IRQHandler(void)              WEAK_DEFAULT_HANDLER;
void Trap8_IRQHandler(void)              WEAK_DEFAULT_HANDLER;
void Trap9_IRQHandler(void)              WEAK_DEFAULT_HANDLER;
void Trap10_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void Trap11_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void Trap12_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void Trap13_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void Trap14_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void Trap15_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void UnsuppportedInstr_IRQHandler(void)  WEAK_DEFAULT_HANDLER;
void Irq_IRQHandler(void)                WEAK_DEFAULT_HANDLER;
void LVD_IRQHandler(void)                WEAK_DEFAULT_HANDLER;
void LLWU_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void MCG_LOL_IRQHandler(void)            WEAK_DEFAULT_HANDLER;
void Flash_IRQHandler(void)              WEAK_DEFAULT_HANDLER;
void DMA_Channel0_IRQHandler(void)       WEAK_DEFAULT_HANDLER;
void DMA_Channel1_IRQHandler(void)       WEAK_DEFAULT_HANDLER;
void DMA_Channel2_IRQHandler(void)       WEAK_DEFAULT_HANDLER;
void DMA_Channel3_IRQHandler(void)       WEAK_DEFAULT_HANDLER;
void USB0_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void RNGB_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void FTM1_Fault_IRQHandler(void)         WEAK_DEFAULT_HANDLER;
void FTM1_Ch0_IRQHandler(void)           WEAK_DEFAULT_HANDLER;
void FTM1_Ch1_IRQHandler(void)           WEAK_DEFAULT_HANDLER;
void FTM1_Ch2_IRQHandler(void)           WEAK_DEFAULT_HANDLER;
void FTM1_Ch3_IRQHandler(void)           WEAK_DEFAULT_HANDLER;
void FTM1_Ch4_IRQHandler(void)           WEAK_DEFAULT_HANDLER;
void FTM1_Ch5_IRQHandler(void)           WEAK_DEFAULT_HANDLER;
void CMP0_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void FTM0_Fault_IRQHandler(void)         WEAK_DEFAULT_HANDLER;
void FTM0_Ch0_IRQHandler(void)           WEAK_DEFAULT_HANDLER;
void FTM0_Ch1_IRQHandler(void)           WEAK_DEFAULT_HANDLER;
void SPI0_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void UART0_IRQHandler(void)              WEAK_DEFAULT_HANDLER;
void I2S_Rx_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void I2S_Tx_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void I2C0_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void I2C2_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void SPI1_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void UART1_IRQHandler(void)              WEAK_DEFAULT_HANDLER;
void I2C1_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void I2C3_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void ADC0_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void TSI0_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void DAC0_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void CMT_IRQHandler(void)                WEAK_DEFAULT_HANDLER;
void PDB0_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void LPTMR0_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
extern void LPTMR0_IRQHandler(void);
void LPTMR1_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void L7_SWI_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void L6_SWI_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void L5_SWI_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void L4_SWI_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void L3_SWI_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void L2_SWI_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void L1_SWI_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void MTIM0_IRQHandler(void)              WEAK_DEFAULT_HANDLER;
void USBDCD_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void PORTA_B_IRQHandler(void)            WEAK_DEFAULT_HANDLER;
void PORTD_C_IRQHandler(void)            WEAK_DEFAULT_HANDLER;
void PORTF_E_IRQHandler(void)            WEAK_DEFAULT_HANDLER;

__attribute__ ((section(".cs3.interrupt_vector")))
intfunc const __cs3_interrupt_vector_coldfire[256] = {
    (intfunc)(&__cs3_stack),        /*   0 The stack pointer after relocation           */
    __cs3_reset,                    /*   1 Reset                                        */
    AccessError_Handler,            /*   2 Access Error                                 */
    AddressError_Handler,           /*   3 Address Error                                */
    IllegalInstruction_Handler,     /*   4 Illegal Instruction                          */
    DivideBy0_Handler,              /*   5 Divide by Zero                               */
    Default_Handler,                /*   6 Reserved                                     */
    Default_Handler,                /*   7 Reserved                                     */
    PrivilegeViolation_Handler,     /*   8 Privilege Violation                          */
    Trace_Handler,                  /*   9 Trace                                        */
    UnimplementedLineA_Handler,     /*  10 Unimplemented Line A                         */
    UnimplementedLineF_Handler,     /*  11 Unimplemented Line F                         */
    NonPCBreakpoint_Handler,        /*  12 Non-PC Breakpoint                            */
    PCBreakpoint_Handler,           /*  13 PC Breakpoint                                */
    FormatError_Handler,            /*  14 Format Error                                 */
    Uninitialized_IRQHandler,       /*  15 Uninitialized Interrupt                      */
    Default_Handler,                /*  16 Reserved                                     */
    Default_Handler,                /*  17 Reserved                                     */
    Default_Handler,                /*  18 Reserved                                     */
    Default_Handler,                /*  19 Reserved                                     */
    Default_Handler,                /*  20 Reserved                                     */
    Default_Handler,                /*  21 Reserved                                     */
    Default_Handler,                /*  22 Reserved                                     */
    Default_Handler,                /*  23 Reserved                                     */
    SpuriousInt_IRQHandler,         /*  24 Spurious Interrupt                           */
    AutoVector1_IRQHandler,         /*  25 AutoVector 1                                 */
    AutoVector2_IRQHandler,         /*  26 AutoVector 2                                 */
    AutoVector3_IRQHandler,         /*  27 AutoVector 3                                 */
    AutoVector4_IRQHandler,         /*  28 AutoVector 4                                 */
    AutoVector5_IRQHandler,         /*  29 AutoVector 5                                 */
    AutoVector6_IRQHandler,         /*  30 AutoVector 6                                 */
    AutoVector7_IRQHandler,         /*  31 AutoVector 7                                 */
    Trap0_IRQHandler,               /*  32 Trap 0                                       */
    Trap1_IRQHandler,               /*  33 Trap 1                                       */
    Trap2_IRQHandler,               /*  34 Trap 2                                       */
    Trap3_IRQHandler,               /*  35 Trap 3                                       */
    Trap4_IRQHandler,               /*  36 Trap 4                                       */
    Trap5_IRQHandler,               /*  37 Trap 5                                       */
    Trap6_IRQHandler,               /*  38 Trap 6                                       */
    Trap7_IRQHandler,               /*  39 Trap 7                                       */
    Trap8_IRQHandler,               /*  40 Trap 8                                       */
    Trap9_IRQHandler,               /*  41 Trap 9                                       */
    Trap10_IRQHandler,              /*  42 Trap 10                                      */
    Trap11_IRQHandler,              /*  43 Trap 11                                      */
    Trap12_IRQHandler,              /*  44 Trap 12                                      */
    Trap13_IRQHandler,              /*  45 Trap 13                                      */
    Trap14_IRQHandler,              /*  46 Trap 14                                      */
    Trap15_IRQHandler,              /*  47 Trap 15                                      */
    Default_Handler,                /*  48 Reserved                                     */
    Default_Handler,                /*  49 Reserved                                     */
    Default_Handler,                /*  50 Reserved                                     */
    Default_Handler,                /*  51 Reserved                                     */
    Default_Handler,                /*  52 Reserved                                     */
    Default_Handler,                /*  53 Reserved                                     */
    Default_Handler,                /*  54 Reserved                                     */
    Default_Handler,                /*  55 Reserved                                     */
    Default_Handler,                /*  56 Reserved                                     */
    Default_Handler,                /*  57 Reserved                                     */
    Default_Handler,                /*  58 Reserved                                     */
    Default_Handler,                /*  59 Reserved                                     */
    Default_Handler,                /*  60 Reserved                                     */
    UnsuppportedInstr_IRQHandler,   /*  61                                              */
    Default_Handler,                /*  62 Reserved                                     */
    Default_Handler,                /*  63 Reserved                                     */
    Irq_IRQHandler,                 /*  64                                              */
    LVD_IRQHandler,                 /*  65                                              */
    LLWU_IRQHandler,                /*  66                                              */
    MCG_LOL_IRQHandler,             /*  67                                              */
    Flash_IRQHandler,               /*  68                                              */
    DMA_Channel0_IRQHandler,        /*  69                                              */
    DMA_Channel1_IRQHandler,        /*  70                                              */
    DMA_Channel2_IRQHandler,        /*  71                                              */
    DMA_Channel3_IRQHandler,        /*  72                                              */
    USB0_IRQHandler,                /*  73                                              */
    RNGB_IRQHandler,                /*  74 Reserved                                     */
    FTM1_Fault_IRQHandler,          /*  75                                              */
    FTM1_Ch0_IRQHandler,            /*  76                                              */
    FTM1_Ch1_IRQHandler,            /*  77                                              */
    FTM1_Ch2_IRQHandler,            /*  78                                              */
    FTM1_Ch3_IRQHandler,            /*  79                                              */
    FTM1_Ch4_IRQHandler,            /*  80                                              */
    FTM1_Ch5_IRQHandler,            /*  81                                              */
    CMP0_IRQHandler,                /*  82                                              */
    FTM0_Fault_IRQHandler,          /*  83                                              */
    FTM0_Ch0_IRQHandler,            /*  84                                              */
    FTM0_Ch1_IRQHandler,            /*  85                                              */
    SPI0_IRQHandler,                /*  86                                              */
    UART0_IRQHandler,               /*  87                                              */
    I2S_Rx_IRQHandler,              /*  88                                              */
    I2S_Tx_IRQHandler,              /*  89                                              */
    I2C0_IRQHandler,                /*  90                                              */
    I2C2_IRQHandler,                /*  91                                              */
    SPI1_IRQHandler,                /*  92                                              */
    UART1_IRQHandler,               /*  93                                              */
    I2C1_IRQHandler,                /*  94                                              */
    I2C3_IRQHandler,                /*  95                                              */
    ADC0_IRQHandler,                /*  96                                              */
    TSI0_IRQHandler,                /*  97                                              */
    DAC0_IRQHandler,                /*  98                                              */
    CMT_IRQHandler,                 /*  99                                              */
    PDB0_IRQHandler,                /* 100                                              */
    LPTMR0_IRQHandler,              /* 101                                              */
    LPTMR1_IRQHandler,              /* 102                                              */
    L7_SWI_IRQHandler,              /* 103                                              */
    L6_SWI_IRQHandler,              /* 104                                              */
    L5_SWI_IRQHandler,              /* 105                                              */
    L4_SWI_IRQHandler,              /* 106                                              */
    L3_SWI_IRQHandler,              /* 107                                              */
    L2_SWI_IRQHandler,              /* 108                                              */
    L1_SWI_IRQHandler,              /* 109                                              */
    MTIM0_IRQHandler,               /* 110                                              */
    USBDCD_IRQHandler,              /* 111                                              */
    PORTA_B_IRQHandler,             /* 112                                              */
    PORTD_C_IRQHandler,             /* 113                                              */
    PORTF_E_IRQHandler,             /* 114                                              */
   };
