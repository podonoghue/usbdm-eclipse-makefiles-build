/*
 * pit.h
 *
 *  Created on: 12/11/2013
 *      Author: podonoghue
 */

#ifndef MTIM0_H_
#define MTIM0_H_

#include "clock.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MTIM0_CLKS_VALUE   (0)

#if (MTIM0_CLKS_VALUE == 0)
#define MTIM0_CLOCK_FREQUENCY_BASE     SYSTEM_BUS_CLOCK
#elif (MTIM0_CLKS_VALUE == 1)
#define MTIM0_CLOCK_FREQUENCY_BASE     SYSTEM_XCLK_CLOCK        // not defined
#elif (MTIM0_CLKS_VALUE == 2)
#define MTIM0_CLOCK_FREQUENCY_BASE     SYSTEM_TCLK_RISING_CLOCK // not defined
#elif (MTIM0_CLKS_VALUE == 3)
#define MTIM0_CLOCK_FREQUENCY_BASE     SYSTEM_TCLK_FALLIN_CLOCK // not defined
#else
#error "MTIM0_CLKS_VALUE is invalid"
#endif

#define MTIM0_PRESCALE_VALUE   (2)
#define MTIM0_CLOCK_FREQUENCY  (MTIM0_CLOCK_FREQUENCY_BASE/(1<<MTIM0_PRESCALE_VALUE))

#if ((MTIM0_CLOCK_FREQUENCY/1000000) > 0)
   //! Macro to convert microseconds to PIT ticks
   // Only usable with a fast clock
   #define MTIM0_MICROSECOND_TO_TICKS(us) (((us)*(MTIM0_CLOCK_FREQUENCY/1000))/1000)
   //! Macro to convert milliseconds to PIT ticks
   #define MTIM0_MILLISECOND_TO_TICKS(ms)  ((ms)*(MTIM0_CLOCK_FREQUENCY/1000))
#else
   //! Macro to convert milliseconds to PIT ticks
   #define MTIM0_MILLISECOND_TO_TICKS(ms)  (((ms)*MTIM0_CLOCK_FREQUENCY)/1000)
#endif

void mtim_initialise(uint32_t modulo /* ticks */);
void mtim_finalise();

#ifndef MTIM0_USES_NAKED_HANDLERS
   typedef void (*MTIMCallbackFunction)(void);
   MTIMCallbackFunction mtim_setCallbackFunction(MTIMCallbackFunction callback);
#endif

#ifdef __cplusplus
}
#endif

#endif /* MTIM0_H_ */
