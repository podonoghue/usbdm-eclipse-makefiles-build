/*
 * clock.h
 *
 *  Created on: Nov 6, 2012
 *      Author: podonoghue
 */

#ifndef CLOCK_H_
#define CLOCK_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Clock sources
 */
// Fast Internal Reference Clock (Fast IRC) frequency
#define _FAST_IRC_CLOCK               (3300000UL) // Hz (nominal)

// Slow Internal Reference Clock (Slow IRC) frequency
#define _SLOW_IRC_CLOCK                 (32768UL) // Hz (nominal)

// External crystal for oscillator (0 for none)
#define _CRYSTAL_CLOCK                (8000000UL) // Hz

// Externally supplied clock to EXTAL pin (0 for none)
#define _EXTERNAL_CLOCK                     (0UL) // Hz

// _ERC_CLOCK ==============================
// External Reference Clock

#if (_EXTERNAL_CLOCK != 0)
#define _ERC_CLOCK _EXTERNAL_CLOCK // _ERC_CLOCK from external clock
#define MCG_C2_EREFS_VALUE    (0)
#elif (_CRYSTAL_CLOCK != 0)
#define _ERC_CLOCK _CRYSTAL_CLOCK  // _ERC_CLOCK from crystal oscillator
#define MCG_C2_EREFS_VALUE    (1)
#else
#define _ERC_CLOCK (0)             // No _ERC_CLOCK
#define MCG_C2_EREFS_VALUE    (0)
#endif

// SYSTEM_MCGIRCLK_CLOCK ==============================

#define MCG_C1_IRCLKEN_VALUE  (1) // MCGIRCLK enable 0,1 -> disable/enabled
#define MCG_C1_IREFSTEN_VALUE (1) // MCGIRCLK enable in stop mode 0,1 -> disable/enabled
#define MCG_C2_IRCS_VALUE     (0) // Select MCGIRCLK source 0,1 -> Slow,Fast IRC

#if (MCG_C2_IRCS_VALUE == 0)
#define _IRCSCLK_CLOCK (_SLOW_IRC_CLOCK)
#elif (MCG_C2_IRCS_VALUE == 1)
#define _IRCSCLK_CLOCK (_FAST_IRC_CLOCK/2)
#else
#error  "Fix MCG_C2_IRCS_VALUE value in Clock.c"
#endif

#if (MCG_C1_IRCLKEN_VALUE == 0)
#define SYSTEM_MCGIRCLK_CLOCK (0)
#elif (MCG_C1_IRCLKEN_VALUE == 1)
#define SYSTEM_MCGIRCLK_CLOCK _IRCSCLK_CLOCK
#else
#error  "Fix MCG_C1_IRCLKEN_VALUE value in Clock.c"
#endif

// ERC_AFTER_FRDIV_CLOCK  ==============================

// 0,1,2 -> low (32kHz-40kHz), high (1-8MHz), very-high (8-32MHz) range XTAL
#if  (_CRYSTAL_CLOCK == 0UL) || ((_CRYSTAL_CLOCK >= 32000UL)   && (_CRYSTAL_CLOCK <= 40000UL))
#define MCG_C2_RANGE_VALUE    (0)
#elif (_CRYSTAL_CLOCK > 1000000UL) && (_CRYSTAL_CLOCK <= 8000000UL)
#define MCG_C2_RANGE_VALUE    (1)
#elif (_CRYSTAL_CLOCK > 8000000UL) && (_CRYSTAL_CLOCK <= 320000000UL)
#define MCG_C2_RANGE_VALUE    (2)
#else
#error  "Fix _CRYSTAL_CLOCK value in Clock.c"
#endif


#define MCG_C1_FRDIV_VALUE  (3) // Divider for External Reference Clock

#if (MCG_C2_RANGE_VALUE == 0)
#define ERC_AFTER_FRDIV_CLOCK (_ERC_CLOCK/(1<<MCG_C1_FRDIV_VALUE))
#else
#define ERC_AFTER_FRDIV_CLOCK (_ERC_CLOCK/(1<<(MCG_C1_FRDIV_VALUE+5)))
#endif

// IRC_CLOCK  ==============================

#define MCG_C1_IREFS_VALUE (0) // Internal reference select 0,1 -> External reference clock, Slow IRC

#if (ERC_AFTER_FRDIV_CLOCK == 0) && (MCG_C1_IREFS_VALUE == 0)
#undef MCG_C1_IREFS_VALUE
#define MCG_C1_IREFS_VALUE (1) // Internal reference select 1 -> force to Slow IRC
#warning "Check External reference selected when none available"
#endif

#if (MCG_C1_IREFS_VALUE == 0)
#define IRC_CLOCK ERC_AFTER_FRDIV_CLOCK
#elif (MCG_C1_IREFS_VALUE == 1)
#define IRC_CLOCK _SLOW_IRC_CLOCK
#else
#error "Check MCG_C1_IREFS_VALUE value in clock.h"
#endif

#if (IRC_CLOCK > 39062) || (IRC_CLOCK < 31250)
#error "Internal reference clock must be in range 31.25 kHz to 39.0625 kHz"
#endif

// SYSTEM_MCGFFCLK_CLOCK  ==============================

#define SYSTEM_MCGFFCLK_CLOCK (IRC_CLOCK/2)

// SYSTEM_MCGFLLCLK_CLOCK  ==============================

// Select FLL bandwidth - 0,1 -> narrow,wide frequency range
#define MCG_C4_DMX32_VALUE (0)

// Select FLL Frequency Range - 0,1,2,3 -> low,mid,mid-high,high
#define MCG_C4_DRST_DRS_VALUE (3)

#if ((MCG_C4_DMX32_VALUE == 0) && ((IRC_CLOCK < 31250) || (IRC_CLOCK > 39063))) || \
    ((MCG_C4_DMX32_VALUE != 0) && ((IRC_CLOCK < 32700) || (IRC_CLOCK > 32800)))
#warning "IRC_CLOCK is out of range"
#define FLL_INVALID
#endif

#if (MCG_C4_DMX32_VALUE == 0)
#define SYSTEM_MCGFLLCLK_CLOCK (640*(MCG_C4_DRST_DRS_VALUE+1)*IRC_CLOCK)
#elif (MCG_C4_DMX32_VALUE == 1)
#define SYSTEM_MCGFLLCLK_CLOCK (732*(MCG_C4_DRST_DRS_VALUE+1)*IRC_CLOCK)
#else
#error "Check MCG_C4_DMX32_VALUE in clock.c"
#endif

// SYSTEM_MCGPLLCLK_CLOCK  ==============================

// Select PLL External Reference Divider - 0-24 -> 1-25
// Selects the amount to divide down the external reference clock for the PLL.
// The resulting frequency must be in the range of 2 MHz to 4 MHz.
#define MCG_C5_PRDIV_VALUE      (1)
#define MCG_C5_PLLCLKEN_VALUE    (0)

#define PLL_INPUT_CLOCK (_ERC_CLOCK/(MCG_C5_PRDIV_VALUE+1))

#if (MCG_C5_PLLCLKEN_VALUE != 0) && ((PLL_INPUT_CLOCK < 2000000) || (PLL_INPUT_CLOCK > 4000000))
#error "Check MCG_C5_PLLCLKEN_VALUE & MCG_C5_PRDIV0_VALUE in clock.c"
#endif

// Select the amount to divide the VCO output of the PLL - 0-31 -> 24-55
// This determine the multiplication factor of the PLL
#define MCG_C6_VDIV_VALUE (0)
#define PLL_FACTOR (MCG_C6_VDIV_VALUE+24)

#define SYSTEM_MCGPLLCLK_CLOCK (PLL_INPUT_CLOCK*PLL_FACTOR)

#if (_SYTEM_MCGPLLCLK_CLOCK > 96000000)
#error "Check MCG_C5_PRDIV0_VALUE, MCG_C6_VDIV0_VALUE in clock.c"
#endif

// SYSTEM_MCGOUTCLK_CLOCK  ==============================

#if (_CRYSTAL_CLOCK == 0) && (_EXTERNAL_CLOCK == 0)
// Choose between FLL/PLL clock 0,1 -> FLL,PLL
#define MCG_C6_PLLS_VALUE  (0)
#else
// Choose between FLL/PLL clock 0,1 -> FLL,PLL
#define MCG_C6_PLLS_VALUE  (1)
#endif

#if (MCG_C6_PLLS_VALUE == 0) && defined FLL_INVALID
#error "FLL being used when invalid"
#endif

// Clock source for MCGOUTCLK 0,1,2,3 -> FLL or PLL, IRC, ERC, -
#define MCG_C1_CLKS_VALUE  (0)

#if (MCG_C1_CLKS_VALUE == 0)
#if (MCG_C6_PLLS_VALUE == 0)
#define SYSTEM_MCGOUTCLK_CLOCK SYSTEM_MCGFLLCLK_CLOCK
#elif (MCG_C6_PLLS_VALUE == 1)
#define SYSTEM_MCGOUTCLK_CLOCK SYSTEM_MCGPLLCLK_CLOCK
#else
#error "Check MCG_C1_CLKS_VALUE in clock.c"
#endif
#elif (MCG_C1_CLKS_VALUE == 1)
#define SYSTEM_MCGOUTCLK_CLOCK _IRCSCLK_CLOCK
#elif (MCG_C1_CLKS_VALUE == 2)
#define SYSTEM_MCGOUTCLK_CLOCK _ERC_CLOCK
#elif (MCG_C1_CLKS_VALUE == 3)
#define SYSTEM_MCGOUTCLK_CLOCK
#else
#error "Check MCG_C1_CLKS_VALUE in clock.c"
#endif

#if (SYSTEM_MCGOUTCLK_CLOCK>100000000)
#error "Adjust SYSTEM_MCGOUTCLK_CLOCK is too high"
#endif

#ifndef SIM_CLKDIV0_OUTDIV_VALUE
#if (SYSTEM_MCGOUTCLK_CLOCK>50)
#define SIM_CLKDIV0_OUTDIV_VALUE 1
#else
#define SIM_CLKDIV0_OUTDIV_VALUE 0
#endif
#endif

#define SYSTEM_CORE_CLOCK (SYSTEM_MCGOUTCLK_CLOCK/(1+SIM_CLKDIV0_OUTDIV_VALUE))
#define SYSTEM_BUS_CLOCK  (SYSTEM_CORE_CLOCK/2)

#if (SYSTEM_CPUCLK>50000000)
#error "Adjust SYSTEM_CPUCLK is too high, adjust SIM_CLKDIV0_OUTDIV_VALUE"
#endif

/*
 * Controls whether the FLL or PLL is disabled in BLPI and BLPE modes. In FBE or PBE modes, setting this
 * bit to 1 will transition the MCG into BLPE mode; in FBI mode, setting this bit to 1 will transition the MCG
 * into BLPI mode. In any other MCG mode, LP bit has no affect.
 */
#define MCG_C2_LP_VALUE    (1)

/*
 * High Gain Oscillator Select
 */
#define MCG_C2_HGO_VALUE   (0) // 0,1 -> low power,high gain crystal oscillator

/*
 * After all the above these are the only one that are intended for external use
 */
extern const uint32_t SystemCoreClock; // Hz
extern const uint32_t SystemBusClock;  // Hz

//#define SYSTEM_MCGIRCLK_CLOCK                 (32768UL) // Hz
//#define SYSTEM_MCGFFCLK_CLOCK               (32768UL/2) // Hz
//#define SYSTEM_MCGFLLCLK_CLOCK             (83886080UL) // Hz
//#define SYSTEM_MCGPLLCLK_CLOCK                    (0UL) // Hz
//#define SYSTEM_MCGOUTCLK_CLOCK             (83886080UL) // Hz
//
//#define SYSTEM_CORE_CLOCK                  (48000000UL) // Hz
//#define SYSTEM_BUS_CLOCK                   (24000000UL) // Hz

#define SYSTEM_LPO_CLOCK                       (1000UL) // Hz (nominal)

void clock_initialise(void);

#ifdef __cplusplus
}
#endif

#endif /* CLOCK_H_ */
