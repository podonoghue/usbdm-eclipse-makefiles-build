/*
 * Example code for ADC on Kinetis devices
 */
#include <stddef.h>
#include "derivative.h" /* include peripheral declarations */
#include "clock.h"
#include "adc0.h"
#include "utilities.h"

#define ADC_CLOCK_DIVIDER_FACTOR (1<<ADC_CFG1_ADIV_VALUE)

#define ADC_CFG1_ADLPC(x)     (((x)<<ADC_CFG1_ADLPC_SHIFT)&ADC_CFG1_ADLPC_MASK)
#define ADC_CFG2_ADHSC(x)     (((x)<<ADC_CFG2_ADHSC_SHIFT)&ADC_CFG2_ADHSC_MASK)
#define ADC_CFG1_ADLSMP(x)    (((x)<<ADC_CFG1_ADLSMP_SHIFT)&ADC_CFG1_ADLSMP_MASK)

// ADC_CFG1
#define ADC_CFG1_ADIV_VALUE      (3)    // Internal ADC clock divider [0..3]
#define ADC_CFG1_ADICLK_VALUE    (1)    // Clock Source [0,1,2,3 -> bus clock, bus clock/2, OSC2ERCLK, ADC internal
#define ADC_CFG1_ADLPC_VALUE     (0)    // Low power mode [0,1 -> -, low power]
#define ADC_CFG1_ADLSMP_VALUE    (1)    // Sample time [0,1 -> short,long], see ADLSTS as well
//#define ADC_CFG1_MODE_VALUE    (0)    // Mode [0,1,2,3 -> 8/9 bit, 12/13 bit, 10/11 bit, 16 bit]

// ADC_CFG2
#define ADC_CFG2_ADHSC_VALUE     (0)    // High power mode [0,1 -> -, high power]
#define ADC_CFG2_ADLSTS_VALUE    (0)    // Long sample time [0,1,2,3 -> +20,+12,+6,+2 ADCK cycles]

// ADC_SC2

#if (ADC_CFG1_ADICLK_VALUE == 0)
#define ADC_CLOCK_BASE (SYSTEM_BUS_CLOCK)
#elif (ADC_CFG1_ADICLK_VALUE == 1)
#define ADC_CLOCK_BASE (SYSTEM_BUS_CLOCK/2)
#elif (ADC_CFG1_ADICLK_VALUE == 2)
#define ADC_CLOCK_BASE (SYSTEM_OSCERCLK_CLOCK)
#elif (ADC_CFG1_ADICLK_VALUE == 3)
#if ((ADC_CFG1_ADLPC_VALUE=0)&&(ADC_CFG2_ADHSC_VALUE==0))
#define ADC_CLOCK_BASE (2400000)
#elif ((ADC_CFG1_ADLPC_VALUE=1)&&(ADC_CFG2_ADHSC_VALUE==0))
#define ADC_CLOCK_BASE (4000000)
#elif ((ADC_CFG1_ADLPC_VALUE=1)&&(ADC_CFG2_ADHSC_VALUE==1))
#define ADC_CLOCK_BASE (5200000)
#elif ((ADC_CFG1_ADLPC_VALUE=0)&&(ADC_CFG2_ADHSC_VALUE==0))
#define ADC_CLOCK_BASE (6200000)
#endif
#else
#error "Check ADC_CFG1_ADICLK_VALUE in adc.c"
#endif

#define ADC_CLOCK (ADC_CLOCK_BASE/ADC_CLOCK_DIVIDER_FACTOR)

/*
 * Initialisation the ADC
 */
void adc0_initialise(adc_precision precision) {

   // Enable clock to ADC
   SIM_SCGC2 |= SIM_SCGC2_ADC_MASK;

   // Configure ADC for software triggered conversion
   ADC0_CFG1 = precision|ADC_CFG1_ADIV(ADC_CFG1_ADIV_VALUE)|ADC_CFG1_ADLSMP(ADC_CFG1_ADLSMP_VALUE)|ADC_CFG1_ADICLK(ADC_CFG1_ADICLK_VALUE);
   ADC0_SC2  = 0;
   ADC0_CFG2 = ADC_CFG2_ADLSTS(0)|ADC_CFG2_ADHSC(ADC_CFG2_ADHSC_VALUE)|ADC_CFG2_ADLSTS(ADC_CFG2_ADLSTS_VALUE);
}

/*
 * Initiates a conversion and waits for it to complete
 *
 * @param channel - selects channel (and differential mode)
 * @param mode    - interrupt or polled operation
 *
 * @return - the result of the conversion (if polled)
 */
int adc0_doConversion(adc_channel_select channel, adc_mode mode) {

   // Trigger conversion
   ADC0_SC1A = ADC_SC1_ADCH(channel)|mode;
   if (mode==adc_interrupt) {
      // Interrupt mode - don't wait for result
      return 0;
   }
   while ((ADC0_SC1A&ADC_SC1_COCO_MASK) == 0) {
   }
   return (int)(uint16_t)ADC0_RA;
}

#ifndef ADC0_USES_NAKED_HANDLERS

static ADCCallbackFunction adcCallback = NULL;

/*! Initialises FTM0 for Input capture/Output compare
 *
 *  @param callback   - The function to handle the ADC complete interrupt
 */
ADCCallbackFunction adc0_setCallbackFunction(ADCCallbackFunction callback) {

   ADCCallbackFunction temp = adcCallback;
   adcCallback = callback;
   INTC_EnableIrq(Vadc0);
   return temp;
}

__attribute__((__interrupt__))
void ADC0_IRQHandler(void) {
   // Clear flag
   uint32_t conversionValue = ADC0_RA;
   if (adcCallback != NULL) {
      // Do callback
      // Zero extend
      adcCallback((int)(uint16_t)conversionValue);
   }
}
#endif
