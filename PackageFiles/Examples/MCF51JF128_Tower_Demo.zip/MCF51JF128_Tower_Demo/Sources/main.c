/*
 ============================================================================
 * main.c
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include <stdio.h>
#include <stdbool.h>
#include "derivative.h"
#include "leds.h"
#include "utilities.h"
#include "mtim.h"
#include "lptmr.h"
#include "ftm0.h"
#include "adc0.h"

// Miscellaneous ==============================================================

void greenLedToggleEnable(void) {
   static bool oddEven = true;
   if (oddEven) {
      greenLedEnable();
   }
   else {
      greenLedDisable();
   }
   oddEven = !oddEven;
}

// LPTMR ==============================================================

#define LPTMR_INTERVAL LPTMR_MILLISECOND_TO_TICKS(1000)

#if (LPTMR_INTERVAL>65536)
#error "LPTMR Value is too large"
#endif


// PWM0/FTM0 ==============================================================

#define FTM0_CH0_PERIOD FTM0_MILLISECONDS_TO_TICKS(10)
#if FTM0_CH0_PERIOD > 65535
#error "FTM0_CH0_PERIOD is too large"
#endif
#if FTM0_CH0_PERIOD < 10
#error "FTM0_CH0_PERIOD is too small"
#endif

#define FTM0_CH1_PERIOD FTM0_MILLISECONDS_TO_TICKS(200)
#if FTM0_CH1_PERIOD > 65535
#error "FTM0_CH1_PERIOD is too large"
#endif
#if FTM0_CH1_PERIOD < 40
#error "FTM0_CH1_PERIOD is too small"
#endif

#define PWM0_PERIOD (FTM0_MILLISECONDS_TO_TICKS(10000))

#if (PWM0_PERIOD<200)
#error "PWM0_PERIOD is too small (resolution < 1%)"
#endif
#if (PWM0_PERIOD>65535)
#error "PWM0_PERIOD is too large"
#endif

// PTD2(Fn4) = FTM0_CH0 = PWM0_CH0
#define FTM0_CH0_PTxPF        MXC_PTDPF3
#define FTM0_CH0_PTxPF_n(x)   MXC_PTDPF3_D2(x)
#define FTM0_CH0_PIN_NUM      2
#define FTM0_CH0_FN           4
#define FTM0_CH0_CLOCK_MASK   SIM_SCGC6_PORTD_MASK

// PTD3(Fn4) = FTM0_CH1 = PWM0_CH1
#define FTM0_CH1_PTxPF        MXC_PTDPF3
#define FTM0_CH2_PTxPF_n(x)   MXC_PTDPF3_D3(x)
#define FTM0_CH1_PIN_NUM      3
#define FTM0_CH1_FN           4
#define FTM0_CH1_CLOCK_MASK   SIM_SCGC6_PORTD_MASK

/*
 * Configures pins as FTM0 output channels
 */
void configureFTMPins(void) {
   SIM_SCGC6 |= FTM0_CH0_CLOCK_MASK|FTM0_CH1_CLOCK_MASK;
   FTM0_CH0_PTxPF = (FTM0_CH0_PTxPF & ~FTM0_CH0_PTxPF_n(0xF))|FTM0_CH0_PTxPF_n(FTM0_CH0_FN);
   FTM0_CH0_PTxPF = (FTM0_CH0_PTxPF & ~FTM0_CH0_PTxPF_n(0xF))|FTM0_CH0_PTxPF_n(FTM0_CH0_FN);
}

// PIT ==============================================================

#define MTIM0_PERIOD MTIM0_MICROSECOND_TO_TICKS(1000)
#if (MTIM0_PERIOD < 100)
#error "MTIM0_PERIOD is too small"
#endif
#if (MTIM0_PERIOD > 65535)
#error "MTIM0_PERIOD is too large"
#endif

// ADC ==============================================================

#define ADC_INTERVAL LPTMR_MILLISECOND_TO_TICKS(1000)
#if (ADC_INTERVAL > 65535)
#error "ADC_INTERVAL is too large"
#endif

#define POTENTIOMETER adc_channel_se12

#define ADC_OUTPUT_RANGE ((1<<12)-1) // 12 bit
#define ADC_INPUT_HIGH   (3300)      // Scaled by x1000
#define ADC_INPUT_LOW    (0)

// PTD5(Fn0) = ADC0_SE12 = Potentiometer
#define ADC0_SE12_PTxPF        MXC_PTDPF2
#define ADC0_SE12_PTxPF_n(x)   MXC_PTDPF2_D5(x)
#define ADC0_SE12_PIN_NUM      5
#define ADC0_SE12_FN           0
#define ADC0_SE12_CLOCK_MASK   SIM_SCGC6_PORTD_MASK

/*
 * Configures ADC pins as analogue
 */
void configureADCPins(void) {
   SIM_SCGC6      |= ADC0_SE12_CLOCK_MASK;
   ADC0_SE12_PTxPF  = (ADC0_SE12_PTxPF & ~ADC0_SE12_PTxPF_n(0xF))|ADC0_SE12_PTxPF_n(ADC0_SE12_FN);
}

/*
 * Handler for ADC - prints out the value assuming it is from potentiometer
 *
 * @param value - value from ADC output register
 */
void adcHandler(int value) {
   greenLedToggle();
   value = ((value *(ADC_INPUT_HIGH-ADC_INPUT_LOW))/ADC_OUTPUT_RANGE)+ADC_INPUT_LOW;
   printf("Potentiometer = %d.%03d V\n", value/1000, value%1000);
}

/*
 * Triggers a conversion on the potentiometer ADC channel
 */
void adcTrigger(void) {
   // Configure next conversion
   adc0_doConversion(POTENTIOMETER, adc_interrupt);
}

int main(void) {
   printf("\n"
         "==========================\n"
         "Starting\n"
         "==========================\n");

   __set_interrupt_level(0);  // set the IRQ mask to unmask all

   led_initialise();

#if 0
   /*
    * This test configures two FTM channels to toggle their respective pins in hardware.
    * In addition the callbacks are used to pulse modulate the Green LED.
    */
   printf("FTM Base Clock = %lu Hz, FTM clock = %lu Hz, interval = %lud ticks\n", _FTM0_CLOCK_FREQUENCY_BASE, FTM0_CLOCK_FREQUENCY, PWM0_PERIOD);
   configureFTMPins();
   ftm0_initialise();
   ftm0_initialiseChannel(0,ftm_outputCompareToggle);
   ftm0_setCallbackFunction(0,greenLedToggle,FTM0_CH0_PERIOD);
   ftm0_initialiseChannel(1,ftm_outputCompareToggle);
   ftm0_setCallbackFunction(1,greenLedToggleEnable,FTM0_CH1_PERIOD);
#elif 0
   /*
    * This test configures two FTM channels as PWM with fixed duty-cycle.
    * One channel is inverted.
    * Channels are centre-aligned.
    */
   printf("FTM Base Clock = %lu Hz, FTM clock = %lu Hz, interval = %lud ticks\n", _FTM0_CLOCK_FREQUENCY_BASE, FTM0_CLOCK_FREQUENCY, PWM0_PERIOD);
   configureFTMPins();
   ftm0_initialiseAsPWM(PWM0_PERIOD, ftm_centreAlign);
   ftm0_initialiseChannel(0, ftm_pwmHighTruePulses);
   ftm0_setDutyCycle(0, 50);
   ftm0_initialiseChannel(1, ftm_pwmLowTruePulses);
   ftm0_setDutyCycle(1, 25);
#elif 0
   /*
    * This test configures the Low Power Timer (LPTMR) for a fixed period.
    * A callback is used to modulate the Green LED.
    */
   printf("LPTMR clock = %lu Hz, interval = %lu ticks\n", LPTMR_CLOCK_FREQUENCY, LPTMR_INTERVAL);
   lptmr_setCallbackFunction(greenLedToggle);
   lptmr_initialise(LPTMR_INTERVAL);
#elif 0
   /*
    * This test configures the MTIM.
    * A callback is used to pulse modulate the Green LED.
    */
   printf("MTIM clock = %lu Hz, MTIM Period = %lu\n", MTIM0_CLOCK_FREQUENCY, MTIM0_PERIOD);
   mtim_initialise(MTIM0_PERIOD);
   mtim_setCallbackFunction(greenLedToggle);
#elif 1
   /*
    * This test configures one ADC channel with interrupt on completion
    * The LPTMR callback is used to schedule the conversions.
    */
   // Initialise ADC
   adc0_initialise(adc_singleEnded12_13bitConversion);
   // Set handler
   adc0_setCallbackFunction(adcHandler);

   printf("LPTMR clock = %lu Hz, ADC interval = %lu ticks\n", LPTMR_CLOCK_FREQUENCY, ADC_INTERVAL);
   lptmr_setCallbackFunction(adcTrigger);
   lptmr_initialise(LPTMR_INTERVAL);

#elif 0
   /*
    * This test configures an ADC channel for the potentiometer on the Tower-JF128 board
    * It runs the ADC in polled fashion.
    */
   configureADCPins();
   adc0_initialise(adc_singleEnded12_13bitConversion);

   for (;;) {
      adcHandler(adc0_doConversion(POTENTIOMETER, adc_polled));
   }
#endif

   for(;;) {
      __asm__("nop");
//      __stop(0xFFFF);
   }
}
