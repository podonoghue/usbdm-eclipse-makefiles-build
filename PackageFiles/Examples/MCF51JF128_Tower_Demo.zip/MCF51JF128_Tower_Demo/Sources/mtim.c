/*
 ============================================================================
 * pit.c
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include <stddef.h>
#include "derivative.h"
#include "leds.h"
#include "utilities.h"
#include "mtim.h"

/*!=========================================================================
 *
 *   Modulo Timer (MTIM) routines
 *
 *=========================================================================*/

/*! Initialises a MTIM channel
 *
 * @param modulo - MTIM interval (use MTIM0_MILLISECOND_TO_TICKS() macro)
 *
 * Configures:
 *   - Enables MTIM clock
 *   - Sets MTIM modulo value
 */
void mtim_initialise(uint32_t modulo) {

   // Enable clock to MTIM interface
   SIM_SCGC3  |= SIM_SCGC3_MTIM_MASK;

   // Set modulo
   MTIM0_MODH = (uint8_t)(modulo>>8);
   MTIM0_MODL = (uint8_t)modulo;

   // Enable MTIM module
   MTIM0_CLK   = MTIM_CLK_CLKS(MTIM0_CLKS_VALUE)|MTIM_CLK_PS(MTIM0_PRESCALE_VALUE);
   MTIM0_SC    = MTIM_SC_TRST_MASK;

   // Enable MTIM interrupts in NVIC (all channels share ISR)
   INTC_EnableIrq(Vmtim0);
}

/*!
 *  Disable MTIM
 *
 */
void mtim_finalise(void) {

   // Enable clock to MTIM interface
   SIM_SCGC3  |= SIM_SCGC3_MTIM_MASK;
   MTIM0_SC    = MTIM_SC_TSTP_MASK|MTIM_SC_TRST_MASK;
}

#ifndef MTIM0_USES_NAKED_HANDLERS

//! Pointer to MTIM callback functions
static MTIMCallbackFunction callbackFunction = NULL;

/*!
 *   Set MTIM interrupt callback
 *
 *   @param callback - The callback function to execute on interrupt
 *
 *   @return - previous callback
 */
MTIMCallbackFunction mtim_setCallbackFunction(MTIMCallbackFunction callback) {
   MTIMCallbackFunction temp = callbackFunction;
   callbackFunction = callback;
   MTIM0_SC |= MTIM_SC_TOIE_MASK;
   return temp;
}

/*!
 *  MTIM Channel 0 Handler
 *
 *   Calls MTIM Channel 0 callback
 */
__attribute__((interrupt))
void MTIM0_IRQHandler(void) {
    // Clear the interrupt request from MTIM Channel 0
   MTIM0_SC &= ~MTIM_SC_TOF_MASK;
   // Do callback
   if (callbackFunction != NULL) {
      callbackFunction();
   }
}

#endif
