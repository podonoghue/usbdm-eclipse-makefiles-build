/*
 *  Include the derivative-specific header file
 */
#include <MCF52233.h>
