/*
 * SysTick.cpp
 *
 *  Created on: 10 Aug 2014
 *      Author: podonoghue
 */
#include <stdint.h>
#include "derivative.h"
#include "SysTick.h"
#include "Gpio.h"

static uint32_t ticks;

#include "Seeed_SLD00200P.h"

void SysTick_Handler(void) {
   ticks++;
   TOGGLE.toggle();  // Used to check calibration
}

uint32_t getTicks() {
   return ticks;
}
