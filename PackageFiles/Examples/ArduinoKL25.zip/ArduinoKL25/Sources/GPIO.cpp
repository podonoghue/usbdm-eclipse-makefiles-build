 /**
  * @file     GPIO.cpp
  *
  * @brief   Pin declarations for MKL25Z4
  */

#include "utilities.h"
#include "GPIO.h"

#define ADC(num) CONCAT2_(ADC,num)
#define FTM(num) CONCAT2_(FTM,num)
#define TPM(num) CONCAT2_(TPM,num)


const DigitalIO digitalIO_PTA0     = {&PCR(PTA0_PORT,   PTA0_NUM),  GPIO(PTA0_PORT),  PORT_CLOCK_MASK(PTA0_PORT),  (1UL<<PTA0_NUM)};
const DigitalIO digitalIO_PTA1     = {&PCR(PTA1_PORT,   PTA1_NUM),  GPIO(PTA1_PORT),  PORT_CLOCK_MASK(PTA1_PORT),  (1UL<<PTA1_NUM)};
const DigitalIO digitalIO_PTA2     = {&PCR(PTA2_PORT,   PTA2_NUM),  GPIO(PTA2_PORT),  PORT_CLOCK_MASK(PTA2_PORT),  (1UL<<PTA2_NUM)};
const DigitalIO digitalIO_PTA3     = {&PCR(PTA3_PORT,   PTA3_NUM),  GPIO(PTA3_PORT),  PORT_CLOCK_MASK(PTA3_PORT),  (1UL<<PTA3_NUM)};
const DigitalIO digitalIO_PTA4     = {&PCR(PTA4_PORT,   PTA4_NUM),  GPIO(PTA4_PORT),  PORT_CLOCK_MASK(PTA4_PORT),  (1UL<<PTA4_NUM)};
const DigitalIO digitalIO_PTA5     = {&PCR(PTA5_PORT,   PTA5_NUM),  GPIO(PTA5_PORT),  PORT_CLOCK_MASK(PTA5_PORT),  (1UL<<PTA5_NUM)};
const DigitalIO digitalIO_PTA12    = {&PCR(PTA12_PORT,  PTA12_NUM), GPIO(PTA12_PORT), PORT_CLOCK_MASK(PTA12_PORT), (1UL<<PTA12_NUM)};
const DigitalIO digitalIO_PTA13    = {&PCR(PTA13_PORT,  PTA13_NUM), GPIO(PTA13_PORT), PORT_CLOCK_MASK(PTA13_PORT), (1UL<<PTA13_NUM)};
const DigitalIO digitalIO_PTA14    = {&PCR(PTA14_PORT,  PTA14_NUM), GPIO(PTA14_PORT), PORT_CLOCK_MASK(PTA14_PORT), (1UL<<PTA14_NUM)};
const DigitalIO digitalIO_PTA15    = {&PCR(PTA15_PORT,  PTA15_NUM), GPIO(PTA15_PORT), PORT_CLOCK_MASK(PTA15_PORT), (1UL<<PTA15_NUM)};
const DigitalIO digitalIO_PTA16    = {&PCR(PTA16_PORT,  PTA16_NUM), GPIO(PTA16_PORT), PORT_CLOCK_MASK(PTA16_PORT), (1UL<<PTA16_NUM)};
const DigitalIO digitalIO_PTA17    = {&PCR(PTA17_PORT,  PTA17_NUM), GPIO(PTA17_PORT), PORT_CLOCK_MASK(PTA17_PORT), (1UL<<PTA17_NUM)};
const DigitalIO digitalIO_PTA18    = {&PCR(PTA18_PORT,  PTA18_NUM), GPIO(PTA18_PORT), PORT_CLOCK_MASK(PTA18_PORT), (1UL<<PTA18_NUM)};
const DigitalIO digitalIO_PTA19    = {&PCR(PTA19_PORT,  PTA19_NUM), GPIO(PTA19_PORT), PORT_CLOCK_MASK(PTA19_PORT), (1UL<<PTA19_NUM)};
const DigitalIO digitalIO_PTA20    = {&PCR(PTA20_PORT,  PTA20_NUM), GPIO(PTA20_PORT), PORT_CLOCK_MASK(PTA20_PORT), (1UL<<PTA20_NUM)};
const DigitalIO digitalIO_PTB0     = {&PCR(PTB0_PORT,   PTB0_NUM),  GPIO(PTB0_PORT),  PORT_CLOCK_MASK(PTB0_PORT),  (1UL<<PTB0_NUM)};
const DigitalIO digitalIO_PTB1     = {&PCR(PTB1_PORT,   PTB1_NUM),  GPIO(PTB1_PORT),  PORT_CLOCK_MASK(PTB1_PORT),  (1UL<<PTB1_NUM)};
const DigitalIO digitalIO_PTB2     = {&PCR(PTB2_PORT,   PTB2_NUM),  GPIO(PTB2_PORT),  PORT_CLOCK_MASK(PTB2_PORT),  (1UL<<PTB2_NUM)};
const DigitalIO digitalIO_PTB3     = {&PCR(PTB3_PORT,   PTB3_NUM),  GPIO(PTB3_PORT),  PORT_CLOCK_MASK(PTB3_PORT),  (1UL<<PTB3_NUM)};
const DigitalIO digitalIO_PTB8     = {&PCR(PTB8_PORT,   PTB8_NUM),  GPIO(PTB8_PORT),  PORT_CLOCK_MASK(PTB8_PORT),  (1UL<<PTB8_NUM)};
const DigitalIO digitalIO_PTB9     = {&PCR(PTB9_PORT,   PTB9_NUM),  GPIO(PTB9_PORT),  PORT_CLOCK_MASK(PTB9_PORT),  (1UL<<PTB9_NUM)};
const DigitalIO digitalIO_PTB10    = {&PCR(PTB10_PORT,  PTB10_NUM), GPIO(PTB10_PORT), PORT_CLOCK_MASK(PTB10_PORT), (1UL<<PTB10_NUM)};
const DigitalIO digitalIO_PTB11    = {&PCR(PTB11_PORT,  PTB11_NUM), GPIO(PTB11_PORT), PORT_CLOCK_MASK(PTB11_PORT), (1UL<<PTB11_NUM)};
const DigitalIO digitalIO_PTB16    = {&PCR(PTB16_PORT,  PTB16_NUM), GPIO(PTB16_PORT), PORT_CLOCK_MASK(PTB16_PORT), (1UL<<PTB16_NUM)};
const DigitalIO digitalIO_PTB17    = {&PCR(PTB17_PORT,  PTB17_NUM), GPIO(PTB17_PORT), PORT_CLOCK_MASK(PTB17_PORT), (1UL<<PTB17_NUM)};
const DigitalIO digitalIO_PTB18    = {&PCR(PTB18_PORT,  PTB18_NUM), GPIO(PTB18_PORT), PORT_CLOCK_MASK(PTB18_PORT), (1UL<<PTB18_NUM)};
const DigitalIO digitalIO_PTB19    = {&PCR(PTB19_PORT,  PTB19_NUM), GPIO(PTB19_PORT), PORT_CLOCK_MASK(PTB19_PORT), (1UL<<PTB19_NUM)};
const DigitalIO digitalIO_PTC0     = {&PCR(PTC0_PORT,   PTC0_NUM),  GPIO(PTC0_PORT),  PORT_CLOCK_MASK(PTC0_PORT),  (1UL<<PTC0_NUM)};
const DigitalIO digitalIO_PTC1     = {&PCR(PTC1_PORT,   PTC1_NUM),  GPIO(PTC1_PORT),  PORT_CLOCK_MASK(PTC1_PORT),  (1UL<<PTC1_NUM)};
const DigitalIO digitalIO_PTC2     = {&PCR(PTC2_PORT,   PTC2_NUM),  GPIO(PTC2_PORT),  PORT_CLOCK_MASK(PTC2_PORT),  (1UL<<PTC2_NUM)};
const DigitalIO digitalIO_PTC3     = {&PCR(PTC3_PORT,   PTC3_NUM),  GPIO(PTC3_PORT),  PORT_CLOCK_MASK(PTC3_PORT),  (1UL<<PTC3_NUM)};
const DigitalIO digitalIO_PTC4     = {&PCR(PTC4_PORT,   PTC4_NUM),  GPIO(PTC4_PORT),  PORT_CLOCK_MASK(PTC4_PORT),  (1UL<<PTC4_NUM)};
const DigitalIO digitalIO_PTC5     = {&PCR(PTC5_PORT,   PTC5_NUM),  GPIO(PTC5_PORT),  PORT_CLOCK_MASK(PTC5_PORT),  (1UL<<PTC5_NUM)};
const DigitalIO digitalIO_PTC6     = {&PCR(PTC6_PORT,   PTC6_NUM),  GPIO(PTC6_PORT),  PORT_CLOCK_MASK(PTC6_PORT),  (1UL<<PTC6_NUM)};
const DigitalIO digitalIO_PTC7     = {&PCR(PTC7_PORT,   PTC7_NUM),  GPIO(PTC7_PORT),  PORT_CLOCK_MASK(PTC7_PORT),  (1UL<<PTC7_NUM)};
const DigitalIO digitalIO_PTC8     = {&PCR(PTC8_PORT,   PTC8_NUM),  GPIO(PTC8_PORT),  PORT_CLOCK_MASK(PTC8_PORT),  (1UL<<PTC8_NUM)};
const DigitalIO digitalIO_PTC9     = {&PCR(PTC9_PORT,   PTC9_NUM),  GPIO(PTC9_PORT),  PORT_CLOCK_MASK(PTC9_PORT),  (1UL<<PTC9_NUM)};
const DigitalIO digitalIO_PTC10    = {&PCR(PTC10_PORT,  PTC10_NUM), GPIO(PTC10_PORT), PORT_CLOCK_MASK(PTC10_PORT), (1UL<<PTC10_NUM)};
const DigitalIO digitalIO_PTC11    = {&PCR(PTC11_PORT,  PTC11_NUM), GPIO(PTC11_PORT), PORT_CLOCK_MASK(PTC11_PORT), (1UL<<PTC11_NUM)};
const DigitalIO digitalIO_PTC12    = {&PCR(PTC12_PORT,  PTC12_NUM), GPIO(PTC12_PORT), PORT_CLOCK_MASK(PTC12_PORT), (1UL<<PTC12_NUM)};
const DigitalIO digitalIO_PTC13    = {&PCR(PTC13_PORT,  PTC13_NUM), GPIO(PTC13_PORT), PORT_CLOCK_MASK(PTC13_PORT), (1UL<<PTC13_NUM)};
const DigitalIO digitalIO_PTC16    = {&PCR(PTC16_PORT,  PTC16_NUM), GPIO(PTC16_PORT), PORT_CLOCK_MASK(PTC16_PORT), (1UL<<PTC16_NUM)};
const DigitalIO digitalIO_PTC17    = {&PCR(PTC17_PORT,  PTC17_NUM), GPIO(PTC17_PORT), PORT_CLOCK_MASK(PTC17_PORT), (1UL<<PTC17_NUM)};
const DigitalIO digitalIO_PTD0     = {&PCR(PTD0_PORT,   PTD0_NUM),  GPIO(PTD0_PORT),  PORT_CLOCK_MASK(PTD0_PORT),  (1UL<<PTD0_NUM)};
const DigitalIO digitalIO_PTD1     = {&PCR(PTD1_PORT,   PTD1_NUM),  GPIO(PTD1_PORT),  PORT_CLOCK_MASK(PTD1_PORT),  (1UL<<PTD1_NUM)};
const DigitalIO digitalIO_PTD2     = {&PCR(PTD2_PORT,   PTD2_NUM),  GPIO(PTD2_PORT),  PORT_CLOCK_MASK(PTD2_PORT),  (1UL<<PTD2_NUM)};
const DigitalIO digitalIO_PTD3     = {&PCR(PTD3_PORT,   PTD3_NUM),  GPIO(PTD3_PORT),  PORT_CLOCK_MASK(PTD3_PORT),  (1UL<<PTD3_NUM)};
const DigitalIO digitalIO_PTD4     = {&PCR(PTD4_PORT,   PTD4_NUM),  GPIO(PTD4_PORT),  PORT_CLOCK_MASK(PTD4_PORT),  (1UL<<PTD4_NUM)};
const DigitalIO digitalIO_PTD5     = {&PCR(PTD5_PORT,   PTD5_NUM),  GPIO(PTD5_PORT),  PORT_CLOCK_MASK(PTD5_PORT),  (1UL<<PTD5_NUM)};
const DigitalIO digitalIO_PTD6     = {&PCR(PTD6_PORT,   PTD6_NUM),  GPIO(PTD6_PORT),  PORT_CLOCK_MASK(PTD6_PORT),  (1UL<<PTD6_NUM)};
const DigitalIO digitalIO_PTD7     = {&PCR(PTD7_PORT,   PTD7_NUM),  GPIO(PTD7_PORT),  PORT_CLOCK_MASK(PTD7_PORT),  (1UL<<PTD7_NUM)};
const DigitalIO digitalIO_PTE0     = {&PCR(PTE0_PORT,   PTE0_NUM),  GPIO(PTE0_PORT),  PORT_CLOCK_MASK(PTE0_PORT),  (1UL<<PTE0_NUM)};
const DigitalIO digitalIO_PTE1     = {&PCR(PTE1_PORT,   PTE1_NUM),  GPIO(PTE1_PORT),  PORT_CLOCK_MASK(PTE1_PORT),  (1UL<<PTE1_NUM)};
const DigitalIO digitalIO_PTE2     = {&PCR(PTE2_PORT,   PTE2_NUM),  GPIO(PTE2_PORT),  PORT_CLOCK_MASK(PTE2_PORT),  (1UL<<PTE2_NUM)};
const DigitalIO digitalIO_PTE3     = {&PCR(PTE3_PORT,   PTE3_NUM),  GPIO(PTE3_PORT),  PORT_CLOCK_MASK(PTE3_PORT),  (1UL<<PTE3_NUM)};
const DigitalIO digitalIO_PTE4     = {&PCR(PTE4_PORT,   PTE4_NUM),  GPIO(PTE4_PORT),  PORT_CLOCK_MASK(PTE4_PORT),  (1UL<<PTE4_NUM)};
const DigitalIO digitalIO_PTE5     = {&PCR(PTE5_PORT,   PTE5_NUM),  GPIO(PTE5_PORT),  PORT_CLOCK_MASK(PTE5_PORT),  (1UL<<PTE5_NUM)};
const DigitalIO digitalIO_PTE20    = {&PCR(PTE20_PORT,  PTE20_NUM), GPIO(PTE20_PORT), PORT_CLOCK_MASK(PTE20_PORT), (1UL<<PTE20_NUM)};
const DigitalIO digitalIO_PTE21    = {&PCR(PTE21_PORT,  PTE21_NUM), GPIO(PTE21_PORT), PORT_CLOCK_MASK(PTE21_PORT), (1UL<<PTE21_NUM)};
const DigitalIO digitalIO_PTE22    = {&PCR(PTE22_PORT,  PTE22_NUM), GPIO(PTE22_PORT), PORT_CLOCK_MASK(PTE22_PORT), (1UL<<PTE22_NUM)};
const DigitalIO digitalIO_PTE23    = {&PCR(PTE23_PORT,  PTE23_NUM), GPIO(PTE23_PORT), PORT_CLOCK_MASK(PTE23_PORT), (1UL<<PTE23_NUM)};
const DigitalIO digitalIO_PTE24    = {&PCR(PTE24_PORT,  PTE24_NUM), GPIO(PTE24_PORT), PORT_CLOCK_MASK(PTE24_PORT), (1UL<<PTE24_NUM)};
const DigitalIO digitalIO_PTE25    = {&PCR(PTE25_PORT,  PTE25_NUM), GPIO(PTE25_PORT), PORT_CLOCK_MASK(PTE25_PORT), (1UL<<PTE25_NUM)};
const DigitalIO digitalIO_PTE29    = {&PCR(PTE29_PORT,  PTE29_NUM), GPIO(PTE29_PORT), PORT_CLOCK_MASK(PTE29_PORT), (1UL<<PTE29_NUM)};
const DigitalIO digitalIO_PTE30    = {&PCR(PTE30_PORT,  PTE30_NUM), GPIO(PTE30_PORT), PORT_CLOCK_MASK(PTE30_PORT), (1UL<<PTE30_NUM)};
const DigitalIO digitalIO_PTE31    = {&PCR(PTE31_PORT,  PTE31_NUM), GPIO(PTE31_PORT), PORT_CLOCK_MASK(PTE31_PORT), (1UL<<PTE31_NUM)};
const AnalogueIO analogueIO_PTB0        = {&digitalIO_PTB0,  ADC(PTB0_ADC_NUM),  PTB0_ADC_CH};
const AnalogueIO analogueIO_PTB1        = {&digitalIO_PTB1,  ADC(PTB1_ADC_NUM),  PTB1_ADC_CH};
const AnalogueIO analogueIO_PTB2        = {&digitalIO_PTB2,  ADC(PTB2_ADC_NUM),  PTB2_ADC_CH};
const AnalogueIO analogueIO_PTB3        = {&digitalIO_PTB3,  ADC(PTB3_ADC_NUM),  PTB3_ADC_CH};
const AnalogueIO analogueIO_PTC0        = {&digitalIO_PTC0,  ADC(PTC0_ADC_NUM),  PTC0_ADC_CH};
const AnalogueIO analogueIO_PTC1        = {&digitalIO_PTC1,  ADC(PTC1_ADC_NUM),  PTC1_ADC_CH};
const AnalogueIO analogueIO_PTC2        = {&digitalIO_PTC2,  ADC(PTC2_ADC_NUM),  PTC2_ADC_CH};
const AnalogueIO analogueIO_PTD1        = {&digitalIO_PTD1,  ADC(PTD1_ADC_NUM),  PTD1_ADC_CH};
const AnalogueIO analogueIO_PTD5        = {&digitalIO_PTD5,  ADC(PTD5_ADC_NUM),  PTD5_ADC_CH};
const AnalogueIO analogueIO_PTD6        = {&digitalIO_PTD6,  ADC(PTD6_ADC_NUM),  PTD6_ADC_CH};
const AnalogueIO analogueIO_PTE20       = {&digitalIO_PTE20, ADC(PTE20_ADC_NUM), PTE20_ADC_CH};
const AnalogueIO analogueIO_PTE22       = {&digitalIO_PTE22, ADC(PTE22_ADC_NUM), PTE22_ADC_CH};
const AnalogueIO analogueIO_PTE29       = {&digitalIO_PTE29, ADC(PTE29_ADC_NUM), PTE29_ADC_CH};
const AnalogueIO analogueIO_PTE30       = {&digitalIO_PTE30, ADC(PTE30_ADC_NUM), PTE30_ADC_CH};
#if TPM0_5_SEL == 1
const PwmIO  pwmIO_PTA0      = {&digitalIO_PTA0,   (volatile TPM_Type*)TPM(PTA0_TPM_NUM),PTA0_TPM_CH,   PORT_PCR_MUX(PTA0_TPM_FN)};
#endif
#if TPM2_0_SEL == 1
const PwmIO  pwmIO_PTA1      = {&digitalIO_PTA1,   (volatile TPM_Type*)TPM(PTA1_TPM_NUM),PTA1_TPM_CH,   PORT_PCR_MUX(PTA1_TPM_FN)};
#endif
#if TPM2_1_SEL == 1
const PwmIO  pwmIO_PTA2      = {&digitalIO_PTA2,   (volatile TPM_Type*)TPM(PTA2_TPM_NUM),PTA2_TPM_CH,   PORT_PCR_MUX(PTA2_TPM_FN)};
#endif
#if TPM0_0_SEL == 1
const PwmIO  pwmIO_PTA3      = {&digitalIO_PTA3,   (volatile TPM_Type*)TPM(PTA3_TPM_NUM),PTA3_TPM_CH,   PORT_PCR_MUX(PTA3_TPM_FN)};
#endif
#if TPM0_1_SEL == 1
const PwmIO  pwmIO_PTA4      = {&digitalIO_PTA4,   (volatile TPM_Type*)TPM(PTA4_TPM_NUM),PTA4_TPM_CH,   PORT_PCR_MUX(PTA4_TPM_FN)};
#endif
#if TPM0_2_SEL == 1
const PwmIO  pwmIO_PTA5      = {&digitalIO_PTA5,   (volatile TPM_Type*)TPM(PTA5_TPM_NUM),PTA5_TPM_CH,   PORT_PCR_MUX(PTA5_TPM_FN)};
#endif
#if TPM1_0_SEL == 1
const PwmIO  pwmIO_PTA12     = {&digitalIO_PTA12,  (volatile TPM_Type*)TPM(PTA12_TPM_NUM),PTA12_TPM_CH,  PORT_PCR_MUX(PTA12_TPM_FN)};
#endif
#if TPM1_1_SEL == 1
const PwmIO  pwmIO_PTA13     = {&digitalIO_PTA13,  (volatile TPM_Type*)TPM(PTA13_TPM_NUM),PTA13_TPM_CH,  PORT_PCR_MUX(PTA13_TPM_FN)};
#endif
#if TPM1_0_SEL == 2
const PwmIO  pwmIO_PTB0      = {&digitalIO_PTB0,   (volatile TPM_Type*)TPM(PTB0_TPM_NUM),PTB0_TPM_CH,   PORT_PCR_MUX(PTB0_TPM_FN)};
#endif
#if TPM1_1_SEL == 2
const PwmIO  pwmIO_PTB1      = {&digitalIO_PTB1,   (volatile TPM_Type*)TPM(PTB1_TPM_NUM),PTB1_TPM_CH,   PORT_PCR_MUX(PTB1_TPM_FN)};
#endif
#if TPM2_0_SEL == 2
const PwmIO  pwmIO_PTB2      = {&digitalIO_PTB2,   (volatile TPM_Type*)TPM(PTB2_TPM_NUM),PTB2_TPM_CH,   PORT_PCR_MUX(PTB2_TPM_FN)};
#endif
#if TPM2_1_SEL == 2
const PwmIO  pwmIO_PTB3      = {&digitalIO_PTB3,   (volatile TPM_Type*)TPM(PTB3_TPM_NUM),PTB3_TPM_CH,   PORT_PCR_MUX(PTB3_TPM_FN)};
#endif
#if TPM2_0_SEL == 3
const PwmIO  pwmIO_PTB18     = {&digitalIO_PTB18,  (volatile TPM_Type*)TPM(PTB18_TPM_NUM),PTB18_TPM_CH,  PORT_PCR_MUX(PTB18_TPM_FN)};
#endif
#if TPM2_1_SEL == 3
const PwmIO  pwmIO_PTB19     = {&digitalIO_PTB19,  (volatile TPM_Type*)TPM(PTB19_TPM_NUM),PTB19_TPM_CH,  PORT_PCR_MUX(PTB19_TPM_FN)};
#endif
#if TPM0_0_SEL == 2
const PwmIO  pwmIO_PTC1      = {&digitalIO_PTC1,   (volatile TPM_Type*)TPM(PTC1_TPM_NUM),PTC1_TPM_CH,   PORT_PCR_MUX(PTC1_TPM_FN)};
#endif
#if TPM0_1_SEL == 2
const PwmIO  pwmIO_PTC2      = {&digitalIO_PTC2,   (volatile TPM_Type*)TPM(PTC2_TPM_NUM),PTC2_TPM_CH,   PORT_PCR_MUX(PTC2_TPM_FN)};
#endif
#if TPM0_2_SEL == 2
const PwmIO  pwmIO_PTC3      = {&digitalIO_PTC3,   (volatile TPM_Type*)TPM(PTC3_TPM_NUM),PTC3_TPM_CH,   PORT_PCR_MUX(PTC3_TPM_FN)};
#endif
#if TPM0_3_SEL == 1
const PwmIO  pwmIO_PTC4      = {&digitalIO_PTC4,   (volatile TPM_Type*)TPM(PTC4_TPM_NUM),PTC4_TPM_CH,   PORT_PCR_MUX(PTC4_TPM_FN)};
#endif
#if TPM0_4_SEL == 1
const PwmIO  pwmIO_PTC8      = {&digitalIO_PTC8,   (volatile TPM_Type*)TPM(PTC8_TPM_NUM),PTC8_TPM_CH,   PORT_PCR_MUX(PTC8_TPM_FN)};
#endif
#if TPM0_5_SEL == 2
const PwmIO  pwmIO_PTC9      = {&digitalIO_PTC9,   (volatile TPM_Type*)TPM(PTC9_TPM_NUM),PTC9_TPM_CH,   PORT_PCR_MUX(PTC9_TPM_FN)};
#endif
#if TPM0_0_SEL == 3
const PwmIO  pwmIO_PTD0      = {&digitalIO_PTD0,   (volatile TPM_Type*)TPM(PTD0_TPM_NUM),PTD0_TPM_CH,   PORT_PCR_MUX(PTD0_TPM_FN)};
#endif
#if TPM0_1_SEL == 3
const PwmIO  pwmIO_PTD1      = {&digitalIO_PTD1,   (volatile TPM_Type*)TPM(PTD1_TPM_NUM),PTD1_TPM_CH,   PORT_PCR_MUX(PTD1_TPM_FN)};
#endif
#if TPM0_2_SEL == 3
const PwmIO  pwmIO_PTD2      = {&digitalIO_PTD2,   (volatile TPM_Type*)TPM(PTD2_TPM_NUM),PTD2_TPM_CH,   PORT_PCR_MUX(PTD2_TPM_FN)};
#endif
#if TPM0_3_SEL == 2
const PwmIO  pwmIO_PTD3      = {&digitalIO_PTD3,   (volatile TPM_Type*)TPM(PTD3_TPM_NUM),PTD3_TPM_CH,   PORT_PCR_MUX(PTD3_TPM_FN)};
#endif
#if TPM0_4_SEL == 2
const PwmIO  pwmIO_PTD4      = {&digitalIO_PTD4,   (volatile TPM_Type*)TPM(PTD4_TPM_NUM),PTD4_TPM_CH,   PORT_PCR_MUX(PTD4_TPM_FN)};
#endif
#if TPM0_5_SEL == 3
const PwmIO  pwmIO_PTD5      = {&digitalIO_PTD5,   (volatile TPM_Type*)TPM(PTD5_TPM_NUM),PTD5_TPM_CH,   PORT_PCR_MUX(PTD5_TPM_FN)};
#endif
#if TPM1_0_SEL == 3
const PwmIO  pwmIO_PTE20     = {&digitalIO_PTE20,  (volatile TPM_Type*)TPM(PTE20_TPM_NUM),PTE20_TPM_CH,  PORT_PCR_MUX(PTE20_TPM_FN)};
#endif
#if TPM1_1_SEL == 3
const PwmIO  pwmIO_PTE21     = {&digitalIO_PTE21,  (volatile TPM_Type*)TPM(PTE21_TPM_NUM),PTE21_TPM_CH,  PORT_PCR_MUX(PTE21_TPM_FN)};
#endif
#if TPM2_0_SEL == 4
const PwmIO  pwmIO_PTE22     = {&digitalIO_PTE22,  (volatile TPM_Type*)TPM(PTE22_TPM_NUM),PTE22_TPM_CH,  PORT_PCR_MUX(PTE22_TPM_FN)};
#endif
#if TPM2_1_SEL == 4
const PwmIO  pwmIO_PTE23     = {&digitalIO_PTE23,  (volatile TPM_Type*)TPM(PTE23_TPM_NUM),PTE23_TPM_CH,  PORT_PCR_MUX(PTE23_TPM_FN)};
#endif
#if TPM0_0_SEL == 4
const PwmIO  pwmIO_PTE24     = {&digitalIO_PTE24,  (volatile TPM_Type*)TPM(PTE24_TPM_NUM),PTE24_TPM_CH,  PORT_PCR_MUX(PTE24_TPM_FN)};
#endif
#if TPM0_1_SEL == 4
const PwmIO  pwmIO_PTE25     = {&digitalIO_PTE25,  (volatile TPM_Type*)TPM(PTE25_TPM_NUM),PTE25_TPM_CH,  PORT_PCR_MUX(PTE25_TPM_FN)};
#endif
#if TPM0_2_SEL == 4
const PwmIO  pwmIO_PTE29     = {&digitalIO_PTE29,  (volatile TPM_Type*)TPM(PTE29_TPM_NUM),PTE29_TPM_CH,  PORT_PCR_MUX(PTE29_TPM_FN)};
#endif
#if TPM0_3_SEL == 3
const PwmIO  pwmIO_PTE30     = {&digitalIO_PTE30,  (volatile TPM_Type*)TPM(PTE30_TPM_NUM),PTE30_TPM_CH,  PORT_PCR_MUX(PTE30_TPM_FN)};
#endif
#if TPM0_4_SEL == 3
const PwmIO  pwmIO_PTE31     = {&digitalIO_PTE31,  (volatile TPM_Type*)TPM(PTE31_TPM_NUM),PTE31_TPM_CH,  PORT_PCR_MUX(PTE31_TPM_FN)};
#endif
