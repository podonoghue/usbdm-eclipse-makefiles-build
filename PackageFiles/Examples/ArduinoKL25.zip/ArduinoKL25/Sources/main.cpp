/*
 ============================================================================
 Name        : main.c
 Author      : $(author)
 Version     :
 Copyright   : $(copyright)
 Description : Basic C Main
 ============================================================================
 */
#include <stdio.h>
#include "Gpio.h"
#include "HMC5883L.h"
#include "MMA845x.h"
#include "PCA9685.h"
#include "Motor.h"

using namespace Arduino;

void delay(void) {
   for(int i=0; i<400000; i++) {
      __asm__("nop");
   }
}

#define EXAMPLE 1

#if EXAMPLE == 1
// Joystick
// 2 x Analogue input
// 1 x Digital input

// Connection mapping
#define JOYSTICK_X   gpioA2
#define JOYSTICK_Y   gpioA1
#define JOYSTICK_K   gpioA0

int main(void) {
   JOYSTICK_X.setAnalogueInput();
   JOYSTICK_Y.setAnalogueInput();
   JOYSTICK_K.setDigitalInput();

   for(;;) {
      int  x = JOYSTICK_X.readAnalogue();
      int  y = JOYSTICK_Y.readAnalogue();
      bool k = JOYSTICK_K.read();
      printf("Joystick (X,Y,Z) = (%7d, %7d, %s)\n", x, y, k?"HIGH":"LOW");
      delay();
   }
}
#endif

#if EXAMPLE == 2
// SWITCH + LED
// 1 x Digital input
// 1 x Digital output

// Connection mapping
#define SWITCH    gpioD12
#define LED       gpioD13

int main(void) {
   LED.setDigitalOutput();
   SWITCH.setDigitalInput();

   for(;;) {
      LED.write(!SWITCH.read());
   }
}
#endif

#if EXAMPLE == 3
// I2C interface
// HMC5883L Compass (external) + MMA845x Accelerometer (on FRDM-K20 board)
//
int main(void) {

   I2C      *i2c0          = new I2C_0(0x00);
   I2C      *i2c1          = new I2C_1(0x00);
   HMC5883L *compass       = new HMC5883L(i2c1);
   MMA845x  *accelerometer = new MMA845x(i2c0, MMA845x::MMA45x_2Gmode);

   uint32_t id = compass->readID();
   printf("Compass ID = 0x%6lX (should be 0x483433)\n", id);

   compass->setGain(1);
   accelerometer->setMode(MMA845x::MMA45x_2Gmode);

   int16_t compassX,compassY,compassZ;
   int16_t accelerometerX,accelerometerY,accelerometerZ;
   int accelerometerXStatus;

   for(;;) {
      compass->doMeasurement(&compassX, &compassY, &compassZ);
      accelerometer->readXYX(&accelerometerXStatus, &accelerometerX, &accelerometerY, &accelerometerZ);
      printf("Compass = (%5d %5d %5d), Accelerometer = (%7d %7d %7d)\n",
             compassX, compassY, compassZ, accelerometerX, accelerometerY, accelerometerZ);
      delay();
   }
}
#endif

#if EXAMPLE == 4
// I2C
// Motor controller (Adafruit Motor-shield V2)
//
int main(void) {

   I2C   *i2c1   = new I2C_1(0x00);
   Motor *motor = new Motor(i2c1);

   for(;;) {
      motor->setMotor2(Motor::CW,  1000);
      motor->setMotor2(Motor::CCW, 1000);
      motor->setMotor2(Motor::CW,  0);
      motor->setMotor2(Motor::CCW, 0);
      motor->setMotor2(Motor::CW,  4000);
      motor->setMotor2(Motor::CCW, 4000);
   }
}
#endif

#if EXAMPLE == 5
// I2C interface
// MMA845x Accelerometer (on FRDM-K20 board)
//
int main(void) {

   I2C      *i2c0          = new I2C_0(0x00, I2C::interrupt);
   MMA845x  *accelerometer = new MMA845x(i2c0, MMA845x::MMA45x_2Gmode);

   accelerometer->setMode(MMA845x::MMA45x_2Gmode);

   int16_t accelerometerX,accelerometerY,accelerometerZ;
   int accelerometerXStatus;

   for(;;) {
      accelerometer->readXYX(&accelerometerXStatus, &accelerometerX, &accelerometerY, &accelerometerZ);
      printf("Accelerometer = (%5d %5d %5d)\n", accelerometerX, accelerometerY, accelerometerZ);
      delay();
   }
}
#endif
