/*
 * SysTick.h
 *
 *  Created on: 10 Aug 2014
 *      Author: podonoghue
 */

#ifndef SYSTICK_H_
#define SYSTICK_H_
#include <stdint.h>

uint32_t getTicks();

#endif /* SYSTICK_H_ */
