/*
 * pwm.c
 *
 *  Created on: 13/11/2013
 *      Author: podonoghue
 */
#include "derivative.h"
#include "stddef.h"
#include "utilities.h"
#include "clock.h"
#include "tpm0.h"

#ifndef TPM0_USES_NAKED_HANDLERS

/*! Set the callback for the TPM channel
 *
 *  @param channel   - PTM channel to initialise
 */
void TPM_0::setCallbackFunction(int channel, FTMCallbackFunction callback, uint16_t interval) {

   channelInformation[channel].callback = callback;
   channelInformation[channel].interval = interval;

   tpmBase->CONTROLS[channel].CnSC |= TPM_CnSC_CHIE_MASK;

   NVIC_EnableIRQ(interruptNumber);
}

TPM_0::FtmChannelInformation TPM_0::channelInformation[] = {{NULL,0}};

extern "C"
void TPM0_IRQHandler(void) {
   // This method is better for the usual case of a single interrupt at a time
   int channel = 0;
   int status  = TPM0_STATUS;
   if (status & 0xF0) {
      channel = 4;
      status  &= 0xF0;
   }
   if (status & 0xCC) {
      channel += 2;
      status  &= 0xCC;
   }
   if (status & 0xAA) {
      channel++;
   }
   // Clear flag
   TPM0->CONTROLS[channel].CnSC |= TPM_CnSC_CHF_MASK;
   if (TPM_0::channelInformation[channel].interval != 0) {
      // Set interval
      TPM0->CONTROLS[channel].CnV += TPM_0::channelInformation[channel].interval;
   }
   if (TPM_0::channelInformation[channel].callback != NULL) {
      // Do callback
      TPM_0::channelInformation[channel].callback();
   }
}

#endif
