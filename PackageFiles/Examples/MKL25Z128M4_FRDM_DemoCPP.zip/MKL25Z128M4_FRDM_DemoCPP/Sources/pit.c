/*
 ============================================================================
 * pit.c
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */

#include <stddef.h>
#include "derivative.h"
#include "leds.h"
#include "utilities.h"
#include "pit.h"

/*!=========================================================================
 *
 *   Programmable Interrupt Timer (PIT) routines
 *
 *=========================================================================*/

/*! Initialises a PIT channel
 *
 * @param channel  - channel (0-1) to configure
 * @param interval - PIT interval (use PIT_MILLISECOND_TO_TICKS() macro)
 *
 * Configures:
 *   - Enables PIT clock
 *   - Sets PIT re-load value
 *   - Enables PIT
 *   - Enables interrupts
 */
void pit_initialise(int channel, uint32_t interval) {

   // Enable clock to PIT interface
   SIM_SCGC6  |= SIM_SCGC6_PIT_MASK;
   // Enable PIT module
   PIT_MCR     = 0;//PIT_MCR_FRZ_MASK;
   // Set re-load value
   PIT->CS[channel].LDVAL  = interval-1;
   // Enable this channel with interrupts
   PIT->CS[channel].TCTRL  = PIT_TCTRL_TEN_MASK|PIT_TCTRL_TIE_MASK;
   // Enable PIT interrupts in NVIC (all channels share ISR)
   NVIC_EnableIRQ(PIT_IRQn);
   // Set arbitrary priority level
   NVIC_SetPriority(PIT_IRQn, 2);
}

/*!
 *  Disable a PIT channel (or entire PIT)
 *
 *  @param channel - channel to disable, -1 disable entire PIT
 *
 */
void pit_finalise(int channel) {

   // Enable clock to PIT interface
   SIM_SCGC6  |= SIM_SCGC6_PIT_MASK;

   if (channel<0) {
      // Disable PIT module
      PIT_MCR     = 0;
      // Disable PIT interrupts in NVIC (all channels share ISR)
      NVIC_DisableIRQ(PIT_IRQn);
   }
   else {
      // Disable this channel with interrupts
      PIT->CS[channel].TCTRL = 0;
   }
}

#ifndef PIT_USES_NAKED_HANDLERS

//! Pointer to PIT callback functions
static PITCallbackFunction callbackFunction[4] = {NULL, NULL, NULL, NULL};

/*!
 *   Set PIT interrupt callback
 *
 *   @param channel  - The channel to associate the callback function with
 *   @param callback - The callback function to execute on interrupt
 *
 *   @return - previous callback
 */
PITCallbackFunction pit_setCallbackFunction(int channel, PITCallbackFunction callback) {
   PITCallbackFunction temp = callbackFunction[channel];
   callbackFunction[channel] = callback;
   return temp;
}

/*!
 *  PIT Handler
 *
 *   Calls PIT callbacks
 */
void PIT_IRQHandler(void) {
   PITCallbackFunction callback = NULL;

   if ((PIT_TFLG0&PIT_TFLG_TIF_MASK) != 0) {
      // Clear the interrupt request from PIT Channel 0
      PIT_TFLG0 = PIT_TFLG_TIF_MASK;
      // Save callback
      callback = callbackFunction[0];
   }
   else if ((PIT_TFLG1&PIT_TFLG_TIF_MASK) != 0) {
      // Clear the interrupt request from PIT Channel 1
      PIT_TFLG1 = PIT_TFLG_TIF_MASK;
      // Save callback
      callback = callbackFunction[1];
   }
#ifdef PIT_TFLG2
   else if ((PIT_TFLG2&PIT_TFLG_TIF_MASK) != 0) {
      // Clear the interrupt request from PIT Channel 2
      PIT_TFLG2 = PIT_TFLG_TIF_MASK;
      // Save callback
      callback = callbackFunction[1];
   }
#endif
#ifdef PIT_TFLG3
   else if ((PIT_TFLG3&PIT_TFLG_TIF_MASK) != 0) {
      // Clear the interrupt request from PIT Channel 3
      PIT_TFLG3 = PIT_TFLG_TIF_MASK;
      // Save callback
      callback = callbackFunction[1];
   }
#endif
   else {
      __breakpoint();
   }
   if (callback != NULL) {
      callback();
   }
}
#endif
