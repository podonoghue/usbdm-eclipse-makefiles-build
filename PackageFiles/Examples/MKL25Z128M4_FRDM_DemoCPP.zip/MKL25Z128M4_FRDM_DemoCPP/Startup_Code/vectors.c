/*
 *  Vectors-mkl.c
 *
 *  Generic vectors and security for Kinetis MKLxx
 *
 *  Created on: 07/12/2012
 *      Author: podonoghue
 */
#include <stdint.h>
#include <string.h>
#include "derivative.h"

#define DEVICE_SUBFAMILY_CortexM0

/*
 * Security information
 */
typedef struct {
    uint8_t  backdoorKey[8];
    uint32_t fprot;
    uint8_t  fsec;
    uint8_t  fopt;
    uint8_t  feprot;
    uint8_t  fdprot;
} SecurityInfo;

__attribute__ ((section(".security_information")))
const SecurityInfo securityInfo = {
    /* backdoor */ {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},
    /* fprot    */ 0xFFFFFFFF,
    /* fsec     */ 0xFE,
    /* fopt     */ 0xFF,
    /* feprot   */ 0xFF,
    /* fdprot   */ 0xFF,
};

/*
 * Vector table related
 */
typedef void( *const intfunc )( void );

#define WEAK_DEFAULT_HANDLER __attribute__ ((__weak__, alias("Default_Handler")))

#ifndef SCB_ICSR
#define SCB_ICSR (*(volatile uint32_t*)(0xE000ED04))
#endif

__attribute__((__interrupt__))
void Default_Handler(void) {

   uint32_t vectorNum = SCB_ICSR;

   (void)vectorNum;

   while (1) {
      __asm__("bkpt #0");
   }
}

typedef struct {
   unsigned int r0;
   unsigned int r1;
   unsigned int r2;
   unsigned int r3;
   unsigned int r12;
   void       (*lr)();
   void       (*pc)();
   unsigned int psr;
} ExceptionFrame;

typedef struct {
   unsigned int scb_hfsr;
   unsigned int scb_cfsr;
   unsigned int scb_bfar;
} ExceptionInfo;

/*  Low-level exception handler
 *
 *  Interface from asm to C.
 *  Passes address of exception handler to C-level handler
 *
 *  See http://www.freertos.org/Debugging-Hard-Faults-On-Cortex-M-Microcontrollers.html
 */
__attribute__((__naked__, __weak__, __interrupt__))
void HardFault_Handler(void) {
   __asm volatile (
          "       mov r0,lr                                     \n"
          "       mov r1,#4                                     \n"
          "       and r0,r1                                     \n"
          "       bne skip1                                     \n"
          "       mrs r0,msp                                    \n"
          "       b   skip2                                     \n"
          "skip1:                                               \n"
          "       mrs r0,psp                                    \n"
          "skip2:                                               \n"
          "       nop                                           \n"
          "       ldr r2, handler_addr_const                    \n"
          "       bx r2                                         \n"
          "       handler_addr_const: .word _HardFault_Handler  \n"
      );
}

/******************************************************************************/
/* Exception frame without floating-point storage
 * hard fault handler in C,
 * with stack frame location as input parameter
 *
 * @param exceptionFrame address of exception frame
 *
 */
void _HardFault_Handler(volatile ExceptionFrame *exceptionFrame) {
   (void)exceptionFrame;
#ifdef SCB_HFSR
   char reason[200] = "";
   volatile ExceptionInfo exceptionInfo = {0};
   exceptionInfo.scb_hfsr = SCB_HFSR;
   (void)exceptionInfo.scb_hfsr;
   if ((exceptionInfo.scb_hfsr&SCB_HFSR_FORCED_MASK) != 0) {
      // Forced
      exceptionInfo.scb_cfsr = SCB_CFSR;

      if (SCB_CFSR&SCB_CFSR_BFARVALID_MASK) {
         exceptionInfo.scb_bfar = SCB_BFAR;
      }
      /* CFSR Bit Fields */
      if (SCB_CFSR&SCB_CFSR_DIVBYZERO_MASK  ) { strcat(reason, "Divide by zero,"); }
      if (SCB_CFSR&SCB_CFSR_UNALIGNED_MASK  ) { strcat(reason, "Unaligned access,"); }
      if (SCB_CFSR&SCB_CFSR_NOCP_MASK       ) { strcat(reason, "No co-processor"); }
      if (SCB_CFSR&SCB_CFSR_INVPC_MASK      ) { strcat(reason, "Invalid PC (on return),"); }
      if (SCB_CFSR&SCB_CFSR_INVSTATE_MASK   ) { strcat(reason, "Invalid state (EPSR.T/IT,"); }
      if (SCB_CFSR&SCB_CFSR_UNDEFINSTR_MASK ) { strcat(reason, "Undefined Instruction,"); }
      if (SCB_CFSR&SCB_CFSR_BFARVALID_MASK  ) { strcat(reason, "BFAR contents valid,"); }
      if (SCB_CFSR&SCB_CFSR_LSPERR_MASK     ) { strcat(reason, "Bus fault on FP state save,"); }
      if (SCB_CFSR&SCB_CFSR_STKERR_MASK     ) { strcat(reason, "Bus fault on exception entry,"); }
      if (SCB_CFSR&SCB_CFSR_UNSTKERR_MASK   ) { strcat(reason, "Bus fault on exception return,"); }
      if (SCB_CFSR&SCB_CFSR_IMPRECISERR_MASK) { strcat(reason, "Imprecise data access error,"); }
      if (SCB_CFSR&SCB_CFSR_PRECISERR_MASK  ) { strcat(reason, "Precise data access error,"); }
      if (SCB_CFSR&SCB_CFSR_IBUSERR_MASK    ) { strcat(reason, "Bus fault on instruction pre-fetch,"); }
      if (SCB_CFSR&SCB_CFSR_MMARVALID_MASK  ) { strcat(reason, "MMAR contents valid,"); }
      if (SCB_CFSR&SCB_CFSR_MLSPERR_MASK    ) { strcat(reason, "MemManage fault on FP state save,"); }
      if (SCB_CFSR&SCB_CFSR_MSTKERR_MASK    ) { strcat(reason, "MemManage fault on exception entry,"); }
      if (SCB_CFSR&SCB_CFSR_MUNSTKERR_MASK  ) { strcat(reason, "MemManage fault on exception return,"); }
      if (SCB_CFSR&SCB_CFSR_DACCVIOL_MASK   ) { strcat(reason, "MemManage access violation on data access,"); }
      if (SCB_CFSR&SCB_CFSR_IACCVIOL_MASK   ) { strcat(reason, "MemManage access violation on instruction fetch,"); }
   }
#endif
   while (1) {
      asm("bkpt #0");
   }
}

void __HardReset(void) __attribute__((__interrupt__));
extern uint32_t __StackTop;

/*
 * Each vector is assigned an unique name.  This is then 'weakly' assigned to the
 * default handler.
 * To install a handler, create a function with the name shown and it will override
 * the weak default.
 */
void NMI_Handler(void)                        WEAK_DEFAULT_HANDLER;
void MemManage_Handler(void)                  WEAK_DEFAULT_HANDLER;
void BusFault_Handler(void)                   WEAK_DEFAULT_HANDLER;
void UsageFault_Handler(void)                 WEAK_DEFAULT_HANDLER;
void SVC_Handler(void)                        WEAK_DEFAULT_HANDLER;
void DebugMon_Handler(void)                   WEAK_DEFAULT_HANDLER;
void PendSV_Handler(void)                     WEAK_DEFAULT_HANDLER;
void SysTick_Handler(void)                    WEAK_DEFAULT_HANDLER;
void DMA0_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void DMA1_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void DMA2_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void DMA3_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void FTFA_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void PMC_IRQHandler(void)                     WEAK_DEFAULT_HANDLER;
void LLWU_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void I2C0_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void I2C1_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void SPI0_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void SPI1_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void UART0_IRQHandler(void)                   WEAK_DEFAULT_HANDLER;
void UART1_IRQHandler(void)                   WEAK_DEFAULT_HANDLER;
void UART2_IRQHandler(void)                   WEAK_DEFAULT_HANDLER;
void ADC0_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void ACMP0_IRQHandler(void)                   WEAK_DEFAULT_HANDLER;
void TPM0_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void TPM1_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void TPM2_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void RTC_Alarm_IRQHandler(void)               WEAK_DEFAULT_HANDLER;
void RTC_Seconds_IRQHandler(void)             WEAK_DEFAULT_HANDLER;
void PIT_IRQHandler(void)                     WEAK_DEFAULT_HANDLER;
void USBOTG_IRQHandler(void)                  WEAK_DEFAULT_HANDLER;
void DAC0_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void TSI0_IRQHandler(void)                    WEAK_DEFAULT_HANDLER;
void MCG_IRQHandler(void)                     WEAK_DEFAULT_HANDLER;
void LPTMR0_IRQHandler(void)                  WEAK_DEFAULT_HANDLER;
void PORTA_IRQHandler(void)                   WEAK_DEFAULT_HANDLER;
void PORTD_IRQHandler(void)                   WEAK_DEFAULT_HANDLER;

typedef struct {
   uint32_t *initialSP;
   intfunc  handlers[];
} VectorTable;

__attribute__ ((section(".interrupt_vectors")))
VectorTable const __vector_table = {
                                     /*  Vec Irq */
   &__StackTop,                      /*   0  -16  Initial stack pointer                                                            */
   {
      __HardReset,                   /*   1  -15  Reset Handler                                                                    */
      NMI_Handler,                   /*   2, -14  Non maskable Interrupt, cannot be stopped or preempted                           */
      HardFault_Handler,             /*   3, -13  Hard Fault, all classes of Fault                                                 */
      MemManage_Handler,             /*   4, -12  Memory Management, MPU mismatch, including Access Violation and No Match         */
      BusFault_Handler,              /*   5, -11  Bus Fault, Pre-Fetch-, Memory Access Fault, other address/memory related Fault   */
      UsageFault_Handler,            /*   6, -10  Usage Fault, i.e. Undef Instruction, Illegal State Transition                    */
      Default_Handler,               /*   7, -9   Reserved                                                                         */
      Default_Handler,               /*   8, -8   Reserved                                                                         */
      Default_Handler,               /*   9, -7   Reserved                                                                         */
      Default_Handler,               /*  10, -6   Reserved                                                                         */
      SVC_Handler,                   /*  11, -5   System Service Call via SVC instruction                                          */
      DebugMon_Handler,              /*  12, -4   Debug Monitor                                                                    */
      Default_Handler,               /*  13, -3   Reserved                                                                         */
      PendSV_Handler,                /*  14, -2   Pendable request for system service                                              */
      SysTick_Handler,               /*  15, -1   System Tick Timer                                                                */

                                     /* External Interrupts */
      DMA0_IRQHandler,               /*  16, 0    DMA0 Transfer complete or error                                                  */
      DMA1_IRQHandler,               /*  17, 1    DMA1 Transfer complete or error                                                  */
      DMA2_IRQHandler,               /*  18, 2    DMA2 Transfer complete or error                                                  */
      DMA3_IRQHandler,               /*  19, 3    DMA3 Transfer complete or error                                                  */
      Default_Handler,               /*  20, 4    Reserved                                                                         */
      FTFA_IRQHandler,               /*  21, 5    FTFA Command complete or error                                                   */
      PMC_IRQHandler,                /*  22, 6    PMC Low-voltage detect, low-voltage warning                                      */
      LLWU_IRQHandler,               /*  23, 7    Low Leakage Wakeup                                                               */
      I2C0_IRQHandler,               /*  24, 8    I2C Interface 0                                                                  */
      I2C1_IRQHandler,               /*  25, 9    I2C Interface 1                                                                  */
      SPI0_IRQHandler,               /*  26, 10   Serial Peripheral Interface 0                                                    */
      SPI1_IRQHandler,               /*  27, 11   Serial Peripheral Interface 1                                                    */
      UART0_IRQHandler,              /*  28, 12   UART0 Status and error                                                           */
      UART1_IRQHandler,              /*  29, 13   UART1 Status and error                                                           */
      UART2_IRQHandler,              /*  30, 14   UART2 Status and error                                                           */
      ADC0_IRQHandler,               /*  31, 15   Analogue to Digital Converter 0                                                  */
      ACMP0_IRQHandler,              /*  32, 16   Analogue comparator 0                                                            */
      TPM0_IRQHandler,               /*  33, 17   Timer/PWM Module 0                                                               */
      TPM1_IRQHandler,               /*  34, 18   Timer/PWM Module 1                                                               */
      TPM2_IRQHandler,               /*  35, 19   Timer/PWM Module 2                                                               */
      RTC_Alarm_IRQHandler,          /*  36, 20   Real Time Clock Alarm                                                            */
      RTC_Seconds_IRQHandler,        /*  37, 21   Real Time Clock Seconds                                                          */
      PIT_IRQHandler,                /*  38, 22   Programmable Interrupt Timer (All channels)                                      */
      Default_Handler,               /*  39, 23   Reserved                                                                         */
      USBOTG_IRQHandler,             /*  40, 24   USBB On The Go                                                                   */
      DAC0_IRQHandler,               /*  41, 25   Digital to Analogue Converter                                                    */
      TSI0_IRQHandler,               /*  42, 26   Touch Sense Input                                                                */
      MCG_IRQHandler,                /*  43, 27   Clock interrupt                                                                  */
      LPTMR0_IRQHandler,             /*  44, 28   Low Power Timer                                                                  */
      Default_Handler,               /*  45, 29   Reserved                                                                         */
      PORTA_IRQHandler,              /*  46, 30   Port A                                                                           */
      PORTD_IRQHandler,              /*  47, 31   Port D                                                                           */
      Default_Handler,               /*  48, 32   Reserved                                                                         */
      Default_Handler,               /*  49, 33   Reserved                                                                         */
      Default_Handler,               /*  50, 34   Reserved                                                                         */
      Default_Handler,               /*  51, 35   Reserved                                                                         */
      Default_Handler,               /*  52, 36   Reserved                                                                         */
      Default_Handler,               /*  53, 37   Reserved                                                                         */
      Default_Handler,               /*  54, 38   Reserved                                                                         */
      Default_Handler,               /*  55, 39   Reserved                                                                         */
      Default_Handler,               /*  56, 40   Reserved                                                                         */
      Default_Handler,               /*  57, 41   Reserved                                                                         */
   }
};



