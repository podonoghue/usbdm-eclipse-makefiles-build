/*
 * MMA845x.h
 *
 *  Created on: 22/11/2013
 *      Author: podonoghue
 */

#ifndef MMA845X_H_
#define MMA845X_H_

#ifdef __cplusplus
extern "C" {
#endif

#define CTRL_REG1_ACTIVE_MASK (1<<0)

#define XYZ_DATA_CFG_FS(x)          (((x)<<0)&0x03)
#define XYZ_DATA_CFG_HPF_OUT_MASK   (1<<4)

typedef enum {
   MMA45x_2Gmode = XYZ_DATA_CFG_FS(0),                                // 2g Full-scale, no high-pass filter
   MMA45x_4Gmode = XYZ_DATA_CFG_FS(1),                                // 4g Full-scale, no high-pass filter
   MMA45x_8Gmode = XYZ_DATA_CFG_FS(2),                                // 8g Full-scale, no high-pass filter
   MMA45x_2G_HPF_mode = XYZ_DATA_CFG_FS(0)|XYZ_DATA_CFG_HPF_OUT_MASK, // 2g Full-scale, high-pass filter
   MMA45x_4G_HPF_mode = XYZ_DATA_CFG_FS(1)|XYZ_DATA_CFG_HPF_OUT_MASK, // 4g Full-scale, high-pass filter
   MMA45x_8G_HPF_mode = XYZ_DATA_CFG_FS(2)|XYZ_DATA_CFG_HPF_OUT_MASK, // 8g Full-scale, high-pass filter
} MMA845x_Mode;

void MMA845x_Standby (void);
void MMA845x_ReadXYX(int *status, int *x, int *y, int *z);
void MMA845x_Initialise(MMA845x_Mode mode);

#ifdef __cplusplus
}
#endif

#endif /* MMA845X_H_ */
