/*
 * SPI.h
 *
 *  Created on: 07/08/2012
 *      Author: podonoghue
 */

#ifndef SPI_H_
#define SPI_H_

#include <stdint.h>
#include "derivative.h"

/**
 * @addtogroup SPI_Group Serial Peripheral Interface
 * @brief Allows access to SPI interface
 * @{
 */

/**
 * @brief Class representing the SPI interface
 *
 * <b>Example</b>
 * @code
 *  // Instantiate interface
 *  SPI *spi0 = new SPI_0(new DMAChannel0(), new DMAChannel1());
 *  spi0->setSpeed(400000);
 *
 *  // Transmit message (reception discarded)
 *  const uint8_t outBuffer[100] = {1,2,3,4};
 *  spi->txRxBytes(sizeof(outBuffer), outBuffer);
 *
 *  // Transmit and receive message
 *  uint8_t inoutBuffer[100] = {1,2,3,4};
 *  spi->txRxBytes(sizeof(inoutBuffer), inoutBuffer, inoutBuffer);
 *
 *  @endcode
 */
class SPI {
protected:
   volatile SPI_Type  *spi;
   uint32_t   spiBaudValue;
   uint32_t   interfaceFrequency;

protected:
   /**
    * Constructor
    *
    * @param baseAddress  Base address of SPI
    */
   SPI(volatile SPI_Type  *baseAddress);
public:
   /**
    * Sets Communication speed for SPI
    *
    * @param frequency => Frequency in Hz (0 => use default value)
    *
    * Note: Chooses the highest speed that is not greater than frequency.
    */
   void setSpeed(uint32_t frequency);
   /**
    * Gets current speed of interface
    *
    * @return Speed in Hz
    */
   uint32_t getSpeed(void) {
      return interfaceFrequency;
   }
   /**
    *  Transmit and receive a series of bytes
    *
    *  @param dataSize  Number of bytes to transfer
    *  @param dataOut   Transmit bytes (may be NULL for Rx only)
    *  @param dataIn    Receive byte buffer (may be NULL for Tx only)
    *
    *  Note: dataIn may use same buffer as dataOut
    */
   void txRxBytes(uint32_t dataSize, const uint8_t *dataOut, uint8_t *dataIn=0);

   /**
    * Transmit and receive an 8-bit value over SPI
    *
    * @param data - Data to send
    *
    * @return Data received
    */
   uint32_t txRx(uint32_t data);

   /*! Set SPI.CTAR0 value
    *
    * @param ctar 32-bit CTAR value (excluding baud)
    */
   void setCTAR0Value(uint32_t ctar) {
      spi->CTAR[0] = spiBaudValue|ctar;
   }

   /*! Set SPI.CTAR1 value
    *
    * @param ctar 32-bit CTAR value (excluding baud)
    */
   void setCTAR1Value(uint32_t ctar) {
      spi->CTAR[1] = spiBaudValue|ctar;
   }

   void on() {

   }

   void off() {

   }
};

/**
 * Class representing SPI0
 */
class SPI_0 : public SPI {
public:
   /**
    * Constructor
    */
   SPI_0();
};

#ifdef SPI1
/**
 * Class representing SPI1
 */
class SPI_1 : public SPI {
public:
   /**
    * Constructor
    */
   SPI_1();
};

#endif

/**
 * @}
 */

#endif /* SPI_H_ */
