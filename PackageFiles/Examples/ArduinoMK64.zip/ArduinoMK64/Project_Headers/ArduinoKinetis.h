/*
 * Tutorial.h
 *
 *  Created on: 09/07/2014
 *      Author: podonoghue
 */

#ifndef TUTORIAL_H_
#define TUTORIAL_H_

#ifdef MCU_MKL25Z4

// FRDM-KL12 Port pin definitions

/*
 * I2C0 = on-board = Arduino (D14, D15) (&others)
 * I2C1 = Arduino (A4, A5)
 */
// PTB0/LLWU_P5/ADC0_SE8/TSI0_CH0/I2C0_SCL/TPM1_CH0
#define A0_PORT         B     // Port Name
#define A0_NUM          0     // Port pin
#define A0_ADC_NUM      0     // ADC number
#define A0_ACH          8     // ADC channel
#define A0_FTM          1     // FTM
#define A0_FTM_CH       0     // FTM channel

// PTB1/ADC0_SE9/TSI0_CH6/I2C0_SDA/TPM1_CH1
#define A1_PORT         B     // Port Name
#define A1_NUM          1     // Port pin
#define A1_ADC_NUM      0     // ADC number
#define A1_ACH          9     // ADC channel
#define A1_FTM          1     // FTM
#define A1_FTM_CH       1     // FTM channel

// PTB2/ADC0_SE12/TSI0_CH7/I2C0_SCL/TPM2_CH0
#define A2_PORT         B     // Port Name
#define A2_NUM          2     // Port pin
#define A2_ADC_NUM      0     // ADC number
#define A2_ACH          12    // ADC channel
#define A2_FTM          2     // FTM
#define A2_FTM_CH       0     // FTM channel

// PTB3/ADC0_SE13/TSI0_CH8/I2C0_SDA/TPM2_CH1
#define A3_PORT         B     // Port Name
#define A3_NUM          3     // Port pin
#define A3_ADC_NUM      0     // ADC number
#define A3_ACH          13    // ADC channel
#define A3_FTM          2     // FTM
#define A3_FTM_CH       1     // FTM channel

// PTC2/ADC0_SE11/TSI0_CH15/I2C1_SDA/TPM0_CH1
#define A4_PORT         C     // Port Name
#define A4_NUM          2     // Port pin
#define A4_ADC_NUM      0     // ADC number
#define A4_ACH          11    // ADC channel
#define A4_FTM          0     // FTM
#define A4_FTM_CH       1     // FTM channel

// PTC1/LLWU_P6/RTC_CLKIN/ADC0_SE15/TSI0_CH14/I2C1_SCL/TPM0_CH0
#define A5_PORT         C     // Port Name
#define A5_NUM          1     // Port pin
#define A5_ADC_NUM      0     // ADC number
#define A5_ACH          15    // ADC channel
#define A5_FTM          0     // FTM
#define A5_FTM_CH       0     // FTM channel

// PTA1/TSI0_CH2/UART0_RX/TPM2_CH0
#define D0_PORT         A     // Port Name
#define D0_NUM          1     // Port pin
#define D0_FTM          2     // FTM
#define D0_FTM_CH       0     // FTM channel

// PTA2/TSI0_CH3/UART0_TX/TPM2_CH1
#define D1_PORT         A     // Port Name
#define D1_NUM          2     // Port pin
#define D1_FTM          2     // FTM
#define D1_FTM_CH       1     // FTM channel

// PTD4/LLWU_P14/SPI1_PCS0/UART2_RX/TPM0_CH4
#define D2_PORT         D     // Port Name
#define D2_NUM          4     // Port pin
#define D2_FTM          0     // FTM
#define D2_FTM_CH       4     // FTM channel

// PTA12/TPM1_CH0
#define D3_PORT         A     // Port Name
#define D3_NUM          12    // Port pin
#define D3_FTM          1     // FTM
#define D3_FTM_CH       0     // FTM channel

// PTA4/TSI0_CH5/I2C1_SDA/TPM0_CH1/NMI
#define D4_PORT         A     // Port Name
#define D4_NUM          4     // Port pin
#define D4_FTM          0     // FTM
#define D4_FTM_CH       1     // FTM channel

// PTA5/USB_CLKIN/TPM0_CH2
#define D5_PORT         A     // Port Name
#define D5_NUM          5     // Port pin
#define D5_FTM          0     // FTM
#define D5_FTM_CH       2     // FTM channel

// PTC8/CMP0_IN2/I2C0_SCL/TPM0_CH4
#define D6_PORT         C     // Port Name
#define D6_NUM          8     // Port pin
#define D6_FTM          0     // FTM
#define D6_FTM_CH       4     // FTM channel

// PTC9/CMP0_IN3/I2C0_SDA/TPM0_CH5
#define D7_PORT         C     // Port Name
#define D7_NUM          9     // Port pin
#define D7_FTM          0     // FTM
#define D7_FTM_CH       5     // FTM channel

// PTA13/TPM1_CH1
#define D8_PORT         A     // Port Name
#define D8_NUM          13    // Port pin
#define D8_FTM          1     // FTM
#define D8_FTM_CH       1     // FTM channel

// PTD5/ADC0_SE6B/SPI1_SCK/UART2_TX/TPM0_CH5
#define D9_PORT         D     // Port Name
#define D9_NUM          5     // Port pin
#define D9_ACH          6     // ADC channel
#define D9_FTM          0     // FTM
#define D9_FTM_CH       5     // FTM channel

// PTD0/SPI0_PCS0/TPM0_CH0
#define D10_PORT        D     // Port Name
#define D10_NUM         0     // Port pin
#define D10_FTM         0     // FTM
#define D10_FTM_CH      0     // FTM channel

// PTD2/SPI0_MOSI/UART2_RX/TPM0_CH2/SPI0_MISO
#define D11_PORT        D     // Port Name
#define D11_NUM         2     // Port pin
#define D11_FTM         0     // FTM
#define D11_FTM_CH      2     // FTM channel

// PTD3/SPI0_MISO/UART2_TX/TPM0_CH3/SPI0_MOSI
#define D12_PORT        D     // Port Name
#define D12_NUM         3     // Port pin
#define D12_FTM         0     // FTM
#define D12_FTM_CH      3     // FTM channel

// PTD1/ADC0_SE5B/SPI0_SCK/TPM0_CH1
#define D13_PORT        D     // Port Name
#define D13_NUM         1     // Port pin
#define D13_FTM         0     // FTM
#define D13_FTM_CH      1     // FTM channel

// PTE0/UART1_TX/RTC_CLKOUT/CMP0_OUT/I2C1_SDA
#define D14_PORT        E     // Port Name (SDA)
#define D14_NUM         0     // Port pin

// PTE1/SPI1_MOSI/UART1_RX/SPI1_MISO/I2C1_SCL
#define D15_PORT        E     // Port Name (SCL)
#define D15_NUM         1     // Port pin

#endif

#if defined(MCU_MK20D5) || defined(MCU_MK22F12)
// Port pin definitions (MK22F12 chip on MK20 board)

/*
 * I2C0 = on-board = Arduino (A4, A5), (D14, D15)
 */
// ADC0_SE14/TSI0_CH13/PTC0/SPI0_PCS4/PDB0_EXTRG/I2S0_TXD1
#define A0_PORT         C     // Port Name
#define A0_NUM          0     // Port pin
#define A0_ADC_NUM      0     // ADC number
#define A0_ACH          14    // ADC channel

// ADC0_SE15/TSI0_CH14/PTC1/SPI0_PCS3/UART1_RTS/FTM0_CH0/I2S0_TXD0
#define A1_PORT         C     // Port Name
#define A1_NUM          1     // Port pin
#define A1_ADC_NUM      0     // ADC number
#define A1_ACH          15    // ADC channel
#define A1_FTM          0     // FTM
#define A1_FTM_CH       0     // FTM channel

// ADC0_SE7b/PTD6/SPI0_PCS3/UART0_RX/FTM0_CH6/FTM0_FLT0
#define A2_PORT         D     // Port Name
#define A2_NUM          6     // Port pin
#define A2_ADC_NUM      0     // ADC number
#define A2_ACH          7     // ADC channel
#define A2_FTM          0     // FTM
#define A2_FTM_CH       6     // FTM channel

// ADC0_SE6B/PTD5/SPI0_PCS2/UART0_CTS/UART0_COL/FTM0_CH5/EWM_OUT
#define A3_PORT         D     // Port Name
#define A3_NUM          5     // Port pin
#define A3_ADC_NUM      0     // ADC number
#define A3_ACH          6     // ADC channel
#define A3_FTM          0     // FTM
#define A3_FTM_CH       5     // FTM channel

// ADC0_SE9/TSI0_CH6/PTB1/I2C0_SDA/FTM1_CH1/FTM1_QD_PHB
#define A4_PORT         B     // Port Name
#define A4_NUM          1     // Port pin
#define A4_ADC_NUM      0     // ADC number
#define A4_ACH          9     // ADC channel
#define A4_FTM          1     // FTM
#define A4_FTM_CH       1     // FTM channel

// ADC0_SE8/TSI0_CH0/PTB0/I2C0_SCL/FTM1_CH0/FTM1_QD_PHA
#define A5_PORT         B     // Port Name
#define A5_NUM          0     // Port pin
#define A5_ADC_NUM      0     // ADC number
#define A5_ACH          8     // ADC channel
#define A5_FTM          0     // FTM
#define A5_FTM_CH       0     // FTM channel

// PTE1/UART1_RX
#define D0_PORT         E     // Port Name
#define D0_NUM          1     // Port pin

// PTE0/UART1_TX/RTC_CLKOUT
#define D1_PORT         E     // Port Name
#define D1_NUM          0     // Port pin

// PTA5/USB_CLKIN/FTM0_CH2/I2S0_TX_BCLK/JTAG_TRST
#define D2_PORT         A     // Port Name
#define D2_NUM          5     // Port pin
#define D2_FTM          0     // FTM
#define D2_FTM_CH       4     // FTM channel
#define D2_FTM_FN       3     // Pin Mux for FTM

// PTD4/SPI0_PCS1/UART0_RTS/FTM0_CH4/EWM_IN
#define D3_PORT         D     // Port Name
#define D3_NUM          4     // Port pin
#define D3_FTM          0     // FTM
#define D3_FTM_CH       4     // FTM channel
#define D3_FTM_FN       4     // Pin Mux for FTM

// CMP0_IN2/PTC8/I2S0_MCLK
#define D4_PORT         C     // Port Name
#define D4_NUM          8     // Port pin

// JTAG_TDI/EZP_DI/TSI0_CH2/PTA1/UART0_RX/FTM0_CH6
#define D5_PORT         A     // Port Name
#define D5_NUM          1     // Port pin
#define D5_FTM          0     // FTM
#define D5_FTM_CH       6     // FTM channel
#define D5_FTM_FN       3     // Pin Mux for FTM

// CMP1_IN1/PTC3/SPI0_PCS1/UART1_RX/FTM0_CH2/CLKOUT/I2S0_TX_BCLK
#define D6_PORT         C     // Port Name
#define D6_NUM          3     // Port pin
#define D6_FTM          0     // FTM
#define D6_FTM_CH       2     // FTM channel
#define D6_FTM_FN       4     // Pin Mux for FTM

// PTC4/SPI0_PCS0/UART1_TX/FTM0_CH3/CMP1_OUT
#define D7_PORT         C     // Port Name
#define D7_NUM          4     // Port pin
#define D7_FTM          0     // FTM
#define D7_FTM_CH       3     // FTM channel
#define D7_FTM_FN       4     // Pin Mux for FTM

// PTA12/FTM1_CH0/I2S0_TXD0/FTM1_QD_PHA
#define D8_PORT         A     // Port Name
#define D8_NUM          12    // Port pin
#define D8_FTM          1     // FTM
#define D8_FTM_CH       0     // FTM channel
#define D8_FTM_FN       3     // Pin Mux for FTM

// JTAG_TDO/TRACE_SWO/EZP_DO/TSI0_CH3/PTA2/UART0_TX/FTM0_CH7
#define D9_PORT         A     // Port Name
#define D9_NUM          2     // Port pin
#define D9_FTM          0     // FTM
#define D9_FTM_CH       7     // FTM channel
#define D9_FTM_FN       3     // Pin Mux for FTM

// ADC0_SE4B/CMP1_IN0/TSI0_CH15/PTC2/SPI0_PCS2/UART1_CTS/FTM0_CH1/I2S0_TX_FS
#define D10_PORT        C     // Port Name
#define D10_NUM         2     // Port pin
#define D10_ACH         4     // ADC channel
#define D10_FTM         0     // FTM
#define D10_FTM_CH      1     // FTM channel
#define D10_FTM_FN      4     // Pin Mux for FTM

// PTD2/SPI0_SOUT/UART2_RX
#define D11_PORT        D     // Port Name
#define D11_NUM         2     // Port pin

// PTD3/SPI0_SIN/UART2_TX
#define D12_PORT        D     // Port Name
#define D12_NUM         3     // Port pin

// ADC0_SE5B/PTD1/SPI0_SCK/UART2_CTS
#define D13_PORT        D     // Port Name
#define D13_NUM         1     // Port pin
#define D13_ACH         5     // ADC channel

// ADC0_SE13/TSI0_CH8/PTB3/I2C0_SDA/UART0_CTS/UART0_COL/FTM0_FLT0
#define D14_PORT        B     // Port Name
#define D14_NUM         3     // Port pin
#define D14_ACH         13    // ADC channel

// ADC0_SE12/TSI0_CH7/PTB2/I2C0_SCL/UART0_RTS/FTM0_FLT3
#define D15_PORT        B     // Port Name
#define D15_NUM         2     // Port pin
#define D15_ACH         12    // ADC channel

#endif

#ifdef MCU_MK22F51212
// FRDM-MK22F12 Port pin definitions

/*
 * I2C0 = on-board = Arduino (D14, D15)
 * I2C1 = Arduino (A4, A5)
 */
// A0 - PTB0/LLWU_P5/ADC0_SE8/ADC1_SE8
#define A0_PORT         B     // Port Name
#define A0_NUM          0     // Port pin
#define A0_ADC_NUM      0     // ADC number
#define A0_ACH          8     // ADC channel

// A1 - PTB1/ADC0_SE9/ADC1_SE9
#define A1_PORT         B     // Port Name
#define A1_NUM          1     // Port pin
#define A1_ADC_NUM      0     // ADC number (
#define A1_ACH          9     // ADC channel

// A2 - PTC1/LLWU_P6/ADC0_SE15
#define A2_PORT         C     // Port Name
#define A2_NUM          1     // Port pin
#define A2_ADC_NUM      0     // ADC number
#define A2_ACH          15    // ADC channel

// A3 - PTC2/ADC0_SE4b/CMP1_IN0
#define A3_PORT         C     // Port Name
#define A3_NUM          2     // Port pin
#define A3_ADC_NUM      0     // ADC number
#define A3_ACH          4     // ADC channel

// A4 - PTB3/ADC0_SE13/I2C0_SDA
#define A4_PORT         B     // Port Name
#define A4_NUM          3     // Port pin
#define A4_ADC_NUM      0     // ADC number
#define A4_ACH          13    // ADC channel

// A5 - PTB2/ADC0_SE12/I2C0_SCL
#define A5_PORT         B     // Port Name
#define A5_NUM          2     // Port pin
#define A5_ADC_NUM      0     // ADC number
#define A5_ACH          12    // ADC channel

// D0 - PTD2/LLWU_P13/UART2_RX/FTM3_CH2
#define D0_PORT         C     // Port Name
#define D0_NUM          16    // Port pin

// D1 - PTD3/UART2_TX/FTM3_CH3
#define D1_PORT         D     // Port Name
#define D1_NUM          3     // Port pin
#define D1_FTM          3     // FTM
#define D1_FTM_CH       3     // FTM channel
#define D1_FTM_FN       4     // FTM function

// D2 - PTB16
#define D2_PORT         B     // Port Name
#define D2_NUM          16    // Port pin

// D3 - PTA2/UART0_TX/FTM0_CH7 | GREEN_LED
#define D3_PORT         A     // Port Name
#define D3_NUM          2     // Port pin
#define D3_FTM          0     // FTM
#define D3_FTM_CH       7     // FTM channel
#define D3_FTM_FN       3     // FTM function

// D4 - PTA4/LLWU_P3
#define D4_PORT         A     // Port Name
#define D4_NUM          4     // Port pin

// D5 - PTB18/FTM2_CH0
#define D5_PORT         B     // Port Name
#define D5_NUM          18    // Port pin
#define D5_FTM          2     // FTM
#define D5_FTM_CH       0     // FTM channel
#define D5_FTM_FN       3     // FTM function

// D6 - PTC3/LLWU_P7/FTM0_CH2/CMP1_IN1
#define D6_PORT         C     // Port Name
#define D6_NUM          3     // Port pin
#define D6_FTM          0     // FTM
#define D6_FTM_CH       2     // FTM channel
#define D6_FTM_FN       4     // FTM function

// D7 - PTC6/LLWU_P10/CMP0_IN0
#define D7_PORT         C     // Port Name
#define D7_NUM          6     // Port pin

// D8 - PTB19/FTM2_CH1
#define D8_PORT         B     // Port Name
#define D8_NUM          19    // Port pin
#define D8_FTM          2     // FTM
#define D8_FTM_CH       1     // FTM channel
#define D8_FTM_FN       3     // FTM function

// D9 - PTA1/UART0_RX/FTM0_CH6 | RED_LED
#define D9_PORT         A     // Port Name
#define D9_NUM          1     // Port pin
#define D9_FTM          0     // FTM
#define D9_FTM_CH       6     // FTM channel
#define D9_FTM_FN       3     // FTM function

// D10 - PTD4/LLWU_P14/SPI0_PCS1/SPI1_PCS0
#define D10_PORT        D     // Port Name
#define D10_NUM         4     // Port pin

// D11 - PTD6/SPI1_SOUT
#define D11_PORT        D     // Port Name
#define D11_NUM         6     // Port pin

// D12 - PTD7/SPI1_SIN
#define D12_PORT        D     // Port Name
#define D12_NUM         7     // Port pin

// D13 - PTD5/FTM0_CH5/SPI1_SCK
#define D13_PORT        D     // Port Name
#define D13_NUM         5     // Port pin
#define D13_FTM         0     // FTM
#define D13_FTM_CH      5     // FTM channel
#define D13_FTM_FN      4     // FTM function

// D14 - PTE0/I2C1_SDA/ADC1_SE4a | UART1_TX
#define D14_PORT        E     // Port Name
#define D14_NUM         0     // Port pin
#define D14_ADC_NUM     1     // ADC number
#define D14_ACH         4     // ADC channel

// D15 - PTE1/I2C1_SCL/ADC1_SE5a | UART1_RX
#define D15_PORT        E     // Port Name
#define D15_NUM         1     // Port pin
#define D15_ADC_NUM     1     // ADC number
#define D15_ACH         5     // ADC channel

#endif

#ifdef MCU_MK64F12
// FRDM-MK64F Port pin definitions

/*
 * I2C0 = on-board = Arduino (D14, D15)
 * I2C1 = Arduino (A4, A5)
 */
// PTB2/ADC0_SE12/I2C0_SCL/UART0_RTS/ENET0_1588_TMR0/FTM0_FLT3
#define A0_PORT         B     // Port Name
#define A0_NUM          2     // Port pin
#define A0_ADC_NUM      0     // ADC number
#define A0_ACH          12    // ADC channel

// PTB3/ADC0_SE13/I2C0_SDA/UART0_CTS/UART0_COL/ENET0_1588_TMR1/FTM0_FLT0
#define A1_PORT         B     // Port Name
#define A1_NUM          3     // Port pin
#define A1_ADC_NUM      0     // ADC number
#define A1_ACH          13    // ADC channel

// PTB10/ADC1_SE14/SPI1_PCS0/UART3_RX/FB_AD19/FTM0_FLT1
#define A2_PORT         B     // Port Name
#define A2_NUM          10    // Port pin
#define A2_ADC_NUM      1     // ADC number
#define A2_ACH          14    // ADC channel

// PTB11/ADC1_SE15/SPI1_SCK/UART3_TX/FB_AD18/FTM0_FLT2
#define A3_PORT         B     // Port Name
#define A3_NUM          11    // Port pin
#define A3_ADC_NUM      1     // ADC number
#define A3_ACH          15    // ADC channel

// PTC11/LLWU_P11/ADC1_SE7B/I2C1_SDA/FTM3_CH7/I2S0_RXD1/FB_RW
#define A4_PORT         C     // Port Name
#define A4_NUM          11    // Port pin
#define A4_ADC_NUM      1     // ADC number
#define A4_ACH          7     // ADC channel
#define A4_FTM          3     // FTM
#define A4_FTM_CH       7     // FTM channel

// PTC10/ADC1_SE6B/I2C1_SCL/FTM3_CH6/I2S0_RX_FS/FB_AD5
#define A5_PORT         C     // Port Name
#define A5_NUM          10    // Port pin
#define A5_ADC_NUM      1     // ADC number
#define A5_ACH          6     // ADC channel

// PTC16/UART3_RX/ENET0_1588_TMR0/FB_CS5/FB_TSIZ1/FB_BE23_16_BLS15_8
#define D0_PORT         C     // Port Name
#define D0_NUM          16    // Port pin

// PTC17/UART3_TX/ENET0_1588_TMR1/FB_CS4/FB_TSIZ0/FB_BE31_24_BLS7_0
#define D1_PORT         C     // Port Name
#define D1_NUM          17    // Port pin

// PTB9/SPI1_PCS1/UART3_CTS/FB_AD20
#define D2_PORT         B     // Port Name
#define D2_NUM          9     // Port pin
#define D2_FTM          0     // FTM
#define D2_FTM_CH       4     // FTM channel

// PTA1/JTAG_TDI/EZP_DI/UART0_RX/FTM0_CH6
#define D3_PORT         A     // Port Name
#define D3_NUM          1     // Port pin
#define D3_FTM          0     // FTM
#define D3_FTM_CH       6     // FTM channel

// PTB23/SPI2_SIN/SPI0_PCS5/FB_AD28
#define D4_PORT         B     // Port Name
#define D4_NUM          23    // Port pin

// PTA2/JTAG_TDO/TRACE_SWO/EZP_DO/UART0_TX/FTM0_CH7
#define D5_PORT         A     // Port Name
#define D5_NUM          2     // Port pin
#define D5_FTM          0     // FTM
#define D5_FTM_CH       7     // FTM channel

// PTC2/ADC0_SE4B/CMP1_IN0/SPI0_PCS2/UART1_CTS/FTM0_CH1/FB_AD12/I2S0_TX_FS
#define D6_PORT         C     // Port Name
#define D6_NUM          2     // Port pin
#define D6_ACH          4     // ADC channel
#define D6_FTM          0     // FTM
#define D6_FTM_CH       1     // FTM channel

// PTC3/LLWU_P7/CMP1_IN1/SPI0_PCS1/UART1_RX/FTM0_CH2/CLKOUT/I2S0_TX_BCLK
#define D7_PORT         C     // Port Name
#define D7_NUM          3     // Port pin
#define D7_FTM          0     // FTM
#define D7_FTM_CH       2     // FTM channel

// PTA0/JTAG_TCLK/SWD_CLK/EZP_CLK/UART0_CTS/UART0_COL/FTM0_CH5
#define D8_PORT         A     // Port Name
#define D8_NUM          0     // Port pin
#define D8_FTM          0     // FTM
#define D8_FTM_CH       5     // FTM channel

// PTC4/LLWU_P8/SPI0_PCS0/UART1_TX/FTM0_CH3/FB_AD11/CMP1_OUT
#define D9_PORT         C     // Port Name
#define D9_NUM          4     // Port pin
#define D9_FTM          0     // FTM
#define D9_FTM_CH       3     // FTM channel

// PTD0/LLWU_P12/SPI0_PCS0/UART2_RTS/FTM3_CH0/FB_ALE/FB_CS1/FB_TS
#define D10_PORT        D     // Port Name
#define D10_NUM         0     // Port pin
#define D10_ACH         4     // ADC channel
#define D10_FTM         3     // FTM
#define D10_FTM_CH      0     // FTM channel

// PTD2/LLWU_P13/SPI0_SOUT/UART2_RX/FTM3_CH2/FB_AD4/I2C0_SCL
#define D11_PORT        D     // Port Name
#define D11_NUM         2     // Port pin
#define D11_FTM         3     // FTM
#define D11_FTM_CH      2     // FTM channel

// PTD3/SPI0_SIN/UART2_TX/FTM3_CH3/FB_AD3/I2C0_SDA
#define D12_PORT        D     // Port Name
#define D12_NUM         3     // Port pin
#define D12_FTM         3     // FTM
#define D12_FTM_CH      3     // FTM channel

// PTD1/ADC0_SE5B/SPI0_SCK/UART2_CTS/FTM3_CH1/FB_CS0
#define D13_PORT        D     // Port Name
#define D13_NUM         1     // Port pin
#define D13_ACH         5     // ADC channel
#define D13_FTM         3     // FTM
#define D13_FTM_CH      1     // FTM channel

// PTE25/ADC0_SE18/UART4_RX/I2C0_SDA/EWM_IN
#define D14_PORT        E     // Port Name
#define D14_NUM         25    // Port pin
#define D14_ACH         18    // ADC channel

// PTE24/ADC0_SE17/UART4_TX/I2C0_SCL/EWM_OUT
#define D15_PORT        E     // Port Name
#define D15_NUM         24    // Port pin
#define D15_ACH         17    // ADC channel

#endif

#endif /* TUTORIAL_H_ */
