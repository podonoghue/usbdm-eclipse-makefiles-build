/*
 * Delay.cpp
 *
 *  Created on: 8 Aug 2014
 *      Author: podonoghue
 */

#include "Delay.h"

/**
 * Provide an approximate delay in us
 */
void Delay::delayUS(unsigned us) {
   for (unsigned i=0; i<4*us; i++) {
      __asm__("nop");
   }
}

/**
 * Provide an approximate delay in ms
 */
void Delay::delayMS(unsigned ms) {
   for (unsigned i=0; i<ms; i++) {
      delayUS(1000);
   }
}

