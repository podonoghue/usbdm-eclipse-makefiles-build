/*
 * pwm.h
 *
 *  Created on: 13/11/2013
 *      Author: podonoghue
 */

#ifndef TPM0_H_
#define TPM0_H_

#include "clock.h"
#include "clock_private.h"
#include "derivative.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * TPM Clock sources
 */
#define _TPM0_CLOCK0 (0) // Disabled
#define _TPM0_CLOCK1 SYSTEM_TPM_CLOCK
#define _TPM0_CLOCK2 SYSTEM_PERIPHERAL_CLOCK
#define _TPM0_CLOCK3 (0) // External TPM_CLKINx clock - not defined

#define _TPM0_CLOCK_FREQUENCY_BASE  _TPM0_CLOCK2

// Choice of prescale value (FTM0_SC.PS)
#define _TPM0_PRESCALE_VALUE    (7)
#define _TPM0_PRESCALE          (1<<_TPM0_PRESCALE_VALUE)
#define TPM0_CLOCK_FREQUENCY    (_TPM0_CLOCK_FREQUENCY_BASE/_TPM0_PRESCALE)

//! Macro to convert milliseconds to TPM0 ticks
#define TPM0_MILLISECONDS_TO_TICKS(ms)    (((ms)*TPM0_CLOCK_FREQUENCY)/1000)

typedef enum  {
   tpm_inputCaptureRisingEdge  = TPM_CnSC_ELSA_MASK,
   tpm_inputCaptureFallingEdge = TPM_CnSC_ELSB_MASK,
   tpm_inputCaptureEitherEdge  = TPM_CnSC_ELSB_MASK|TPM_CnSC_ELSA_MASK,
   tpm_outputCompare           = TPM_CnSC_MSA_MASK,
   tpm_outputCompareToggle     = TPM_CnSC_MSA_MASK|TPM_CnSC_ELSA_MASK,
   tpm_outputCompareClear      = TPM_CnSC_MSA_MASK|TPM_CnSC_ELSB_MASK,
   tpm_outputCompareSet        = TPM_CnSC_MSA_MASK|TPM_CnSC_ELSB_MASK|TPM_CnSC_ELSA_MASK,
   tpm_pwmHighTruePulses       = TPM_CnSC_MSB_MASK|TPM_CnSC_ELSB_MASK,
   tpm_pwmLowTruePulses        = TPM_CnSC_MSB_MASK|TPM_CnSC_ELSA_MASK,
} Ftm_Mode;

typedef enum {
   tpm_leftAlign   = 0,
   tpm_centreAlign = TPM_SC_CPWMS_MASK,
} Pwm_Mode;

void tpm0_initialise(void);
void tpm0_initialiseAsPWM(int period /* ticks */, Pwm_Mode mode);
void tpm0_setDutyCycle(int channel, int dutyCycle);

void tpm0_initialiseChannel(int channel, Ftm_Mode mode);
void tpm0_finaliseChannel(int channel);

#ifndef TPM0_USES_NAKED_HANDLERS
   typedef void (*TPMCallbackFunction)(void);
   TPMCallbackFunction tpm0_setCallbackFunction(int channel, TPMCallbackFunction callback, uint16_t interval);
#endif

#ifdef __cplusplus
}
#endif

#endif /* TPM0_H_ */
