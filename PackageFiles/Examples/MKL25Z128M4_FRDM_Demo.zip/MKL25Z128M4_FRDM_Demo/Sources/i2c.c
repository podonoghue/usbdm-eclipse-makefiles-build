/*
 * i2c.c
 *
 *  Created on: 22/11/2013
 *      Author: podonoghue
 */
#include <stdbool.h>
#include <stdio.h>
#include "derivative.h"
#include "utilities.h"
#include "Freedom.h"
#include "clock.h"
#include "clock_private.h"
#include "i2c.h"

#define I2C_F_MULT_VALUE    (0)
#define I2C_F_ICR_VALUE     (0x14) // SCL diver = 34, See table 44-28 in RM

#if (I2C_F_MULT_VALUE>2)
#error "I2C_F_MULT_VALUE is too large"
#endif
#if (I2C_F_ICR_VALUE>=(1<<6))
#error "I2C_F_ICR_VALUE is too large"
#endif

#define I2C_BAUD_RATE SYSTEM_BUS_CLOCK/((1<<I2C_F_MULT_VALUE)*34)

enum {i2c_idle, i2c_txAddr, i2c_rxAddr, i2c_rxAddr2, i2c_txRegAddr, i2c_rxRegAddr, i2c_txData, i2c_rxData } i2cMode;
uint8_t *dataPtr;
int      dataBytesRemaining;
uint8_t deviceAddress;

void I2C0_IRQHandler(void);

/*
 * Initialise the I2C interface
 *
 * @param slaveAddress - not used as slave interface is not handled.
 *
 */
void i2c_initialise(uint8_t slaveAddress) {

   // Configure I2C pins
   SIM_SCGC5 |= I2C_SCL_CLOCK_MASK|I2C_SDA_CLOCK_MASK;
#ifndef PORT_PCR_ODE_MASK
// Some devices don't have ODE function on pin
#define PORT_PCR_ODE_MASK 0
#endif
   PCR(I2C_SCL_PORT,I2C_SCL_PIN_NUM) = PORT_PCR_MUX(I2C_SCL_FN)|PORT_PCR_ODE_MASK;
   PCR(I2C_SDA_PORT,I2C_SDA_PIN_NUM) = PORT_PCR_MUX(I2C_SDA_FN)|PORT_PCR_ODE_MASK;

   // Enable clock to I2C interface
   SIM_SCGC4 |=SIM_SCGC4_I2C0_MASK;

   // Enable I2C peripheral
   I2C0_C1 = I2C_C1_IICEN_MASK;

   // Set baud rate
   I2C0_F  = I2C_F_MULT(I2C_F_MULT_VALUE)|I2C_F_ICR(I2C_F_ICR_VALUE);

   // Default options
   I2C0_C2 = 0;//I2C_C2_AD(address>>8);
   I2C0_A1 = slaveAddress&~1;

   NVIC_EnableIRQ(I2C0_IRQn);
}

typedef enum {
   i2c_polled    = 0,
   i2c_interrupt = I2C_C1_IICIE_MASK,
} i2c_Mode;

/*!
 * Start TxRx sequence
 *
 * Sets up data pointer and size
 * Starts transmission of the address byte
 *
 * @param address - address of slave to access
 * @param data    - data in/out buffer
 * @param size    - size of buffer to transfer
 * @param mode    - either i2c_polled or i2c_interrupt mode
 */
static void i2c_startTxRx(uint8_t address, uint8_t data[], int size, i2c_Mode mode) {

   // Set up transmit or receive data
   dataPtr            = data;
   dataBytesRemaining = size;

   // Configure for Tx of address
   I2C0_C1 = I2C_C1_IICEN_MASK|mode|I2C_C1_TX_MASK;
   // Generate START
   I2C0_C1 = I2C_C1_IICEN_MASK|mode|I2C_C1_TX_MASK|I2C_C1_MST_MASK;

   deviceAddress = address;

   // Tx address (starts interrupt process)
   I2C0_D  = I2C_D_DATA(address);
}

/*!
 * Start Tx sequence
 *
 * Sets mode = i2c_txAddr
 * Sets up data pointer and size
 * Starts transmission of the address byte
 *
 * @param address - address of slave to access
 * @param data    - data in/out buffer
 * @param size    - size of buffer to transfer
 */
void i2c_startTransmit(uint8_t address, uint8_t data[], int size, i2c_Mode mode) {
   // Sending address byte of data transmission
   i2cMode = i2c_txAddr;
   i2c_startTxRx(address, data, size, mode);
}

/*!
 * Start Rx sequence
 *
 * Sets mode = i2c_rxAddr
 * Sets up data pointer and size
 * Starts transmission of the address byte
 *
 * @param address - address of slave to access
 * @param data    - data in/out buffer
 * @param size    - size of buffer to transfer
 */
void i2c_startReceive(uint8_t address, uint8_t data[], int size, i2c_Mode mode) {
   // Sending address byte of data reception
   i2cMode = i2c_rxAddr;
   i2c_startTxRx(address, data, size, mode);
}

/*
 * Wait for current sequence to complete
 */
void i2c_waitWhileBusy(void) {
   while (i2cMode != i2c_idle) {
      I2C0_IRQHandler();
   }
}

/*!
 * Transmit data to slave and wait for completion
 *
 * @param address - address of slave to access
 * @param data    - data in/out buffer
 * @param size    - size of buffer to transfer
 */
void i2c_transmit(uint8_t address, uint8_t data[], int size) {
   i2c_startTransmit(address, data, size, i2c_polled);
   i2c_waitWhileBusy();
}

/*!
 * Receive data from slave and wait for completion
 *
 * @param address - address of slave to access
 * @param data    - data in/out buffer
 * @param size    - size of buffer to transfer
 */
void i2c_receive(uint8_t address, uint8_t data[], int size) {
   i2c_startReceive(address, data, size, i2c_polled);
   i2c_waitWhileBusy();
}

/*
 * I2C state-machine based interrupt handler
 */
void I2C0_IRQHandler(void) {
   if ((I2C0_S & I2C_S_IICIF_MASK) == 0) {
      return;
   }
   // Clear interrupt flag
   I2C0_S = I2C_S_IICIF_MASK;

//   if ((I2C0_S&I2C_S_RXAK_MASK) != 0) {
//      // Failed
//      i2cMode = i2c_idle;
//      // Generate stop signal
//      I2C0_C1 = I2C_C1_IICEN_MASK|I2C_C1_IICIE_MASK|I2C_C1_TXAK_MASK;
//      return;
//   }

   switch (i2cMode) {
      case i2c_idle:
      default:
         i2cMode = i2c_idle;
         break;

      case i2c_txAddr:
         // Just sent address byte at start of Tx transaction
         // Transmit register address byte
         i2cMode = i2c_txRegAddr;
         I2C0_D = *dataPtr++;
         break;

      case i2c_txRegAddr:
         // Just sent register address byte at start of Tx data
      case i2c_txData:
         // Just sent data byte
         if (--dataBytesRemaining == 0) {
            // Complete
            i2cMode = i2c_idle;
            // Generate stop signal
            I2C0_C1 = I2C_C1_IICEN_MASK|I2C_C1_TXAK_MASK;
            return;
         }
         else {
            // Transmit next byte
            i2cMode = i2c_txData;
            I2C0_D = *dataPtr++;
         }
         break;

      case i2c_rxAddr:
         // Just sent device address byte at start of Rx transaction
         // Transmit register address byte
         i2cMode = i2c_rxRegAddr;
         I2C0_D = *dataPtr;
         break;

      case i2c_rxRegAddr:
         // Just sent register address byte at start of Rx transaction
         i2cMode = i2c_rxAddr2;
         i2cMode = i2c_rxAddr2;
         i2cMode = i2c_rxAddr2;
         i2cMode = i2c_rxAddr2;
         // Send repeated start
         I2C0_C1 = I2C_C1_IICEN_MASK|I2C_C1_TX_MASK|I2C_C1_MST_MASK|I2C_C1_RSTA_MASK;
         // Send device address again with READ bit set
         I2C0_D = deviceAddress|1;
         break;

      case i2c_rxAddr2:
         // Just sent device address byte at start of Rx data phase
         i2cMode = i2c_rxData;
         // Change to reception
         if (dataBytesRemaining == 1) {
            // Receiving only single byte (don't acknowledge the byte)
            I2C0_C1 = I2C_C1_IICEN_MASK|I2C_C1_MST_MASK|I2C_C1_TXAK_MASK;
         }
         else {
            I2C0_C1 = I2C_C1_IICEN_MASK|I2C_C1_MST_MASK;
         }
//          Dummy read
         (void)I2C0_D;
         break;

      case i2c_rxData:
         // Just received a data byte
         if (--dataBytesRemaining == 0) {
            // Received last byte - complete
            i2cMode = i2c_idle;
            // Generate STOP
            I2C0_C1 = I2C_C1_IICEN_MASK;
         }
         else if (dataBytesRemaining == 1) {
            // Received 2nd last byte (don't acknowledge the last byte to follow)
            I2C0_C1 = I2C_C1_IICEN_MASK|I2C_C1_MST_MASK|I2C_C1_TXAK_MASK;
         }
         // Save receive data
         *dataPtr++ = I2C0_D;
         break;
   }
}

