/*
 *  Include the derivative-specific header file
 */
//#include "MK20DX128M5.h"
#include "FRDM_K20D50M.h"
