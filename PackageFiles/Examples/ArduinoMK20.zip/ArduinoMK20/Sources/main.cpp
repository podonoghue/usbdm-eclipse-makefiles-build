/*
 ============================================================================
 * main.c
 *
 *  Created on: 04/12/2012
 *      Author: podonoghue
 ============================================================================
 */
#include <stdio.h>
#include "system.h"
#include "derivative.h"
#include "utilities.h"
#include "GPIO.h"
#include "I2C.h"
#include "HMC5883L.h"
#include "MMA845x.h"
#include "PCA9685.h"
#include "Motor.h"
#include "GT20L16.h"
#include "Seeed_SLD00200P.h"
#include "EPD.h"
#include "EPaper.h"

// Simple delay - not for real programs!
void delay(void) {
   for(int i=0; i<400000; i++) {
      __asm__("nop");
   }
}

void shortDelay(void) {
   for(int i=0; i<400; i++) {
      __asm__("nop");
   }
}

#define EXAMPLE 0

#if EXAMPLE == 0

#ifdef MCU_MKL25Z4
#define RED_LED   digitalIO_PTB18
#define GREEN_LED digitalIO_PTB19
#define BLUE_LED  digitalIO_PTD1
#endif
#ifdef MCU_MK20D5
#define RED_LED   digitalIO_PTC3
#define GREEN_LED digitalIO_PTD4
#define BLUE_LED  digitalIO_PTD9
#endif

int main() {
   RED_LED.setDigitalOutput();
   GREEN_LED.setDigitalOutput();
   BLUE_LED.setDigitalOutput();
   RED_LED.set();
   GREEN_LED.set();
   BLUE_LED.set();
   for(;;) {
      RED_LED.toggle();
      delay();
      RED_LED.toggle();
      delay();
      GREEN_LED.toggle();
      delay();
      GREEN_LED.toggle();
      delay();
      BLUE_LED.toggle();
      delay();
      BLUE_LED.toggle();
      delay();
   }
}
#endif

#if EXAMPLE == 1

#ifdef MCU_MKL25Z4
#define RED_LED   pwmIO_PTB18
#define GREEN_LED pwmIO_PTB19
#define BLUE_LED  pwmIO_PTD1
#endif
#ifdef MCU_MK20D5
#define RED_LED   pwmIO_PTC3
#define GREEN_LED pwmIO_PTD4
#define BLUE_LED  pwmIO_PTD9
#endif

int main() {
   RED_LED.setPwmOutput(2000,   PwmIO::ftm_leftAlign);
   GREEN_LED.setPwmOutput(2000, PwmIO::ftm_leftAlign);
   BLUE_LED.setPwmOutput(2000,  PwmIO::ftm_leftAlign);
   for(;;) {
      for (int i=0; i<=100; i++) {
         RED_LED.setDutyCycle(i);
         delay();
      }
      for (int i=0; i<=100; i++) {
         GREEN_LED.setDutyCycle(i);
         delay();
      }
      for (int i=0; i<=100; i++) {
         BLUE_LED.setDutyCycle(i);
         delay();
      }
   }
}
#endif

#if EXAMPLE == 2
// Joystick
// 2 x Analogue input
// 1 x Digital input

// Connection mapping
#define JOYSTICK_X   analogueIO_A2
#define JOYSTICK_Y   analogueIO_A1
#define JOYSTICK_K   digitalIO_A0

int main(void) {
   JOYSTICK_X.setAnalogueInput();
   JOYSTICK_Y.setAnalogueInput();
   JOYSTICK_K.setDigitalInput();

   for(;;) {
      int  x = JOYSTICK_X.readAnalogue();
      int  y = JOYSTICK_Y.readAnalogue();
      bool k = JOYSTICK_K.read();
      printf("Joystick (X,Y,Z) = (%7d, %7d, %s)\n", x, y, k?"HIGH":"LOW");
      delay();
   }
}
#endif

#if EXAMPLE == 3
// SWITCH + LED
// 1 x Digital input
// 1 x Digital output

// Connection mapping
#define SWITCH    digitalIO_D12
#define LED       digitalIO_D13

int main(void) {
   LED.setDigitalOutput();
   SWITCH.setDigitalInput();

   for(;;) {
      LED.write(!SWITCH.read());
   }
}
#endif

#if EXAMPLE == 4
// I2C interface
// HMC5883L Compass (external) + MMA845x Accelerometer (on FRDM-K20 board)
//
int main(void) {

   I2C      *i2c0          = new I2C_0(0x00);

   HMC5883L *compass       = new HMC5883L(i2c0);
   MMA845x  *accelerometer = new MMA845x(i2c0, MMA845x::MMA45x_2Gmode);

   uint32_t id = compass->readID();
   printf("Compass ID = 0x%6lX (should be 0x483433)\n", id);

   compass->setGain(1);
   accelerometer->setMode(MMA845x::MMA45x_2Gmode);

   int16_t compassX,compassY,compassZ;
   int16_t accelerometerX,accelerometerY,accelerometerZ;
   int accelerometerXStatus;

   for(;;) {
      compass->doMeasurement(&compassX, &compassY, &compassZ);
      accelerometer->readXYX(&accelerometerXStatus, &accelerometerX, &accelerometerY, &accelerometerZ);
      printf("Compass = (%5d %5d %5d), Accelerometer = (%7d %7d %7d)\n",
             compassX, compassY, compassZ, accelerometerX, accelerometerY, accelerometerZ);
      delay();
   }
}
#endif

#if EXAMPLE == 5
// I2C
// Motor controller (Adafruit Motor-shield V2)
//
int main(void) {
#ifdef MCU_MK20D5
   I2C   *i2c   = new I2C_0(0x00);
#endif
#ifdef MCU_MK22F51212 || defined(MCU_MK64F12)
   I2C   *i2c   = new I2C_1(0x00);
#endif

   Motor *motor = new Motor(i2c);

   for(;;) {
      motor->setMotor2(Motor::CW,  1000);
      motor->setMotor2(Motor::CCW, 1000);
      motor->setMotor2(Motor::CW,  0);
      motor->setMotor2(Motor::CCW, 0);
      motor->setMotor2(Motor::CW,  4000);
      motor->setMotor2(Motor::CCW, 4000);
   }
}
#endif

#if EXAMPLE == 6
// I2C interface
// MMA845x Accelerometer (on FRDM-K20 board)
//
int main(void) {

   I2C      *i2c0          = new I2C_0(0x00, I2C::interrupt);
   MMA845x  *accelerometer = new MMA845x(i2c0, MMA845x::MMA45x_2Gmode);

   accelerometer->setMode(MMA845x::MMA45x_2Gmode);

   int16_t accelerometerX,accelerometerY,accelerometerZ;
   int accelerometerXStatus;

   for(;;) {
      accelerometer->readXYX(&accelerometerXStatus, &accelerometerX, &accelerometerY, &accelerometerZ);
      printf("Accelerometer = (%5d %5d %5d)\n", accelerometerX, accelerometerY, accelerometerZ);
      delay();
   }
}
#endif

#if EXAMPLE == 7
// 'Arduino' motor shield
// Elecfreaks L298 Motor Shield SHD-L298N or similar
// Assumes swapped inputs D6<->D7 to allow PWM (link option on board)
#define M2_DIRECTION digitalIO_D4
#define M2_ENABLE    pwmIO_D5
#define M1_DIRECTION digitalIO_D6
#define M1_ENABLE    pwmIO_D7

#define PWM_PERIOD (10000)
enum {
   CW = false,
   CCW = true,
};

int main(void) {
   M1_ENABLE.setPwmOutput(PWM_PERIOD, PwmIO::ftm_leftAlign);
   M1_DIRECTION.setDigitalOutput();
   M2_ENABLE.setPwmOutput(PWM_PERIOD, PwmIO::ftm_leftAlign);
   M2_DIRECTION.setDigitalOutput();

   M1_ENABLE.setDutyCycle(50);
   M2_ENABLE.setDutyCycle(50);

   M1_DIRECTION.write(CW);
   M2_DIRECTION.write(CCW);

   for(;;) {
      for (int i=0; i<=100; i++) {
         M1_ENABLE.setDutyCycle(i);
         M2_ENABLE.setDutyCycle(i);
         shortDelay();
      }
   }
}
#endif

#if EXAMPLE == 8

int main(void) {

   printf("Starting\n");

   // Set 1ms tick rate
   SysTick_Config(SystemCoreClock/1000);

   // Disable SD card
   SD_Pin_CS.setDigitalOutput();
   SD_Pin_CS.set();

   TOGGLE.setDigitalOutput();
   TOGGLE.clear();
#if defined(MCU_MK20D5) || defined(MCU_MK64F12)
   SPI      *spi     = new SPI_0();
#endif
#ifdef MCU_MK22F51212
   SPI      *spi     = new SPI_1();
#endif
   GT20L16  *gt20l16 = new GT20L16(spi);
   EPaper   *ePaper  = new EPaper(gt20l16, spi, EPD_2_7);

//   ePaper->clearCanvas();
//   ePaper->displayCanvas();

//   ePaper->clearDisplay();
   for(;;) {
      unsigned x;
      unsigned y;
      ePaper->setOrientation(EPaper::LANDSCAPE);
      ePaper->clearCanvas();
      ePaper->drawRectangle(0, 0, 40, 20);
      ePaper->drawString("L-TL", 3, 3);
      ePaper->drawString("<- Landscape ->", 80, 50);
      ePaper->drawString("SeeedStudio 12345 -1.25", 80, 90);
      x = ePaper->getWidth()-40-1;
      y = ePaper->getHeight()-20-1;
      ePaper->drawString("L-BR", x+3, y+3);
      ePaper->drawRectangle(x, y, 40, 20);
      ePaper->displayCanvas();

      ePaper->setOrientation(EPaper::PORTRAIT);
//      ePaper->clearCanvas();
      ePaper->drawRectangle(0, 0, 40, 20);
      ePaper->drawString("P-TL", 3, 3);
      ePaper->drawString("<- Portrait ->", 40, 50);
      x = ePaper->getWidth()-40-1;
      y = ePaper->getHeight()-20-1;
      ePaper->drawString("P-BR", x+3, y+3);
      ePaper->drawRectangle(x, y, 40, 20);
      ePaper->displayCanvas();

      ePaper->setOrientation(EPaper::LANDSCAPE);
      ePaper->setInvertY(false);
      ePaper->setWriteMode(EPaper::XORMODE);
//      int width  = ePaper->getWidth();
//      int height = ePaper->getHeight();
      ePaper->clearCanvas();
//      ePaper->drawLine(0,  0, width-1,  0);
//      ePaper->drawLine(0, 10, width-1, 10);
//      ePaper->drawString("XXXX",  60, 0);

      ePaper->setInvertY(true);
      ePaper->setWriteMode(EPaper::PAINTMODE);
//      ePaper->drawLine(0, 10, 200, 10);
//      ePaper->drawLine(0,  0, width-1,  0);
      ePaper->drawFilledRectangle( 50, 10, 50, 100);
      ePaper->drawRectangle(150, 10, 50, 120);
      ePaper->setWriteMode(EPaper::XORMODE);
      ePaper->drawString("RESP", 60, 10);
      ePaper->drawString("TEMP", 160, 10);
//      ePaper->drawFilledRectangle( 60, 60, 80, 80);
//      ePaper->drawFilledCircle( 120, 120, 50);
      ePaper->displayCanvas();
      ePaper->displayCanvas();
      for(;;){
         __WFI();
      }
   }
}
#endif
