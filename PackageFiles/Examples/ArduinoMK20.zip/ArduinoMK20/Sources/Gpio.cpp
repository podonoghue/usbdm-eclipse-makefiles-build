/*
 * Gpio.cpp
 *
 *  Created on: 09/07/2014
 *      Author: podonoghue
 */

#include "utilities.h"
#include "Gpio.h"
#include "ArduinoKinetis.h"
#include "clock_configure.h"

namespace Arduino {

#define PORT_PCR (PORT_PCR_DSE_MASK|PORT_PCR_PE_MASK|PORT_PCR_PS_MASK) // PCR setting for ports (w/o MUX)

#define ADC(num) CONCAT2_(ADC,num)
#define FTM(num) CONCAT2_(FTM,num)

static const AnalogueIO::AnalogueIOData A0_data  = {{PORT_CLOCK_MASK(A0_PORT),  &PCR(A0_PORT,  A0_NUM),  PORT_PCR, GPIO(A0_PORT),  (1<<A0_NUM)},
                                                   ADC(A0_ADC_NUM), A0_ACH};
static const AnalogueIO::AnalogueIOData A1_data  = {{PORT_CLOCK_MASK(A1_PORT),  &PCR(A1_PORT,  A1_NUM),  PORT_PCR, GPIO(A1_PORT),  (1<<A1_NUM)},
                                                   ADC(A1_ADC_NUM), A1_ACH};
static const AnalogueIO::AnalogueIOData A2_data  = {{PORT_CLOCK_MASK(A2_PORT),  &PCR(A2_PORT,  A2_NUM),  PORT_PCR, GPIO(A2_PORT),  (1<<A2_NUM)},
                                                   ADC(A2_ADC_NUM), A2_ACH};
static const AnalogueIO::AnalogueIOData A3_data  = {{PORT_CLOCK_MASK(A3_PORT),  &PCR(A3_PORT,  A3_NUM),  PORT_PCR, GPIO(A3_PORT),  (1<<A3_NUM)},
                                                   ADC(A3_ADC_NUM), A3_ACH};
static const AnalogueIO::AnalogueIOData A4_data  = {{PORT_CLOCK_MASK(A4_PORT),  &PCR(A4_PORT,  A4_NUM),  PORT_PCR, GPIO(A4_PORT),  (1<<A4_NUM)},
                                                   ADC(A4_ADC_NUM), A4_ACH};
static const AnalogueIO::AnalogueIOData A5_data  = {{PORT_CLOCK_MASK(A5_PORT),  &PCR(A5_PORT,  A5_NUM),  PORT_PCR, GPIO(A5_PORT),  (1<<A5_NUM)},
                                                   ADC(A5_ADC_NUM), A5_ACH};

static const DigitalIO::DigitalIOData D0_data  = {PORT_CLOCK_MASK(D0_PORT),  &PCR(D0_PORT,  D0_NUM),  PORT_PCR, GPIO(D0_PORT),  (1<<D0_NUM)};
static const DigitalIO::DigitalIOData D1_data  = {PORT_CLOCK_MASK(D1_PORT),  &PCR(D1_PORT,  D1_NUM),  PORT_PCR, GPIO(D1_PORT),  (1<<D1_NUM)};
static const DigitalIO::DigitalIOData D2_data  = {PORT_CLOCK_MASK(D2_PORT),  &PCR(D2_PORT,  D2_NUM),  PORT_PCR, GPIO(D2_PORT),  (1<<D2_NUM)};
static const DigitalIO::DigitalIOData D3_data  = {PORT_CLOCK_MASK(D3_PORT),  &PCR(D3_PORT,  D3_NUM),  PORT_PCR, GPIO(D3_PORT),  (1<<D3_NUM)};
static const DigitalIO::DigitalIOData D4_data  = {PORT_CLOCK_MASK(D4_PORT),  &PCR(D4_PORT,  D4_NUM),  PORT_PCR, GPIO(D4_PORT),  (1<<D4_NUM)};
static const PwmIO::PwmIOData D5_data          = {{PORT_CLOCK_MASK(D5_PORT),  &PCR(D5_PORT,  D5_NUM),  PORT_PCR, GPIO(D5_PORT),  (1<<D5_NUM)},
                                                 FTM(D5_FTM), D5_FTM_CH, PORT_PCR_MUX(D5_FTM_FN)};
static const PwmIO::PwmIOData D6_data          = {{PORT_CLOCK_MASK(D6_PORT),  &PCR(D6_PORT,  D6_NUM),  PORT_PCR, GPIO(D6_PORT),  (1<<D6_NUM)},
                                                 FTM(D6_FTM), D6_FTM_CH, PORT_PCR_MUX(D6_FTM_FN)};
static const PwmIO::PwmIOData D7_data          = {{PORT_CLOCK_MASK(D7_PORT),  &PCR(D7_PORT,  D7_NUM),  PORT_PCR, GPIO(D7_PORT),  (1<<D7_NUM)},
                                                 FTM(D7_FTM), D7_FTM_CH, PORT_PCR_MUX(D7_FTM_FN)};
static const DigitalIO::DigitalIOData D8_data  = {PORT_CLOCK_MASK(D8_PORT),  &PCR(D8_PORT,  D8_NUM),  PORT_PCR, GPIO(D8_PORT),  (1<<D8_NUM)};
static const DigitalIO::DigitalIOData D9_data  = {PORT_CLOCK_MASK(D9_PORT),  &PCR(D9_PORT,  D9_NUM),  PORT_PCR, GPIO(D9_PORT),  (1<<D9_NUM)};
static const DigitalIO::DigitalIOData D10_data = {PORT_CLOCK_MASK(D10_PORT), &PCR(D10_PORT, D10_NUM), PORT_PCR, GPIO(D10_PORT), (1<<D10_NUM)};
static const DigitalIO::DigitalIOData D11_data = {PORT_CLOCK_MASK(D11_PORT), &PCR(D11_PORT, D11_NUM), PORT_PCR, GPIO(D11_PORT), (1<<D11_NUM)};
static const DigitalIO::DigitalIOData D12_data = {PORT_CLOCK_MASK(D12_PORT), &PCR(D12_PORT, D12_NUM), PORT_PCR, GPIO(D12_PORT), (1<<D12_NUM)};
static const DigitalIO::DigitalIOData D13_data = {PORT_CLOCK_MASK(D13_PORT), &PCR(D13_PORT, D13_NUM), PORT_PCR, GPIO(D13_PORT), (1<<D13_NUM)};
static const DigitalIO::DigitalIOData D14_data = {PORT_CLOCK_MASK(D14_PORT), &PCR(D14_PORT, D14_NUM), PORT_PCR, GPIO(D14_PORT), (1<<D14_NUM)};
static const DigitalIO::DigitalIOData D15_data = {PORT_CLOCK_MASK(D15_PORT), &PCR(D15_PORT, D15_NUM), PORT_PCR, GPIO(D15_PORT), (1<<D15_NUM)};

static const DigitalIO::DigitalIOData D16_data = {PORT_CLOCK_MASK(D16_PORT), &PCR(D16_PORT, D16_NUM), PORT_PCR, GPIO(D16_PORT), (1<<D16_NUM)};
static const DigitalIO::DigitalIOData D17_data = {PORT_CLOCK_MASK(D17_PORT), &PCR(D17_PORT, D17_NUM), PORT_PCR, GPIO(D17_PORT), (1<<D17_NUM)};
static const DigitalIO::DigitalIOData D18_data = {PORT_CLOCK_MASK(D18_PORT), &PCR(D18_PORT, D18_NUM), PORT_PCR, GPIO(D18_PORT), (1<<D18_NUM)};
static const DigitalIO::DigitalIOData D19_data = {PORT_CLOCK_MASK(D19_PORT), &PCR(D19_PORT, D19_NUM), PORT_PCR, GPIO(D19_PORT), (1<<D19_NUM)};
static const DigitalIO::DigitalIOData D20_data = {PORT_CLOCK_MASK(D20_PORT), &PCR(D20_PORT, D20_NUM), PORT_PCR, GPIO(D20_PORT), (1<<D20_NUM)};
static const DigitalIO::DigitalIOData D21_data = {PORT_CLOCK_MASK(D21_PORT), &PCR(D21_PORT, D21_NUM), PORT_PCR, GPIO(D21_PORT), (1<<D21_NUM)};
static const DigitalIO::DigitalIOData D22_data = {PORT_CLOCK_MASK(D22_PORT), &PCR(D22_PORT, D22_NUM), PORT_PCR, GPIO(D22_PORT), (1<<D22_NUM)};
static const DigitalIO::DigitalIOData D23_data = {PORT_CLOCK_MASK(D23_PORT), &PCR(D23_PORT, D23_NUM), PORT_PCR, GPIO(D23_PORT), (1<<D23_NUM)};
static const DigitalIO::DigitalIOData D24_data = {PORT_CLOCK_MASK(D24_PORT), &PCR(D24_PORT, D24_NUM), PORT_PCR, GPIO(D24_PORT), (1<<D24_NUM)};
static const DigitalIO::DigitalIOData D25_data = {PORT_CLOCK_MASK(D25_PORT), &PCR(D25_PORT, D25_NUM), PORT_PCR, GPIO(D25_PORT), (1<<D25_NUM)};

const AnalogueIO    gpioA0(&A0_data);
const AnalogueIO    gpioA1(&A1_data);
const AnalogueIO    gpioA2(&A2_data);
const AnalogueIO    gpioA3(&A3_data);
const AnalogueIO    gpioA4(&A4_data); // Conflicts with KL25-I2C1
const AnalogueIO    gpioA5(&A5_data); // Conflicts with KL25-I2C1

const DigitalIO     gpioD0(&D0_data);
const DigitalIO     gpioD1(&D1_data); // Conflicts with KL25-UART0
const DigitalIO     gpioD2(&D2_data); // Conflicts with KL25-UART0
const DigitalIO     gpioD3(&D3_data);
const DigitalIO     gpioD4(&D4_data);
const PwmIO         gpioD5(&D5_data);
const PwmIO         gpioD6(&D6_data);
const PwmIO         gpioD7(&D7_data);

const DigitalIO     gpioD8(&D8_data);
const DigitalIO     gpioD9(&D9_data);
const DigitalIO     gpioD10(&D10_data);
const DigitalIO     gpioD11(&D11_data);
const DigitalIO     gpioD12(&D12_data);
const DigitalIO     gpioD13(&D13_data);
const DigitalIO     gpioD14(&D14_data);
const DigitalIO     gpioD15(&D15_data);
const DigitalIO     gpioD16(&D16_data);

const DigitalIO     gpioD17(&D17_data);
const DigitalIO     gpioD18(&D18_data);
const DigitalIO     gpioD19(&D19_data);
const DigitalIO     gpioD20(&D20_data);
const DigitalIO     gpioD21(&D21_data);
const DigitalIO     gpioD22(&D22_data);
const DigitalIO     gpioD23(&D23_data);
const DigitalIO     gpioD24(&D24_data);
const DigitalIO     gpioD25(&D25_data);


/*
 * Initialise the ADC
 */
void AnalogueIO::initialiseADC(void) const {

   // Enables clock to ADCs
   SIM_SCGC6 |= SIM_SCGC6_ADC0_MASK;

#ifdef SIM_SCGC6_ADC1_MASK
   SIM_SCGC6 |= SIM_SCGC6_ADC1_MASK;
#endif

#ifdef SIM_SCGC3_ADC1_MASK
   SIM_SCGC3 |= SIM_SCGC3_ADC1_MASK;
#endif

   // Configure ADC for software triggered conversion
   analogueData->adc->CFG1 = ADC_CFG1_ADIV(1)|ADC_CFG1_MODE(1)|ADC_CFG1_ADLSMP_MASK|ADC_CFG1_ADICLK(0);
   analogueData->adc->SC2  = 0;
   analogueData->adc->CFG2 = ADC_CFG2_ADLSTS(0)|ADC_CFG2_MUXSEL_MASK; // Choose 'b' channels
}

/*
 * Initiates a conversion and waits for it to complete
 *
 * @return - the result of the conversion
 */
int AnalogueIO::doADCConversion() const {

   // Trigger conversion
   analogueData->adc->SC1A = ADC_SC1_ADCH(analogueData->adcChannel);

   while ((analogueData->adc->SC1A&ADC_SC1_COCO_MASK) == 0) {
      __asm__("nop");
   }
   return (int)analogueData->adc->RA;
}

/*
 * FTM Clock sources
 */
#define _FTM0_CLOCK0 (0) // Disabled
#define _FTM0_CLOCK1 SYSTEM_CORE_CLOCK
#define _FTM0_CLOCK2 SYSTEM_MCGFFCLK_CLOCK
#define _FTM0_CLOCK3 (0) // External FTM_CLKINx clock - not defined

#define _FTM0_CLOCK_FREQUENCY_BASE  _FTM0_CLOCK1

#if (_FTM0_CLOCK_FREQUENCY_BASE == _FTM0_CLOCK0)
#define FTM_SC_CLKS_VALUE (0)
#elif (_FTM0_CLOCK_FREQUENCY_BASE == _FTM0_CLOCK1)
#define FTM_SC_CLKS_VALUE (1)
#elif (_FTM0_CLOCK_FREQUENCY_BASE == _FTM0_CLOCK2)
#define FTM_SC_CLKS_VALUE (2)
#elif (_FTM0_CLOCK_FREQUENCY_BASE == _FTM0_CLOCK3)
#define FTM_SC_CLKS_VALUE (3)
#else
#error "Check _FTM0_CLOCK_FREQUENCY_BASE value in pwm.h"
#endif

// Choice of prescale value (FTM0_SC.PS)
#define _FTM0_PRESCALE_VALUE    (7)
#define _FTM0_PRESCALE          (1<<_FTM0_PRESCALE_VALUE)
#define FTM0_CLOCK_FREQUENCY    (_FTM0_CLOCK_FREQUENCY_BASE/_FTM0_PRESCALE)

//! Macro to convert milliseconds to FTM0 ticks
#define FTM0_MILLISECONDS_TO_TICKS(ms)    (((ms)*FTM0_CLOCK_FREQUENCY)/1000)
//! Macro to convert microseconds to FTM0 ticks
#define FTM0_MICROSECONDS_TO_TICKS(us)    (((us)*FTM0_CLOCK_FREQUENCY)/1000000)


void PwmIO::setDutyCycle(int dutyCycle) const {
   pwmData->ftm->CONTROLS[pwmData->ftmChannel].CnSC = ftm_pwmHighTruePulses;

   if (pwmData->ftm->SC&FTM_SC_CPWMS_MASK) {
      pwmData->ftm->CONTROLS[pwmData->ftmChannel].CnV  = (dutyCycle*pwmData->ftm->MOD)/100;
   }
   else {
      pwmData->ftm->CONTROLS[pwmData->ftmChannel].CnV  = (dutyCycle*(pwmData->ftm->MOD+1))/100;
   }
}

void PwmIO::setPeriod(int period) const {
   // Common registers
   pwmData->ftm->SC      = FTM_SC_CLKS(0); // Disable FTM so register changes are immediate
   if ((pwmData->ftm->SC&FTM_SC_CPWMS_MASK) != 0) {
      pwmData->ftm->MOD     = period/2;
      // Centre aligned PWM with CPWMS not selected
      pwmData->ftm->SC      = FTM_SC_CLKS(FTM_SC_CLKS_VALUE)|FTM_SC_PS(_FTM0_PRESCALE_VALUE)|FTM_SC_CPWMS_MASK;
   }
   else {
      pwmData->ftm->MOD     = period-1;
      // Left aligned PWM without CPWMS selected
      pwmData->ftm->SC      = FTM_SC_CLKS(FTM_SC_CLKS_VALUE)|FTM_SC_PS(_FTM0_PRESCALE_VALUE);
   }
}

/*! Initialises FTM0 for PWM
 *
 *  @param period  - PWM Period in ticks (use PWM0_MILLISECOND() macro)
 *  @param mode    - Left- or centre-align all waveforms from this PWM
 *
 * Configures:
 *   - Enables FTM0 clock
 *   - Sets FTM0 CNTIN & MOD values
 *   - Enables FTM0
 */
void PwmIO::setPwmOutput(int period /* ticks */, Pwm_Mode mode) const {
   *data->pcr = data->pcrValue|pwmData->portMux;

   // Enable clock to FTM0
   SIM_SCGC6  |= SIM_SCGC6_FTM0_MASK;

#ifdef SIM_SCGC6_FTM1_MASK
   // Enable clock to FTM0
   SIM_SCGC6  |= SIM_SCGC6_FTM0_MASK;
#endif

   // Common registers
   pwmData->ftm->SC      = FTM_SC_CLKS(0); // Disable FTM so register changes are immediate
   pwmData->ftm->CNTIN   = 0;
   pwmData->ftm->CNT     = 0;
   if (mode == ftm_centreAlign) {
      pwmData->ftm->MOD     = period/2;
      // Centre aligned PWM with CPWMS not selected
      pwmData->ftm->SC      = FTM_SC_CLKS(FTM_SC_CLKS_VALUE)|FTM_SC_PS(_FTM0_PRESCALE_VALUE)|FTM_SC_CPWMS_MASK;
   }
   else {
      pwmData->ftm->MOD     = period-1;
      // Left aligned PWM without CPWMS selected
      pwmData->ftm->SC      = FTM_SC_CLKS(FTM_SC_CLKS_VALUE)|FTM_SC_PS(_FTM0_PRESCALE_VALUE);
   }
}
}
