/*
 * I2C.h
 *
 *  Created on: 22/11/2013
 *      Author: podonoghue
 */

#ifndef I2C_H_
#define I2C_H_

#include <stdint.h>
#include "derivative.h"

class I2C {

public:
   enum Mode {
      polled    = 0,
      interrupt = I2C_C1_IICIE_MASK,
   };

   enum i2cState { i2c_idle, i2c_txAddr, i2c_rxAddr, i2c_rxAddr2, i2c_txRegAddr, i2c_rxRegAddr, i2c_txData, i2c_rxData };
   Mode mode;

   int transmit(uint8_t address, const uint8_t data[], int size);
   int receive(uint8_t address,  uint8_t data[], int size);

protected:
   uint8_t             myAddress;           // Address of this device (operating as slave)
   volatile I2C0_Type *i2c;                 // Pointer to hardware device
   i2cState            state;               // State of current transaction
   int                 dataBytesRemaining;  // Number of bytes remaining in current transaction
   uint8_t            *dataPtr;             // Pointer to data for current transaction
   uint8_t             addressedDevice;     // Address of device being communicated with
   int                 errorCode;

   I2C(uint8_t myAddress, Mode mode, volatile I2C0_Type *i2c);
   I2C(const I2C&);

   void init(void);
   void waitWhileBusy(void);
   void startTxRx(uint8_t address, uint8_t data[], int size);
   void startTransmit(uint8_t address, const uint8_t data[], int size);
   void startReceive(uint8_t address, uint8_t data[], int size);
   void setbps(uint32_t bps);

   void poll(void);
   friend void I2C0_IRQHandler(void);
   friend void I2C1_IRQHandler(void);
   friend void I2C2_IRQHandler(void);
   friend void I2C3_IRQHandler(void);
};

#ifdef I2C0
class I2C_0 : public I2C {

public:
   /*
    * Constructor for I2C #0 interface
    *
    * @param myAddress - not used as slave interface is not handled.
    * @param mode      - i2c_polled or i2c_interrupt
    * @param baud      - baud rate
    *
    */
   I2C_0(uint8_t myAddress = 0x00, Mode mode = polled, unsigned baud=400000) : I2C(myAddress, mode, I2C0) {
      busHangReset();
      init();
      // Set baud rate
      setbps(baud);
   }

private:
   void init(void);
   void busHangReset();
   friend void I2C0_IRQHandler(void);
   static I2C* thisPtr;      // This pointer for class instance associated with I2S0
};
#endif

#ifdef I2C1
class I2C_1 : public I2C {

public:
   /*
    * Constructor for I2C #1 interface
    *
    * @param myAddress - not used as slave interface is not handled.
    * @param mode      - i2c_polled or i2c_interrupt
    * @param baud      - baud rate
    *
    */
   I2C_1(uint8_t myAddress = 0x00, Mode mode = polled, unsigned baud=400000) : I2C(myAddress, mode, I2C1) {
      busHangReset();
      init();
      setbps(baud);
   }

private:
   void init(void);
   void busHangReset();
   static I2C* thisPtr;      // This pointer for class instance associated with I2S1
   friend void I2C1_IRQHandler(void);
};
#endif

#ifdef I2C2
class I2C_2 : public I2C {

public:
   /*
    * Initialise the I2C interface
    *
    * @param myAddress - not used as slave interface is not handled.
    * @param mode      - i2c_polled or i2c_interrupt
    * @param baud      - baud rate
    */
   I2C_2(uint8_t myAddress = 0x00, Mode mode = polled, unsigned baud=400000) : I2C(myAddress, mode, I2C2) {
      busHangReset();
      init();
      setbps(baud);
   }

private:
   void init(void);
   void busHangReset();
   static I2C* thisPtr;      // This pointer for class instance associated with I2S2
   friend void I2C2_IRQHandler(void);
};
#endif

#endif /* I2C_H_ */
