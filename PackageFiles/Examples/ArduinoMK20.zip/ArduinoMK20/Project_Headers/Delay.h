/*
 * @file Delay.h
 * @brief Very simple delay routine using SysTick timer
 *
 *  Created on: 5 Jul 2015
 *      Author: podonoghue
 */

#ifndef SOURCES_DELAY_H_
#define SOURCES_DELAY_H_

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Simple delay routine
 *
 * @param msToWait How many milliseconds to busy-wait
 */
void waitMS(unsigned msToWait);

/**
 * Simple 10us delay routine
 */
void wait10us();

/**
 * Get count of timer ticks
 *
 * @return ticks since arbitrary epoch
 */
unsigned getTicks();

#ifdef __cplusplus
}
#endif

#endif /* SOURCES_DELAY_H_ */
