/*!
 * CMSIS Timer-Signal example
 *
 * This example demonstrates creating a timer callback function and communication between that function and the main thread using
 * signals.
 *
 * Target board - FRDM-K20D50
 *
 * Assumes LEDs on PA1 & PA5
 *
 */
#include <stdio.h>
#include "cmsis_os.h"
#include "derivative.h"
#include "leds.h"

// Forward references
void callbackFunction (void const *argument); // prototypes for timer callback function

//! Thread IDs
osThreadId mainFunctionId;
osThreadId threadFunctionId;

//! Define timers
osTimerDef (Timer1, callbackFunction); 

#define SIGNAL_MASK (1<<2) // Arbitrary signal mask used for communication

/*!
 * Function used a timer call-back
 *
 * @param argument pointer to arbitrary object passed when timer is created
 *
 */
void callbackFunction(void const *argument) {
   (void) argument;

   // Set Green LED on
   greenLedOn();

   // Signal to main thread
   osSignalSet(mainFunctionId, SIGNAL_MASK);

   // Pause for 250 ms
   osDelay(250);

   // Set Green LED off
   greenLedOff();
}

void port_initialise() {
   // Enable all port clocks
   SIM_SCGC5 |=   SIM_SCGC5_PORTA_MASK
                | SIM_SCGC5_PORTB_MASK
                | SIM_SCGC5_PORTC_MASK
                | SIM_SCGC5_PORTD_MASK
                | SIM_SCGC5_PORTE_MASK;
}

/*!
 * Main function - forms main thread
 *
 */
int main(void) {

   port_initialise();
   led_initialise();

   // Get main thread ID
   mainFunctionId = osThreadGetId();

   // Create periodic timer
   osTimerId timerId = osTimerCreate (osTimer(Timer1), osTimerPeriodic, NULL);
   if (timerId == NULL) {
      __asm("bkpt");
   }
   osTimerStart (timerId, 1000UL);
   printf("Timer ID      = %d\n", (int)timerId);

   for (;;) {
      // Wait for signal from thread
      osSignalWait(SIGNAL_MASK, osWaitForever);

      // Flash LED for 100 ms
      redLedOn();
      osDelay(100);
      redLedOff();
   }
}

