/*
 * Gpio.cpp
 *
 *  Created on: 09/07/2014
 *      Author: podonoghue
 */

#include "utilities.h"
#include "Gpio.h"
#include "ArduinoKinetis.h"
#include "clock_configure.h"

namespace Arduino {

#define PORT_PCR (PORT_PCR_DSE_MASK|PORT_PCR_PE_MASK|PORT_PCR_PS_MASK) // PCR setting for ports (w/o MUX)

#define ADC(num) CONCAT2_(ADC,num)
#define FTM(num) CONCAT2_(FTM,num)

static const AnalogueIO::AnalogueIOData A0_data  = {{PORT_CLOCK_MASK(A0_PORT),  &PCR(A0_PORT,  A0_NUM),  PORT_PCR, GPIO(A0_PORT),  (1<<A0_NUM)},
                                                   ADC(A0_ADC_NUM), A0_ACH};
static const AnalogueIO::AnalogueIOData A1_data  = {{PORT_CLOCK_MASK(A1_PORT),  &PCR(A1_PORT,  A1_NUM),  PORT_PCR, GPIO(A1_PORT),  (1<<A1_NUM)},
                                                   ADC(A1_ADC_NUM), A1_ACH};
static const AnalogueIO::AnalogueIOData A2_data  = {{PORT_CLOCK_MASK(A2_PORT),  &PCR(A2_PORT,  A2_NUM),  PORT_PCR, GPIO(A2_PORT),  (1<<A2_NUM)},
                                                   ADC(A2_ADC_NUM), A2_ACH};
static const AnalogueIO::AnalogueIOData A3_data  = {{PORT_CLOCK_MASK(A3_PORT),  &PCR(A3_PORT,  A3_NUM),  PORT_PCR, GPIO(A3_PORT),  (1<<A3_NUM)},
                                                   ADC(A3_ADC_NUM), A3_ACH};
static const AnalogueIO::AnalogueIOData A4_data  = {{PORT_CLOCK_MASK(A4_PORT),  &PCR(A4_PORT,  A4_NUM),  PORT_PCR, GPIO(A4_PORT),  (1<<A4_NUM)},
                                                   ADC(A4_ADC_NUM), A4_ACH};
static const AnalogueIO::AnalogueIOData A5_data  = {{PORT_CLOCK_MASK(A5_PORT),  &PCR(A5_PORT,  A5_NUM),  PORT_PCR, GPIO(A5_PORT),  (1<<A5_NUM)},
                                                   ADC(A5_ADC_NUM), A5_ACH};

static const DigitalIO::DigitalIOData D0_data  = {PORT_CLOCK_MASK(D0_PORT),  &PCR(D0_PORT,  D0_NUM),  PORT_PCR, GPIO(D0_PORT),  (1<<D0_NUM)};
static const PwmIO::PwmIOData         D1_data  = {{PORT_CLOCK_MASK(D1_PORT),  &PCR(D1_PORT,  D1_NUM),  PORT_PCR, GPIO(D1_PORT),  (1<<D1_NUM)},
                                                 FTM(D1_FTM), D1_FTM_CH, PORT_PCR_MUX(D1_FTM_FN)};
static const DigitalIO::DigitalIOData D2_data  = {PORT_CLOCK_MASK(D2_PORT),  &PCR(D2_PORT,  D2_NUM),  PORT_PCR, GPIO(D2_PORT),  (1<<D2_NUM)};
static const PwmIO::PwmIOData         D3_data  = {{PORT_CLOCK_MASK(D3_PORT),  &PCR(D3_PORT,  D3_NUM),  PORT_PCR, GPIO(D3_PORT),  (1<<D3_NUM)},
                                                 FTM(D3_FTM), D3_FTM_CH, PORT_PCR_MUX(D3_FTM_FN)};
static const DigitalIO::DigitalIOData D4_data  = {PORT_CLOCK_MASK(D4_PORT),  &PCR(D4_PORT,  D4_NUM),  PORT_PCR, GPIO(D4_PORT),  (1<<D4_NUM)};

static const PwmIO::PwmIOData         D5_data  = {{PORT_CLOCK_MASK(D5_PORT),  &PCR(D5_PORT,  D5_NUM),  PORT_PCR, GPIO(D5_PORT),  (1<<D5_NUM)},
                                                 (FTM0_Type*)FTM(D5_FTM), D5_FTM_CH, PORT_PCR_MUX(D5_FTM_FN)};
static const PwmIO::PwmIOData         D6_data  = {{PORT_CLOCK_MASK(D6_PORT),  &PCR(D6_PORT,  D6_NUM),  PORT_PCR, GPIO(D6_PORT),  (1<<D6_NUM)},
                                                 FTM(D6_FTM), D6_FTM_CH, PORT_PCR_MUX(D6_FTM_FN)};
static const DigitalIO::DigitalIOData D7_data  = {PORT_CLOCK_MASK(D7_PORT),  &PCR(D7_PORT,  D7_NUM),  PORT_PCR, GPIO(D7_PORT),  (1<<D7_NUM)};
static const PwmIO::PwmIOData         D8_data  = {{PORT_CLOCK_MASK(D8_PORT),  &PCR(D8_PORT,  D8_NUM),  PORT_PCR, GPIO(D8_PORT),  (1<<D8_NUM)},
                                                  (FTM0_Type*)FTM(D8_FTM), D8_FTM_CH, PORT_PCR_MUX(D8_FTM_FN)};
static const PwmIO::PwmIOData         D9_data  = {{PORT_CLOCK_MASK(D9_PORT),  &PCR(D9_PORT,  D9_NUM),  PORT_PCR, GPIO(D9_PORT),  (1<<D9_NUM)},
                                                  (FTM0_Type*)FTM(D9_FTM), D9_FTM_CH, PORT_PCR_MUX(D9_FTM_FN)};
static const DigitalIO::DigitalIOData D10_data = {PORT_CLOCK_MASK(D10_PORT), &PCR(D10_PORT, D10_NUM), PORT_PCR, GPIO(D10_PORT), (1<<D10_NUM)};
static const DigitalIO::DigitalIOData D11_data = {PORT_CLOCK_MASK(D11_PORT), &PCR(D11_PORT, D11_NUM), PORT_PCR, GPIO(D11_PORT), (1<<D11_NUM)};
static const DigitalIO::DigitalIOData D12_data = {PORT_CLOCK_MASK(D12_PORT), &PCR(D12_PORT, D12_NUM), PORT_PCR, GPIO(D12_PORT), (1<<D12_NUM)};
static const PwmIO::PwmIOData         D13_data  = {{PORT_CLOCK_MASK(D13_PORT),  &PCR(D13_PORT,  D13_NUM),  PORT_PCR, GPIO(D13_PORT),  (1<<D13_NUM)},
                                                  (FTM0_Type*)FTM(D13_FTM), D13_FTM_CH, PORT_PCR_MUX(D13_FTM_FN)};

static const DigitalIO::DigitalIOData D14_data = {PORT_CLOCK_MASK(D14_PORT), &PCR(D14_PORT, D14_NUM), PORT_PCR, GPIO(D14_PORT), (1<<D14_NUM)};
static const DigitalIO::DigitalIOData D15_data = {PORT_CLOCK_MASK(D15_PORT), &PCR(D15_PORT, D15_NUM), PORT_PCR, GPIO(D15_PORT), (1<<D15_NUM)};

const AnalogueIO    gpioA0(&A0_data);
const AnalogueIO    gpioA1(&A1_data);
const AnalogueIO    gpioA2(&A2_data);
const AnalogueIO    gpioA3(&A3_data);
const AnalogueIO    gpioA4(&A4_data); // Conflicts with KL25-I2C1
const AnalogueIO    gpioA5(&A5_data); // Conflicts with KL25-I2C1

const DigitalIO     gpioD0(&D0_data);
const PwmIO         gpioD1(&D1_data); // Conflicts with KL25-UART0
const DigitalIO     gpioD2(&D2_data); // Conflicts with KL25-UART0
const PwmIO         gpioD3(&D3_data);
const DigitalIO     gpioD4(&D4_data);
const PwmIO         gpioD5(&D5_data);
const PwmIO         gpioD6(&D6_data);
const DigitalIO     gpioD7(&D7_data);

const PwmIO         gpioD8(&D8_data);
const PwmIO         gpioD9(&D9_data);
const DigitalIO     gpioD10(&D10_data);
const DigitalIO     gpioD11(&D11_data);
const DigitalIO     gpioD12(&D12_data);
const PwmIO         gpioD13(&D13_data);
const DigitalIO     gpioD14(&D14_data);
const DigitalIO     gpioD15(&D15_data);

/*
 * Initialise the ADC
 */
void AnalogueIO::initialiseADC(void) const {

   // Enables clock to ADCs
   SIM_SCGC6 |= SIM_SCGC6_ADC0_MASK;

#ifdef SIM_SCGC6_ADC1_MASK
   SIM_SCGC6 |= SIM_SCGC6_ADC1_MASK;
#endif

#ifdef SIM_SCGC3_ADC1_MASK
   SIM_SCGC3 |= SIM_SCGC3_ADC1_MASK;
#endif

   // Configure ADC for software triggered conversion
   analogueData->adc->CFG1 = ADC_CFG1_ADIV(3)|ADC_CFG1_MODE(1)|ADC_CFG1_ADLSMP_MASK|ADC_CFG1_ADICLK(0);
   analogueData->adc->SC2  = 0;
   analogueData->adc->CFG2 = ADC_CFG2_ADLSTS(0)|ADC_CFG2_MUXSEL_MASK; // Choose 'b' channels
}

/*
 * Initiates a conversion and waits for it to complete
 *
 * @return - the result of the conversion
 */
int AnalogueIO::doADCConversion() const {

   // Trigger conversion
   analogueData->adc->SC1A = ADC_SC1_ADCH(analogueData->adcChannel);

   while ((analogueData->adc->SC1A&ADC_SC1_COCO_MASK) == 0) {
      __asm__("nop");
   }
   return (int)analogueData->adc->RA;
}

/*
 * FTM Clock sources
 */
#define _FTM0_CLOCK0 (0) // Disabled
#define _FTM0_CLOCK1 SYSTEM_CORE_CLOCK
#define _FTM0_CLOCK2 SYSTEM_MCGFFCLK_CLOCK
#define _FTM0_CLOCK3 (0) // External FTM_CLKINx clock - not defined

#define _FTM0_CLOCK_FREQUENCY_BASE  _FTM0_CLOCK1

#if (_FTM0_CLOCK_FREQUENCY_BASE == _FTM0_CLOCK0)
#define FTM_SC_CLKS_VALUE (0)
#elif (_FTM0_CLOCK_FREQUENCY_BASE == _FTM0_CLOCK1)
#define FTM_SC_CLKS_VALUE (1)
#elif (_FTM0_CLOCK_FREQUENCY_BASE == _FTM0_CLOCK2)
#define FTM_SC_CLKS_VALUE (2)
#elif (_FTM0_CLOCK_FREQUENCY_BASE == _FTM0_CLOCK3)
#define FTM_SC_CLKS_VALUE (3)
#else
#error "Check _FTM0_CLOCK_FREQUENCY_BASE value in pwm.h"
#endif

// Choice of prescale value (FTM0_SC.PS)
#define _FTM0_PRESCALE_VALUE    (7)
#define _FTM0_PRESCALE          (1<<_FTM0_PRESCALE_VALUE)
#define FTM0_CLOCK_FREQUENCY    (_FTM0_CLOCK_FREQUENCY_BASE/_FTM0_PRESCALE)

//! Macro to convert milliseconds to FTM0 ticks
#define FTM0_MILLISECONDS_TO_TICKS(ms)    (((ms)*FTM0_CLOCK_FREQUENCY)/1000)
//! Macro to convert microseconds to FTM0 ticks
#define FTM0_MICROSECONDS_TO_TICKS(us)    (((us)*FTM0_CLOCK_FREQUENCY)/1000000)


void PwmIO::setDutyCycle(int dutyCycle) const {
   pwmData->ftm->CONTROLS[pwmData->ftmChannel].CnSC = ftm_pwmHighTruePulses;

   if (pwmData->ftm->SC&FTM_SC_CPWMS_MASK) {
      pwmData->ftm->CONTROLS[pwmData->ftmChannel].CnV  = (dutyCycle*pwmData->ftm->MOD)/100;
   }
   else {
      pwmData->ftm->CONTROLS[pwmData->ftmChannel].CnV  = (dutyCycle*(pwmData->ftm->MOD+1))/100;
   }
}

void PwmIO::setPeriod(int period) const {
   // Common registers
   pwmData->ftm->SC      = FTM_SC_CLKS(0); // Disable FTM so register changes are immediate
   if ((pwmData->ftm->SC&FTM_SC_CPWMS_MASK) != 0) {
      pwmData->ftm->MOD     = period/2;
      // Centre aligned PWM with CPWMS not selected
      pwmData->ftm->SC      = FTM_SC_CLKS(FTM_SC_CLKS_VALUE)|FTM_SC_PS(_FTM0_PRESCALE_VALUE)|FTM_SC_CPWMS_MASK;
   }
   else {
      pwmData->ftm->MOD     = period-1;
      // Left aligned PWM without CPWMS selected
      pwmData->ftm->SC      = FTM_SC_CLKS(FTM_SC_CLKS_VALUE)|FTM_SC_PS(_FTM0_PRESCALE_VALUE);
   }
}

/*! Initialises FTM0 for PWM
 *
 *  @param period  - PWM Period in ticks (use PWM0_MILLISECOND() macro)
 *  @param mode    - Left- or centre-align all waveforms from this PWM
 *
 * Configures:
 *   - Enables FTM0 clock
 *   - Sets FTM0 CNTIN & MOD values
 *   - Enables FTM0
 */
void PwmIO::setPwmOutput(int period /* ticks */, Pwm_Mode mode) const {
   *data->pcr = data->pcrValue|pwmData->portMux;

   // Enable clock to FTM0
   SIM_SCGC6  |= SIM_SCGC6_FTM0_MASK;

#ifdef SIM_SCGC6_FTM1_MASK
   // Enable clock to FTM0
   SIM_SCGC6  |= SIM_SCGC6_FTM0_MASK;
#endif

   // Common registers
   pwmData->ftm->SC      = FTM_SC_CLKS(0); // Disable FTM so register changes are immediate
   pwmData->ftm->CNTIN   = 0;
   pwmData->ftm->CNT     = 0;
   if (mode == ftm_centreAlign) {
      pwmData->ftm->MOD     = period/2;
      // Centre aligned PWM with CPWMS not selected
      pwmData->ftm->SC      = FTM_SC_CLKS(FTM_SC_CLKS_VALUE)|FTM_SC_PS(_FTM0_PRESCALE_VALUE)|FTM_SC_CPWMS_MASK;
   }
   else {
      pwmData->ftm->MOD     = period-1;
      // Left aligned PWM without CPWMS selected
      pwmData->ftm->SC      = FTM_SC_CLKS(FTM_SC_CLKS_VALUE)|FTM_SC_PS(_FTM0_PRESCALE_VALUE);
   }
}
}
