/*
 *  Include the derivative-specific header file
 */
#include "MK22FN512M12.h"
