/*
 * Delay.h
 *
 *  Created on: 8 Aug 2014
 *      Author: podonoghue
 */

#ifndef DELAY_H_
#define DELAY_H_

class Delay {
public:
   static void delayMS(unsigned ms);
   static void delayUS(unsigned us);
};

#endif /* DELAY_H_ */
