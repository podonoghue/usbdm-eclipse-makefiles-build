/*
 * newlib_stubs.c
 *
 *  Created on: 2 Nov 2010
 *      Author: nanoage.co.uk
 */
#include <stddef.h>
#include <stdint.h>
#include <sys/types.h>

/**
 *  sbrk
 *
 *   Increase program data space.
 *   Malloc and related functions depend on this
 */
static caddr_t heap_end = NULL;

caddr_t _sbrk(int incr) {
   extern char __HeapBottom; /* Defined by the linker */
   extern char __HeapLimit;  /* Defined by the linker */
   caddr_t prev_heap_end;
   caddr_t next_heap_end;

   if (heap_end == NULL) {
      /* First allocation */
      heap_end = &__HeapBottom;
   }
   prev_heap_end = heap_end;
   // Round top to 2^3 boundary
   next_heap_end = (caddr_t)(((int)prev_heap_end + incr + 7) & ~7);
   if (next_heap_end > &__HeapLimit) {
      /* Heap and stack collision */
      return NULL;
   }
   heap_end = next_heap_end;
   return prev_heap_end;
}

// cmsis-os optional routine
void os_tmr_call(uint16_t  info) {
   (void)info;
}
